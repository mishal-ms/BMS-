const path = require('path')

//  const sharepoint = 'C:/Users/SOGI8019/OneDrive Corp/Atkins Ltd/BIM Navigator - html/dist';
// const sharepoint = 'C:/Users/SOGI8019/OneDrive Corp/Atkins Ltd/Babcock - html/AtkinsBIM';
// const sharepoint = 'C:/Users/SOGI8019/OneDrive Corp/Atkins Ltd/GDFLibrary - html/AtkinsBim';
//const sharepoint = 'C:/Users/SOGI8019/OneDrive Corp/Atkins Ltd/GDFLibrary - html/BIM';
// const sharepoint = 'C:/Temp/BIMChanges20210416';
const sharepoint = 'C:/Users/mali8965/OneDrive/Desktop/BMSHUB';
module.exports = {
  
     outputDir: sharepoint,
     publicPath: '',
     indexPath:'index.aspx'
}