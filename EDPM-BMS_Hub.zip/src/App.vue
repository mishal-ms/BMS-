<template>
	<div id="app">
		<div class="wrapper-container">
		<Navigation />
		<HeaderComp />
		
		
		<!-- <WinWorkAllSteps v-if="tab"/>  -->
		<div >
			<router-view/>
		</div>
		<FooterComp />
		
</div>

	</div>
</template>
<script>
import Navigation from '@/components/Navigation.vue'
import api from '@/service'
import { mapActions, mapGetters } from 'vuex'
import HeaderComp from '@/components/Header.vue'
import FooterComp from '@/components/Footer.vue'
export default {
  	name: 'App',
	components: {
		Navigation, FooterComp, HeaderComp
	},
	data() {
		return {
			search: false,
		}
	},
	mounted(){
		// this.getAllData();
	},
	methods: {
		// ...mapActions([
		// 	'storeResults','storeCombinedResult'
		// ]),
		// getAllData() {
		// 	api.getAll().then(response => {
				
		// 		let array = [];
		// 		response.subStages.forEach(subStage => {
		// 			let stage = response.stages.find(stage => stage.Id === subStage.StageId);
        //         	subStage.Stage = stage;
        //         	array.push(subStage);
		// 		});
		// 		console.log(response)
		// 		this.storeCombinedResult(array);
		// 		this.storeResults(response);
		// 	})
		// 	.catch(error => {
		// 		console.log(error);
		// 	})
		// },
		// showSearchResults(value) {
		// 	this.search = value.active;
		// 	console.log(this.search);
		// },
		// changeTab(value) {
		// 	this.tab= value;
		// }
  	}
		
}
</script>
<style >
	@import 'assets/css/style.css';
</style>