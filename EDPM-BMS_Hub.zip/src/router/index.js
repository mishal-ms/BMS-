import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Detail from '../views/Detail.vue'
import WinWorkAllSteps from '../components/WinWorkAllSteps.vue'
import CapturePlanning from '../components/CapturePlanning.vue'
import BimStages from '../components/BimStages.vue'
import BimStagesDetail from '../components/BimStagesDetail.vue'
import ClientDevelopment from '../components/ClientDevelopment.vue'
import ExploreTheMarket from '../components/ExploreTheMarket.vue'
import Navigation from '../components/Navigation.vue'
import OpportunityIdentification from '../components/OpportunityIdentification.vue'
import PostSubmission from '../components/PostSubmission.vue'
import ProcessDetainedView from '../components/ProcessDetainedView.vue'
import ProcessImplement from '../components/ProcessImplement.vue'
import ProcessLeadership from '../components/ProcessLeadership.vue'
import ProcessSectorPlan from '../components/ProcessSectorPlan.vue'
import ProcessPerformance from '../components/ProcessPerformance.vue'
import ProposalManagement from '../components/ProposalManagement.vue'
import StragicPositioning from '../components/StragicPositioning.vue'
import DeliverWorkProposalHandover from '../components/DeliverWorkProposalHandover.vue'
import DeliverWorkProposalHandoverNew from '../components/DeliverWorkProposalHandOverNew.vue'
import DeliverWorkAllSteps from '../components/DeliverWorkAllSteps'
import DeliverWorkProjectRiskManagement from '../components/DeliverWorkProjectRiskManagement.vue'
import DeliverWorkProjectInfoManagement from '../components/DeliverWorkProjectInfoManagement.vue'
import DeliverWorkClientSatisfaction from '../components/DeliverWorkClientSatisfaction.vue'
import DeliverWorkTechnicalAssurance from '../components/DeliverWorkTechnicalAssurance.vue'
import DeliverWorkProjectPerformance from '../components/DeliverWorkProjectPerformance.vue'
import DeliverWorkProjectChangeControl from '../components/DeliverWorkProjectChangeControl.vue'
import DeliverWorkProjectPlanning from '../components/DeliverWorkProjectPlanning.vue'
import DeliverWorkProjectFinancialManagement from '../components/DeliverWorkProjectFinancialManagement.vue'
import DeliverWorkProjectMobilisation from '../components/DeliverworkProjectMobilisation.vue'
import DeliverWorkProjectClosure from '../components/DeliverWorkProjectClosure.vue'
import CapturePlanningDetailedView from '../components/CapturePlanningDetailedView.vue'
import StragicPositioningDetailedView from '../components/StragicPositioningDetailedView.vue'
import OpportunityIdentificationDetailedView from '../components/OpportunityIdentificationDetailedView.vue'
import ClientDevelopmentDetailedView from '../components/ClientDevelopmentDetailedView.vue'
import ProposalManagementDetailedView from '../components/ProposalManagementDetailedView.vue'
import DeliverWorkClientSatisfactionNew from '../components/DeliverWorkClientSatisfactionNew.vue'
import DeliverWorkExternalProjectProcurementManagement from '../components/DeliverWorkExternalProjectProcurementManagement.vue'
import DeliverWorkProjectChangeControlNew from '../components/DeliverWorkProjectChangeControlNew.vue'
import DeliverWorkProjectClosureNew from '../components/DeliverWorkProjectClosureNew.vue'
import DeliverWorkProjectPlanningNew from '../components/DeliverWorkProjectPlanningNew.vue'
import DeliverWorkProjectRiskManagementNew from '../components/DeliverWorkProjectRiskManagementNew.vue'
import DeliverWorkProjectInfoManagementNew from '../components/DeliverWorkProjectInfoManagementNew.vue'
import DeliverWorkProjectPerformanceNew from '../components/DeliverWorkProjectPerformanceNew.vue'
import DeliverWorkProjectMobilisationNew from '../components/DeliverWorkProjectMobilisationNew.vue'
import EnableBusinessPerformanceManagement from '../components/EnableBusinessPerformanceManagement.vue'
import EnableCareerDevelopment from '../components/EnableCareerDevelopment.vue'
import EnableAttractHire from '../components/EnableAttractHire.vue'
import EnableCorporateProcurement from '../components/EnableCorporateProcurement.vue'
import EnableEdAndI from '../components/EnableEdAndI.vue'
import EnableEnterpriseRiskManagement from '../components/EnableEnterpriseRiskManagement.vue'
import EnableExternalCompliance from '../components/EnableExternalCompliance.vue'
import EnableHighPerformingCulture from '../components/EnableHighPerformingCulture.vue'
import EnableIntegratedManagementSystem from '../components/EnableIntegratedManagementSystem.vue'
import EnableIntegrity from '../components/EnableIntegrity.vue'
import EnableIT from '../components/EnableIT.vue'
import EnableOptimisedWorkforce from '../components/EnableOptimisedWorkforce.vue'
import EnableSafeHealthyWorkEnvironment from '../components/EnableSafeHealthyWorkEnvironment.vue'
import EnableSecurity from '../components/EnableSecurity.vue'
import EnableAttractHireDtVw from '../components/EnableAttractHireDtVw.vue'
import LeadProcessLeadershipDetailedView from '../components/LeadProcessLeadershipDetailedView.vue'
import LeadProcessSectorPlanDetailedView from '../components/LeadProcessSectorPlanDetailedView.vue'
import LeadProcessImplementDetailedView from '../components/LeadProcessImplementDetailedView.vue'
import LeadProcessImprovementDetailedView from '../components/LeadProcessImprovementDetailedView.vue'
import EnableBusinessPerformanceManagementDtVw from '../components/EnableBusinessPerformanceManagementDtVw.vue'
import EnableCareerDevelopmentDtVw from '../components/EnableCareerDevelopmentDtVw.vue'
import EnableCorporateProcurementDtVw from '../components/EnableCorporateProcurementDtVw.vue'
import EnableEdAndIDtVw from '../components/EnableEdAndIDtVw.vue'
import EnableEnterpriseRiskManagementDtVw from '../components/EnableEnterpriseRiskManagementDtVw.vue'
import EnableExternalComplianceDtVw from '../components/EnableExternalComplianceDtVw.vue'
import EnableHighPerformingCultureDtVw from '../components/EnableHighPerformingCultureDtVw.vue'
import EnableIntegratedManagementSystemDtVw from '../components/EnableIntegratedManagementSystemDtVw.vue'
import EnableIntegrityDtVw from '../components/EnableIntegrityDtVw.vue'
import EnableITDtVw from '../components/EnableITDtVw.vue'
import EnableOptimisedWorkforceDtVw from '../components/EnableOptimisedWorkforceDtVw.vue'
import EnableSafeHealthyWorkEnvironmentDtVw from '../components/EnableSafeHealthyWorkEnvironmentDtVw.vue'
import EnableSecurityDtVw from '../components/EnableSecurityDtVw.vue'
import DeliverWorkStartJobTab from '../components/DeliverWorkStartJobTab.vue'
import DeliverWorkDoJobTab from '../components/DeliverWorkDoJobTab.vue'
import DeliverWorkFinishJobTab from '../components/DeliverWorkFinishJobTab.vue'
import DeliverWorkTechnicalAssuranceNew from '../components/DeliverWorkTechnicalAssuranceNew.vue'
import ProcessBusinessPlan from '../components/ProcessBusinessPlan.vue'
import ProcessImprovement from '../components/ProcessImprovement.vue'
import LeadProcessBusinessPlanDetailedView from '../components/LeadProcessBusinessPlanDetailedView.vue'
import LeadProcessPerformanceDetailedView from '../components/LeadProcessPerformanceDetailedView.vue'
import DeliverWorkProjectFinancialManagementNew from '../components/DeliverWorkProjectFinancialManagementNew.vue'
import WinWorkFirstTab from '../components/WinWorkFirstTab.vue'
import WinWorkSecondTab from '../components/WinWorkSecondTab.vue'
import WinWorkThirdTab from '../components/WinWorkThirdTab.vue'









Vue.use(VueRouter)
const routes = [{
		path: '/',
		name: 'Home',
		component: Home
	},

	{
		path: '/detail/:slug',
		name: 'Detail',
		component: Detail
	},

	{
		path: '/WinWorkAllSteps',
		name: 'WinWorkAllSteps',

		component: WinWorkAllSteps
	},

	{
		path: '/CapturePlanning',
		name: 'CapturePlanning',
		component: CapturePlanning
	}
,

	{
		path: '/ClientDevelopment',
		name: 'ClientDevelopment',
		component: ClientDevelopment
	},

	{
		path: '/ExploreTheMarket',
		name: 'ExploreTheMarket',
		component: ExploreTheMarket
	},

	{
		path: '/OpportunityIdentification',
		name: 'OpportunityIdentification',
		component: OpportunityIdentification
	},

	{
		path: '/PostSubmission',
		name: 'PostSubmission',
		component: PostSubmission
	},

	{
		path: '/ProcessDetainedView',
		name: 'ProcessDetainedView',
		component: ProcessDetainedView
	},

	{
		path: '/ProcessImplement',
		name: 'ProcessImplement',
		component: ProcessImplement
	},

	{
		path: '/ProcessLeadership',
		name: 'ProcessLeadership',
		component: ProcessLeadership
	},

	{
		path: '/ProcessSectorPlan',
		name: 'ProcessSectorPlan',
		component: ProcessSectorPlan
	},

	{
		path: '/ProcessPerformance',
		name: 'ProcessPerformance',
		component: ProcessPerformance
	},
	{
		path: '/ProcessImprovement',
		name: 'ProcessImprovemente',
		component: ProcessImprovement
	},
	

	{
		path: '/ProposalManagement',
		name: 'ProposalManagement',
		component: ProposalManagement
	},

	{
		path: '/StragicPositioning',
		name: 'StragicPositioning',
		component: StragicPositioning
	},
	
	{
		path: '/DeliverWorkAllSteps',
		name: 'DeliverWorkAllSteps',
		component: DeliverWorkAllSteps
	},
	{
		path: '/DeliverWorkProposalHandover',
		name: 'DeliverWorkProposalHandover',
		component: DeliverWorkProposalHandover
	},
	{
		path: '/DeliverWorkProposalHandoverAdditionalDetails',
		name: 'DeliverWorkProposalHandoverNew',
		component: DeliverWorkProposalHandoverNew
	},
	
	{
		path: '/DeliverWorkProjectRiskManagement',
		name: 'DeliverWorkProjectRiskManagement',
		component: DeliverWorkProjectRiskManagement
	},
	{
		path: '/DeliverWorkProjectInfoManagement',
		name: 'DeliverWorkProjectInfoManagement',
		component: DeliverWorkProjectInfoManagement
	},
	{
		path: '/DeliverWorkClientSatisfaction',
		name: 'DeliverWorkClientSatisfaction',
		component: DeliverWorkClientSatisfaction
	},
	{
		path: '/DeliverWorkTechnicalAssurance',
		name: 'DeliverWorkTechnicalAssurance',
		component: DeliverWorkTechnicalAssurance
	},
	{
		path: '/DeliverWorkProjectPerformance',
		name: 'DeliverWorkProjectPerformance',
		component: DeliverWorkProjectPerformance
	},
	{
		path: '/DeliverWorkProjectChangeControl',
		name: 'DeliverWorkProjectChangeControl',
		component: DeliverWorkProjectChangeControl
	},
	{
		path: '/DeliverWorkExternalProjectProcurementManagement',
		name: 'DeliverWorkExternalProjectProcurementManagement',
		component: DeliverWorkExternalProjectProcurementManagement
	},
	{
		path: '/DeliverWorkProjectPlanning',
		name: 'DeliverWorkProjectPlanning',
		component: DeliverWorkProjectPlanning
	},

	{
		path: '/DeliverWorkProjectFinancialManagement',
		name: 'DeliverWorkProjectFinancialManagement',
		component: DeliverWorkProjectFinancialManagement
	},

	{
		path: '/DeliverWorkProjectMobilisation',
		name: 'DeliverWorkProjectMobilisation',
		component: DeliverWorkProjectMobilisation
	},
	
	{
		path: '/DeliverWorkProjectClosure',
		name: 'DeliverWorkProjectClosure',
		component: DeliverWorkProjectClosure
	},

	{
		path: '/CapturePlanningDetailedView',
		name: 'CapturePlanningDetailedView',
		component: CapturePlanningDetailedView
	},
	
	{
		path: '/StragicPositioningDetailedView',
		name: 'StragicPositioningDetailedView',
		component: StragicPositioningDetailedView
	},

	{
		path: '/OpportunityIdentificationDetailedView',
		name: 'OpportunityIdentificationDetailedView',
		component: OpportunityIdentificationDetailedView
	},

	{
		path: '/ClientDevelopmentDetailedView',
		name: 'ClientDevelopmentDetailedView',
		component: ClientDevelopmentDetailedView
	},

	{
		path: '/ProposalManagementDetailedView',
		name: 'ProposalManagementDetailedView',
		component: ProposalManagementDetailedView
	},


	{
		path: '/DeliverWorkClientSatisfactionNew',
		name: 'DeliverWorkClientSatisfactionNew',
		component: DeliverWorkClientSatisfactionNew
	},

	{
		path: '/DeliverWorkProjectChangeControlNew',
		name: 'DeliverWorkProjectChangeControlNew',
		component: DeliverWorkProjectChangeControlNew
	},

	{
		path: '/DeliverWorkProjectClosureNew',
		name: 'DeliverWorkProjectClosureNew',
		component: DeliverWorkProjectClosureNew
	},

	{
		path: '/DeliverWorkProjectPlanningNew',
		name: 'DeliverWorkProjectPlanningNew',
		component: DeliverWorkProjectPlanningNew
	},

	{
		path: '/DeliverWorkProjectRiskManagementNew',
		name: 'DeliverWorkProjectRiskManagementNew',
		component: DeliverWorkProjectRiskManagementNew
	},
	
	{
		path: '/DeliverWorkProjectInfoManagementNew',
		name: 'DeliverWorkProjectInfoManagementNew',
		component: DeliverWorkProjectInfoManagementNew
	},

	{
		path: '/DeliverWorkProjectPerformanceNew',
		name: 'DeliverWorkProjectPerformanceNew',
		component: DeliverWorkProjectPerformanceNew
	},

	{
		path: '/DeliverWorkProjectMobilisationNew',
		name: 'DeliverWorkProjectMobilisationNew',
		component: DeliverWorkProjectMobilisationNew

	},

	{
		path: '/EnableBusinessPerformanceManagement',
		name: 'EnableBusinessPerformanceManagement',
		component: EnableBusinessPerformanceManagement

	},
	
	{
		path: '/EnableCareerDevelopment',
		name: 'EnableCareerDevelopment',
		component: EnableCareerDevelopment

	},

	{
		path: '/EnableAttractHire',
		name: 'EnableAttractHire',
		component: EnableAttractHire

	},

	{
		path: '/EnableCorporateProcurement',
		name: 'EnableCorporateProcurement',
		component: EnableCorporateProcurement

	},

	{
		path: '/EnableEdAndI',
		name: 'EnableEdAndI',
		component: EnableEdAndI

	},

	{
		path: '/EnableEnterpriseRiskManagement',
		name: 'EnableEnterpriseRiskManagement',
		component: EnableEnterpriseRiskManagement

	},

	{
		path: '/EnableExternalCompliance',
		name: 'EnableExternalCompliance',
		component: EnableExternalCompliance

	},

	{
		path: '/EnableHighPerformingCulture',
		name: 'EnableHighPerformingCulture',
		component: EnableHighPerformingCulture

	},

	{
		path: '/EnableSafeHealthyWorkEnvironment',
		name: 'EnableSafeHealthyWorkEnvironment',
		component: EnableSafeHealthyWorkEnvironment


	},

	{
		path: '/EnableIntegratedManagementSystem',
		name: 'EnableIntegratedManagementSystem',
		component: EnableIntegratedManagementSystem

	},

	{
		path: '/EnableIntegrity',
		name: 'EnableIntegrity',
		component: EnableIntegrity

	},

	{
		path: '/EnableIT',
		name: 'EnableIT',
		component: EnableIT

	},

	{
		path: '/EnableOptimisedWorkforce',
		name: 'EnableOptimisedWorkforce',
		component: EnableOptimisedWorkforce


	},

	{
		path: '/EnableSecurity',
		name: 'EnableSecurity',
		component: EnableSecurity

	},

	{
		path: '/LeadProcessLeadershipDetailedView',
		name: 'LeadProcessLeadershipDetailedView',
		component: LeadProcessLeadershipDetailedView

	},
	{
		path: '/LeadProcessSectorPlanDetailedView',
		name: 'LeadProcessSectorPlanDetailedView',
		component: LeadProcessSectorPlanDetailedView

	},
	{
		path: '/LeadProcessImplementDetailedView',
		name: 'LeadProcessImplementDetailedView',
		component: LeadProcessImplementDetailedView

	},
	{
		path: '/LeadProcessImprovementDetailedView',
		name: 'LeadProcessImprovementDetailedView',
		component: LeadProcessImprovementDetailedView

	},
	{
		path: '/EnableBusinessPerformanceManagementDtVw',
		name: 'EnableBusinessPerformanceManagementDtVw',
		component: EnableBusinessPerformanceManagementDtVw

	},
	{
		path: '/EnableCareerDevelopmentDtVw',
		name: 'EnableCareerDevelopmentDtVw',
		component: EnableCareerDevelopmentDtVw

	},
	{
		path: '/EnableCorporateProcurementDtVw',
		name: 'EnableCorporateProcurementDtVw',
		component: EnableCorporateProcurementDtVw

	},
	{
		path: '/EnableEdAndIDtVw',
		name: 'EnableEdAndIDtVw',
		component: EnableEdAndIDtVw

	},
	{
		path: '/EnableEnterpriseRiskManagementDtVw',
		name: 'EnableEnterpriseRiskManagementDtVw',
		component: EnableEnterpriseRiskManagementDtVw

	},
	{
		path: '/EnableExternalComplianceDtVw',
		name: 'EnableExternalComplianceDtVw',
		component: EnableExternalComplianceDtVw

	},
	{
		path: '/EnableHighPerformingCultureDtVw',
		name: 'EnableHighPerformingCultureDtVw',
		component: EnableHighPerformingCultureDtVw

	},
	{
		path: '/EnableIntegrityDtVw',
		name: 'EnableIntegrityDtVw',
		component: EnableIntegrityDtVw

	},
	{
		path: '/EnableITDtVw',
		name: 'EnableITDtVw',
		component: EnableITDtVw

	},
	{
		path: '/EnableOptimisedWorkforceDtVw',
		name: 'EnableOptimisedWorkforceDtVw',
		component: EnableOptimisedWorkforceDtVw

	},
	{
		path: '/EnableSafeHealthyWorkEnvironmentDtVw',
		name: 'EnableSafeHealthyWorkEnvironmentDtVw',
		component: EnableSafeHealthyWorkEnvironmentDtVw

	},
	{
		path: '/EnableSecurityDtVw',
		name: 'EnableSecurityDtVw',
		component: EnableSecurityDtVw

	},
	{
		path: '/EnableAttractHireDtVw',
		name: 'EnableAttractHireDtVw',
		component: EnableAttractHireDtVw

	},
	{
		path: '/EnableIntegratedManagementSystemDtVw',
		name: 'EnableIntegratedManagementSystemDtVw',
		component: EnableIntegratedManagementSystemDtVw

	},
	{
		path: '/DeliverWorkStartJobTab',
		name: 'DeliverWorkStartJobTab',
		component: DeliverWorkStartJobTab

	},
	{
		path: '/DeliverWorkDoJobTab',
		name: 'DeliverWorkDoJobTab',
		component: DeliverWorkDoJobTab

	},
	{
		path: '/DeliverWorkFinishJobTab',
		name: 'DeliverWorkFinishJobTab',
		component: DeliverWorkFinishJobTab

	},
	{
		path: '/DeliverWorkTechnicalAssuranceNew',
		name: 'DeliverWorkTechnicalAssuranceNew',
		component: DeliverWorkTechnicalAssuranceNew

	},
	{
		path: '/ProcessBusinessPlan',
		name: 'ProcessBusinessPlan',
		component: ProcessBusinessPlan

	},
	{
		path: '/LeadProcessBusinessPlanDetailedView',
		name: 'LeadProcessBusinessPlanDetailedView',
		component: LeadProcessBusinessPlanDetailedView

	},
	{
		path: '/LeadProcessPerformanceDetailedView',
		name: 'LeadProcessPerformanceDetailedView',
		component: LeadProcessPerformanceDetailedView

	},
	{
		path: '/DeliverWorkProjectFinancialManagementNew',
		name: 'DeliverWorkProjectFinancialManagementNew',
		component: DeliverWorkProjectFinancialManagementNew

	},

	{
		path: '/WinWorkFirstTab',
		name: 'WinWorkFirstTab',
		component: WinWorkFirstTab

	},
	{
		path: '/WinWorkSecondTab',
		name: 'WinWorkSecondTab',
		component: WinWorkSecondTab

	},
	{
		path: '/WinWorkThirdTab',
		name: 'WinWorkThirdTab',
		component: WinWorkThirdTab

	},
		
]

const router = new VueRouter({
	// mode: 'history',
	base: process.env.BASE_URL,
	routes 
})

export default router