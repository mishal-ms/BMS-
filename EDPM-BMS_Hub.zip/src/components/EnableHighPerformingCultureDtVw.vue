<template>
  <div>
    <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>High Performing Culture</h2>
      <p>A high-performance culture is an organizational culture built on a set of universally accepted behaviors and norms that are encouraged by leaders and facilitated by optimal tools and processes. These help employees work as effectively as possible to achieve business goals and create value.</p>
  </div>
  <div class="tabs">
       <button class="tab-link" onclick="window.location.href='#/EnableHighPerformingCulture';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='#/EnableHighPerformingCultureDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Plan employee learning and development with associated investment</h4>
  <p>An annual training budget shall be identified as part of the business plan.  Individual training and development needs shall be assessed following the annual Performance Develoment Review (PDR) process. L&D needs shall be objectively reviewed to manage all requests in line with the business plan, budget and personal development needs. </p>
  <h4> Access is provided to the skills everyone needs to be effective in their role </h4>
  <p>Everyone shall have access to relevant learning and development essential to performing their current role </p>
  <h4>Establish controls at the right level to enable innovations and improvements</h4>
  <p>Appropriate controls shall be identified to encourage, manage, review and support innovation and improvements that align to the strategy or business plan. Investment in innovation shall be appropriately approved and supported by a documented business case. </p>
  <h4>Provide a physical environment that promotes the productivity requirements of a diverse workforce</h4>
  <p>Managing a diverse workforce requires the recognition that everyone comes with different challenges, expectations, needs and opportunities. In order to support high performance consideration shall be given to how diverse needs can be accommodated such that we benefit from a diverse talent pool that is motivated, engaged and able to deliver to their potential.</p>

  <h4> Prioritize technology and tools to support an agile organization</h4>
  <p>Technology is critical to enabling high performance. Having the right tools and systems to be effective, efficient and connected is vital. Making sure technology meets the needs of everyone today and into the future is a key priority and shall be considered as part of the business planning process</p>

   <h4>Establish performance management reviews</h4>
  <p>Performance management reviews shall formally be conducted annually to measure performance, identify future objectives and agree development needs. Regular discussions should take place during the year to enable everyone to learn from their experiences, share feedback and gain valuable support in reaching their full potential. </p>

  <h4> Plan and effectively share knowledge managament</h4>
  <p>Access to knowledge is fundamental in developing high performing teams. Learning from experience shall be captured and shared across relevant networks.  Technical leaders shall be identified and shall share knowledge and updates within their technical field.</p>


</div>
</div>
  
  </div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "EnableHighPerformingCultureDtVwComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>