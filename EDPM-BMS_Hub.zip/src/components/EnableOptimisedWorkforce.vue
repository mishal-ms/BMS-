<template>
<div>
    <!-- Main content Container section start from here -->
    <div class="cont-container">
        <div class="content-wt">
            <div class="content-hd-text">
                <h2>Optimized workforce</h2>
                <p>
                    <strong class="bld-txt">Workforce Optimization (WFO)</strong> refers
                    to a business strategy that is focused on balancing customer
                    satisfaction with service levels, workforce scheduling, operational
                    costs, and other key performance metrics. The goal is to get the
                    maximum performance from employees at any given time while servicing
                    customers in a way that works for them. WFO is an overall approach
                    to business operation with the necessary tools and applications put
                    in place to foster efficient and effective growth.
                </p>
            </div>
            <div class="tabs">

                <button class="tab-link active" onclick="window.location.href='#/EnableOptimisedWorkforce';">
                    Requirements
                </button>
                <button class="tab-link" onclick="window.location.href='#/EnableOptimisedWorkforceDtVw';">
                    Additional Detail
                </button>
                <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->

            </div>
            <div class="row-content">
                <div class="col-9">
                    <div class="card-wrap">
                        <div class="row-box">
                            <div class="box" v-on:click="show('The resource, skills and knowledge expectations to deliver to the sector plan shall be used to build the workforce management plans and inform future workforce planning needs.')">
                                <div class="content content-enable">
                                    <p class="para-cont">Share Sector Business Plan</p>
                                </div>
                                <div class="arrow-img">
                                    <img src="../assets/images/arrow-main.png" />
                                </div>
                            </div>
                            <div class="box" v-on:click="show('The resource management plan identifies the availability and skills required to deliver the short to medium term commitments.  It should balance staffing issues, agency staff, staff retention, recruitment and training.')">
                                <div class="content content-enable">
                                    <p class="para-cont">Establish Workforce Management Plan</p>
                                </div>
                                <div class="arrow-img">
                                    <img src="../assets/images/arrow-main.png" />
                                </div>
                            </div>
                            <div class="box" v-on:click="show('Development plans shall be identified to ensure people have the right knowledge, right skills and right tools to deliver to expectations.')">
                                <div class="content content-enable">
                                    <p class="para-cont">
                                        Establish documented development plans for all employees
                                    </p>
                                </div>
                                <div class="arrow-img">
                                    <img src="../assets/images/arrow-main.png" />
                                </div>
                            </div>
                            <div class="box" v-on:click="show('Capture learning from experience and make it available to share with employees to support development.')">
                                <div class="content content-enable">
                                    <p class="para-cont">Support employee development</p>
                                </div>
                                <div class="arrow-img">
                                    <img src="../assets/images/arrow-main.png" />
                                </div>
                            </div>
                            <div class="box arrow-rt" v-on:click="show('Provide employees with the right technology to effectively deliver to client requirements.')">
                                <div class="content content-enable">
                                    <p class="para-cont">Document effective technology plan</p>
                                </div>
                            </div>
                        </div>
                        <div class="row-reverse-last-child">
                            <div class="box" v-on:click="show('A workforce planning strategy shall understand and plan for future workforce needs. It shall take into account changing skills, expectations, markets and drivers to ensure the workforce of the future is ready to deliver to expectations with the right capabilities and working environment to deliver business success.')">
                                <div class="content content-enable">
                                    <p class="para-cont">
                                        Dcoument workforce planning strategy
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-3">
                    <div class="content-box">
                        <div class="own-detail">
                            <span>Process Owner:
                                <strong class="bld-txt">Simon Cole</strong></span>
                        <div class="ult-links">
                            <h4>Useful links</h4>
                            <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/human-resources/career-journey/" target="_blank">HR - Career Journey Guides</a>
                            <a href="https://wd3.myworkday.com/slihrms/d/home.htmld" target="_blank">Workday </a>
                            <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/human-resources/learning-zone.aspx" target="_blank">Learning Zone</a>
                        </div>
                        
                        <div class="ult-links">
                            <h4>Approved Deviations</h4>
                            <a>None</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        </div>
    </div>
    <!-- Main content Container section end here -->
</div>
</template>

<script>
import api from "@/service";
import router from "@/router";
import {
    mapGetters, mapActions
} from "vuex";
export default {
    name: "EnableOptimisedWorkforcecomp",
    // data() {
    //   return {
    //     banner: Banner,
    //     searchText: "",
    //     search: false,
    //     sr: "",
    //     searchResults: [],
    //   };
    // },
    // computed: {
    //   ...mapGetters(["subStages", "stages", "header"]),
    //   completeStagesInfo() {
    //     let array = [];
    //     this.subStages.forEach((subStage) => {
    //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
    //       subStage.Stage = stage;
    //       array.push(subStage);
    //     });
    //     return array;
    //   },
    //   searchRes() {
    //     if (this.sr) {
    //       return this.completeStagesInfo.filter((post) => {
    //         if (post.Title) {
    //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
    //         }
    //       });
    //     }
    //   },
    // },
     methods: {
              ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
    //   redirectTo() {
    //     this.sr = "";
    //     this.$router.push("/").catch((err) => {});
    //   },
    //   pushTo(slug) {
    //     this.sr = "";
    //     if (this.$route.params.slug !== slug) {
    //       // this.$router.go({ path: `/detail/${slug}` })
    //       this.$router.push({ name: "Detail", params: { slug: slug } });
    //     }
    //     this.$emit("searching", { active: false });
    //   },
     },
    // watch: {
    //   $route(to, from) {
    //     // Reset Search If route changes
    //     // this.search = false;
    //     // this.searchText = '';
    //     // this.searchResults = [];
    //   },
    // },
};
</script>
