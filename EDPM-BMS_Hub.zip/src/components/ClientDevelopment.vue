<template>
    <div>



<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Client development</h2>
      <p>Building and sustaining close client relationships is key to the success of our business. <strong class="bld-txt">Client development</strong> is about listening to our clients and identifying and providing solutions to their problems, sometimes even before they realize they have a problem. Our key accounts make up the majority of our business income and therefore it is essential we remain close to these clients. Our Client development process provides guidance on how to build long-term relationships with our most valuable clients.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" >Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/ClientDevelopmentDetailedView';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>

  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <div class="row-box">
        <div class="box" v-on:click="show('Should be aligned to Regional Market Strategies and shall comprise common tools for assessing Market priorities, including (but not limited to): Addressable Market Sizing; Market Forecasting (including by Segment); Analysis of Customer Demand Drivers. ')">
          <div class="content"><p class="para-cont">Market priorities identified</p></div> 
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Should be aligned to Regional Market Strategies and should be informed by an understanding of where customer demand drivers meet Engineering Services capabilities. A variety of tools and methodologies shall be available to help identify Key Clients.')">
          <div class="content"><p class="para-cont">Key clients identified  </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Should utilise a variety of qualitative and quantitative research methodologies and strategic marketing tools e.g. PESTEL / SWOT analysis, and internal interviews, to gain a deeper understanding of client demand drivers and spending priorities.')">
          <div class="content"><p class="para-cont">Undertake Client research to build understanding</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Should utilize Client Research and the Win Work Client Selection Tools that are available to help define and priortize key clients')">
          <div class="content"><p class="para-cont">Identify Key Accounts based on defined criteria</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt" v-on:click="show('Consult Win Work collaboration platforms to access guidance for KAM Plan structure, required content and tools (such as annual targets, market analysis, pipeline opportunities and a Client Engagement Plan and Customer Value Proposition Development tools)')">
          <div class="content"><p class="para-cont">Develop Client Account Management Plan for every client</p></div>
          </div>
        
      </div>

       <div class="row-reverse" v-on:click="show('Formal KPIs and Metrics shall be agreed to measure performance against KAM Plan. Formal Win Work KAM Metrics shall be required by the Global Growth Team and Key Account Managers should be responsble for implementing mechanisms to track Lead and Lag indicators on an quarterly basis. ')">
        <div class="box">
          <div class="content"><p class="para-cont">Identify measures to monitor performance against Client Account Management Plan</p></div>
        </div>
        <div class="box" v-on:click="show('A relationship plan should cover influential/key people in a client we want to build a relationship with. It should identify who is the Atkins member who will do the engagement.')">
          <div class="content"><p class="para-cont">Define and align client engagement at all levels</p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show(' The client account plan should be reviewed and updated annually ')">
          <div class="content"><p class="para-cont">Review delivery to the Client Account Management Plan </p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Client Perception Survey issued to client, completed by client, revceived from client.')">
          <div class="content"><p class="para-cont">Formal Client perception feedback received</p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Formal Client Perception findings (e.g. via Surveys) should be analysed and key findings incorporated into Client Account Plans in the form of Client Research and Intelligence. Access to feedback should be disseminated to other parts of the business, including by making it available of Win Work collaboration platforms. ')">
          <div class="content"><p class="para-cont">Feedback from Client perception incorporated into Client Account Plan</p></div>
            <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
      </div>
    </div>
    </div>

    <RightInformationPannel/>
</div>
</div>
  </div>
<!-- Main content Container section end here -->





    </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapActions } from "vuex";
import RightInformationPannel from "../components/RightInformationPannel";

export default {
  name: "ClientDevelopmentComp",
  components: {
    RightInformationPannel
  },
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  methods: {
    ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>