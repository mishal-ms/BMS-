<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Corporate Procurement</h2>
      <p>The requirement for clear controls in the procurement of goods and services is to contribute in creating and maintaining effective supply chain management capabilities, processes and systems. The overarching objective is to set controls whereby SNC-Lavalin will be competitive, yet fair and ethical in our business practice. </p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/EnableCorporateProcurement';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/EnableCorporateProcurementDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">

      <div class="row-box">
        <div class="box" v-on:click="show('Prior to initiating the procurement and sourcing of indirect goods and services, the requester shall complete the Indirect Procurement Project Initiation Charter. Involve authorised Procurement Personnel at the beginning of the procurement process to ensure the process is handled in accordance with documented procedures.')">
          <div class="content content-enable"><p class="para-cont">Document procurement requirements using the Project Initiation Charter</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Authorised Procurement Personnel shall be involved at the beginning of the procurement process to ensure the process is handled in accordance with documented procedures.')">
          <div class="content content-enable"><p class="para-cont">Involve authorised procurement personnel </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('SNC-L Employees shall make every attempt to utilize preferred suppliers where identified.')">
          <div class="content content-enable"><p class="para-cont">Utilize suppliers who are appropriately approved</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('All indirect Goods and Services to be procured equal to or in excess of $2,500 CAD shall be competitively bid. Any exception to this standard must use the Bid Waiver Sole Source Justification form, prior to launching the RFT process.')">
          <div class="content content-enable"><p class="para-cont">Competively bid where value exceeds $2,500 CAD</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt" v-on:click="show('Request For Tender (RFT) Criteria and Guidelines for assessment shall be established and used to evaluate suppliers. During the evaluation process suppliers shall be assessed against the RFT Criteria which shall  include: Bid Compliance; Pricing and Scope; Technical Evaluation; Commercial Questionnaire .')">
          <div class="content content-enable"><p class="para-cont">Establish Tender criteria and guidelines</p></div>
          </div>
      </div>

       <div class="row-reverse">
        <div class="box" v-on:click='show("A Bid review Presentation and, or Contract Resume and Approvals report shall be developed and approved by the relevant Corporate Function Manager. All negotiations shall ensure they do not take the following prohibited actions: \"tender (bid) shopping; sharing confidential information or information from other tenders; unequal sharing of information; non-disclosure of any conflicts of interest.")'>
          <div class="content content-enable"><p class="para-cont">Approval must be received from the relevant Corporate Function </p></div>
        </div>
        <div class="box" v-on:click="show('On completion of negotiations and mutual agreement is reached by both parties, Authorized Procurement Personnel must issue a notice communicating final Supplier selection. The final decision and all binding commitments shall be made by an authorised Procurement Personnel.')">
          <div class="content content-enable"><p class="para-cont">Final supplier selection notice must be issued and communicated by authorized procurement personnel</p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Approved Procurement Personnel shall ensure all necessary internal requirements are followed in the formalising of any agreement with a third party supplier. Prior to an award of an Agreement authorised procurement personnel shall ensure the following is completed: 360 Integrity Check Verification; Business Partner Compliance Due Diligence (CDD); data privacy requirements and verifications; cloud and Third Parties Engagement Framework requirements and verifications. If required ensure IT equipment activities are approved.')">
          <div class="content content-enable"><p class="para-cont">In formalising an agreement all necessary internal procurement requirements must be followed </p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('All suppliers shall receive a copy of the Supplier Code of Conduct and the requirements of the Code shall be embeded in the agreement.')">
          <div class="content content-enable"><p class="para-cont">Embed requirements of SUPPLIER CODE OF CONDUCT in agreement </p></div>
           <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-lt" v-on:click="show('The Authorized Procurement Personnel shall obtain the appropriate signatures from the designated signatories with respect to the legal entity entering into the contract.')">
          <div class="content content-enable"><p class="para-cont">Obtain appropriate signatures</p></div>
           <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        </div>

      <div class="row-box">
        <div class="box">
          <div class="content content-enable cursor-none"><p class="para-cont">Obtain purchase order for non-IT expenditure over $2500 CAD and all IT expenditure</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('All fully signed contractual documents will be filed by Corporate Procurement in digital formats.')">
          <div class="content content-enable"><p class="para-cont">Digitally file contractual documents</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Performance of suppliers shall be monitored and measured at planned intervals to ensure delivery to contractual obligations and service level agreements.')">
          <div class="content content-enable"><p class="para-cont">Performance of suppliers shall be monitored and measured</p></div>
        </div>
        </div>
</div>
</div>

    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span> </div>
      <div class="ult-links"><h4>Useful links</h4>
      <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/ethics-compliance/services-responsibilities/supplier-code-of-conduct.aspx" target="_blank">Supplier Code of Conduct</a>
      <a href="https://km.snclavalin.com/pdce/Global/1554-procurement-en.pdf" target="_blank">Procurement of Goods and Services Policy </a>
      <a href="https://km.snclavalin.com/pdce/Functional/2P-AG-010%20Procurement%20Management%20FINAL.pdf" target="_blank">Procurement Management Procedure</a>
      <a href="https://km.snclavalin.com/pdce/Functional/2P-AG-200%20Purchasing%20Management%20EN%20FINAL.pdf" target="_blank">Purchasing Management Procedure</a>
      <a href="https://km.snclavalin.com/pdce/Functional/Vendor%20Integrity%20Verification%20SOP%202P-AG-050%20FINAL.pdf" target="_blank">Vendor Integrity Verification Procedure</a>
      </div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>

    </div>
</div>
</div>
<!-- Main content Container section end here -->

</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions } from "vuex";
export default {
  name: "EnableCorporateProcurementcomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
   methods: {
        ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>