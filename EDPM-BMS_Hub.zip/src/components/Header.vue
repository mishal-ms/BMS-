<template>
<div>
    <div v-if="showpopup" style="position:fixed;top:0px;left:0px;width:100%;height:100%;background-color:#000000cc;z-index: 1000;">
        <div style="position:relative; width:830px;min-height:100px;margin:300px auto 0px auto;background:#fff;border-radius:4px;padding:24px 24px; line-height:20px">
            <h1><b style="font-size:20px;font-weight:bold;">Additional Detail</b> <span style="display:inline-block;float:right;"><i class="fas fa-times-circle" v-on:click="hide();"></i></span></h1>
            <br/>
            <p>{{this.popupcontent}}</p>
        </div>
    </div>
    <header class="content-row bg01 pos-fix" id="myHeader">
        <div class="content-wt header-sty">
            <div class="logo-text">
                <h1><a href="https://atkins.sharepoint.com/sites/BMSHub/html/index.aspx?sw=bypass#/" style="">Engineering Services BMS Hub</a></h1>
            </div>
            <div class="snc-logo" >
                <img src="../assets/images/snc-logo.png" width="100" height="auto" alt="snc logo" />
            </div>
        </div>
    </header>

    <div class="clear-fix"></div>

    <div class="header-content content-row bg bg02">
        <!-- search and content section start from here -->
        <div class="content-wt">
            <div class="srch-content">
                <!-- <div class="search-box">
                <input type="search" name="search" placeholder="Search the BMS Library" id="search">
                <label class="d-none" for="search">Search</label>
                <span class="search-btn"><i class="fas fa-search search-icon-posi"></i></span>
            </div> -->
                <div class="hrd-content">
                    <p>
                        The BMS Hub details processes aligned to Corporate and Sector
                        requirements across the four key process areas describing how we
                        lead our business, win and deliver our projects and how we enable
                        their success through our supporting functions. Our BMS is
                        certified to ISO9001; ISO45001; and ISO14001. The BMS draws on the
                        requirements of these external standards; our corporate
                        requirements and sector standards and provides the controls which
                        enable us to predictably deliver a quality outcome to our clients
                        whilst keeping everyone safe, healthy and well and protecting the
                        environment we work within. The BMS is aimed at supporting leaders
                        at all levels of our business to understand their obligations,
                        know what is expected and ensure their teams conform to these
                        requirements.
                    </p>

                    <p>
                        We aim to continually learn from our experience and improve so if
                        you have any feedback or suggestions to enhance the BMS Hub please
                        follow the link in the footer.
                    </p>
                </div>
            </div>
            <!-- search and content section end here -->

            <!-- project different stage section(with arrow) start from here -->
            <div class="arrow-procss-sect">
                <div class="arrow-cont"></div>
                <div class="num-bx-wrapper">
                    <div class="box-num-text">
                        <a href="https://atkins.sharepoint.com/sites/CommercialHub/html/index.aspx#/theme/service-delivery-process">Service Delivery Process</a>
                    </div>
                    <div class="box-num">
                        <a href="#" title="Takes place as soon as decision is made to pursue an opportunity. This should always be prior to any teaming JV or other agreements; commitments to bid" class="num">1</a>
                    </div>
                    <div class="box-num">
                        <a href="#" title="Takes place once tender or procurement documentation has been received or when the client requirements and initial submission process are known." class="num">1a</a>
                    </div>
                    <div class="box-num">
                        <a href="#" title="Takes place once the initial bid documentation is prepared and the delivery methodology is defined but prior to submission." class="num">1b</a>
                    </div>
                    <div class="box-num">
                        <a href="#" title="Takes place following the award of contract prior to contract signature and/or commencement of services." class="num">2</a>
                    </div>
                    <div class="box-num">
                        <a href="#" title="Takes place within 30 days of contract signature or commencement of services (whichever the earliest)." class="num">3</a>
                    </div>
                    <div class="box-num">
                        <a href="#" title="Periodic Reviews : Takes place on regular basis during the project to review the performance and identify any opportunities for enhancing delivery outcomes; typically 6 monthly

Significant Change: Takes place upon awareness of a significant change or on the request of a senior member of the business" class="num">3a</a>
                    </div>
                    <div class="box-num">
                        <a href="#" title="Takes place following contractual and financial completion of the project. SG4 shall be conducted for all Red Zone, Amber Frameworks of 3* years and any Amber Zone project with cumulative value > ￡5m (or equivalent local currency)" class="num">4</a>
                    </div>
                </div>
            </div>
            <!-- project different stage section(with arrow) end here -->

            <!-- project different stage section(diamond shape) end here -->

            <!-- win work delivery work outline button section start from here -->
            <div class="wn-dl-pr-cont">
                <a class="wn-wrk-btn" href="#/WinWorkAllSteps">Win work</a>
                <a class="dl-wrk-btn" href="#/DeliverWorkAllSteps">Deliver work</a>
            </div>
            <!-- win work delivery work outline button section end here -->

            <!-- Project stage button section start from here -->
            <div class="pr-stage-sect">
                <a id="hoverEft" href="#/ExploreTheMarket" class="fl-ctrl-btn">Functional Controls</a>
                <a id="hoverEftLd" href="#/ExploreTheMarket" class="lead-btn">Lead</a>
                <a id="hoverEftexp" href="#/WinWorkFirstTab" class="exp-btn">Explore the Market</a>
                <a id="hoverEftDlp" href="#/WinWorkSecondTab" class="dl-op-btn">Develop the Opportunity</a>
                <a id="hoverEftBd" href="#/WinWorkThirdTab" class="bid-btn">Bid it &<br />Win it</a>
                <a id="hoverEftSt" href="#/DeliverWorkStartJobTab" class="start-jb-btn">Start the<br />Job Right</a>
                <a id="hoverEftDo" href="#/DeliverWorkDoJobTab" class="do-jb-btn">Do the<br />Job Right</a>
                <a id="hoverEftFn" href="#/DeliverWorkFinishJobTab" class="fn-jb-btn">Finish the<br />Job Right</a>
                <a id="hoverEftLdEn" href="#/ExploreTheMarket" class="enble-btn">Enable Our Success</a>
            </div>
            <!-- Project stage button section end here -->
        </div>
    </div>
</div>
</template>

<script>
import api from "@/service";
import router from "@/router";
import {
    mapActions,
    mapGetters
} from "vuex";
export default {
    name: "HeaderComp",

    data() {
        return {
            // showpopup: false,
        };
    },
    computed: {
        ...mapGetters(["showpopup","popupcontent"]),

        //   ...mapGetters(["subStages", "stages", "header"]),
        //   completeStagesInfo() {
        //     let array = [];
        //     this.subStages.forEach((subStage) => {
        //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
        //       subStage.Stage = stage;
        //       array.push(subStage);
        //     });
        //     return array;
        //   },
        //   searchRes() {
        //     if (this.sr) {
        //       return this.completeStagesInfo.filter((post) => {
        //         if (post.Title) {
        //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
        //         }
        //       });
        //     }
        //   },
    },
    methods: {
        ...mapActions(["UPDATE_SHOW_POPUP"]),
        // show() {
        //     this.UPDATE_SHOW_POPUP(true);
        // },
        hide() {
            this.UPDATE_SHOW_POPUP(false);

        },
    },
    // watch: {
    //   $route(to, from) {
    //     // Reset Search If route changes
    //     // this.search = false;
    //     // this.searchText = '';
    //     // this.searchResults = [];
    //   },
    // },
};
</script>
