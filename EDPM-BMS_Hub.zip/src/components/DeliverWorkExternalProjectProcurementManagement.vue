<template>
  <div>
    <!-- Main content Container section start from here -->
    <div class="cont-container">
      <div class="content-wt">
        <div class="content-hd-text">
          <h2>External Project Procurement Management</h2>
          <p>
            When we engage the supply chain in support of the delivery of a
            project, we remain responsible for the quality and performance of
            the goods and / or services supplied, as if they were provided by
            ourselves. We must ensure all third party goods and / or services
            are procured from a reputable supply chain, and to the standards and
            requirements set out by both our clients and ourselves
          </p>
        </div>
        <div class="tabs">
          <button
            class="tab-link active"
            
          >
            Requirements
          </button>
          <!-- <button class="tab-link" >
            Additional Detail
          </button> -->
          <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button>  -->
        </div>
        <div class="row-content">
          <div class="col-9">
            <div class="card-wrap">
              <div class="row-box">
                <div class="box">
                  <div class="content bg-fst-chld cursor-none">
                    <p class="para-cont">
                      Document proposed procurement need in a plan
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box">
                  <div class="content bg-fst-chld cursor-none">
                    <p class="para-cont">
                      Identify approved suppliers in line with procurement plan
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box">
                  <div class="content bg-fst-chld cursor-none">
                    <p class="para-cont">
                      Consider commercial risk and ensure relevant protection in
                      place
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box">
                  <div class="content bg-fst-chld cursor-none">
                    <p class="para-cont">
                      Engage suppliers to obtain budgetary pricing
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-rt">
                  <div class="content bg-fst-chld cursor-none">
                    <p class="para-cont">
                      Conduct formal handover meeting between proposal manager,
                      PD and PM
                    </p>
                  </div>
                </div>
              </div>

              <div class="row-reverse">
                <div class="box">
                  <div class="content bg-snd-chld cursor-none">
                    <p class="para-cont">
                      Review and document procurement requirements
                    </p>
                  </div>
                </div>
                <div class="box">
                  <div class="content bg-snd-chld cursor-none">
                    <p class="para-cont">
                      Document Procurement Plan as part of the Project
                      Management Plan
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box">
                  <div class="content bg-snd-chld cursor-none">
                    <p class="para-cont">Approve competent supplier(s)</p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box">
                  <div class="content bg-snd-chld cursor-none">
                    <p class="para-cont">
                      Agree criteria for the evaluation of tenders
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-lt">
                  <div class="content bg-snd-chld cursor-none">
                    <p class="para-cont">
                      Complete purchase requisition (or equivalent as required)
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
              </div>

              <div class="row-box">
                <div class="box">
                  <div class="content bg-snd-chld cursor-none">
                    <p class="para-cont">
                      Complete tender process in line with documented plan
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box">
                  <div class="content bg-snd-chld cursor-none">
                    <p class="para-cont">Select preferred supplier</p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box">
                  <div class="content bg-snd-chld cursor-none">
                    <p class="para-cont">
                      Agree formal contract with supplier in line with LOA
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box">
                  <div class="content bg-snd-chld cursor-none">
                    <p class="para-cont">
                      Document Contract Administration plan
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-lt">
                  <div class="content bg-th-chld cursor-none">
                    <p class="para-cont">
                      Documented evidence from supplier received and contract
                      accepted
                    </p>
                  </div>
                </div>
              </div>

              <div class="row-reverse">
                <div class="box">
                  <div class="content bg-th-chld cursor-none">
                    <p class="para-cont">
                      Conduct contract mobilization meeting with supplier
                    </p>
                  </div>
                </div>
                <div class="box">
                  <div class="content bg-th-chld cursor-none">
                    <p class="para-cont">
                      Monitor and review supplier performance and progress in
                      accordance with contract administration plan
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box">
                  <div class="content bg-th-chld cursor-none">
                    <p class="para-cont">
                      Manage change in accordance with the provisions of the
                      contract and in line LoA
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box">
                  <div class="content bg-frth-chld cursor-none">
                    <p class="para-cont">
                      Confirm services / goods delivered by supplier
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-lt">
                  <div class="content bg-frth-chld cursor-none">
                    <p class="para-cont">
                      Evaluate and document supplier performance as part of
                      Project closure
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
              </div>

              <div class="row-box">
                <div class="box">
                  <div class="content bg-frth-chld cursor-none">
                    <p class="para-cont">
                      Conduct end of project review in line with Project
                      Management Plan
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
   <!-- <RightInformationPannel/> -->

          <div class="col-3">
            <div class="content-box">
              <div class="own-detail">
                <span
                  >Process Owner:
                  <strong class="bld-txt">Nick Welch</strong></span
                >
                <!-- <span
                  >Key Contact:
                  <strong class="bld-txt">Joann Clarke</strong></span
                > -->
              </div>
              <div class="ult-links">
                <h4>Useful links</h4>
                <a href="https://atkins.sharepoint.com/sites/dwh/html/index.aspx?OR=Teams-HL&CT=1649844968359&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjA0MDExMTQwMCJ9#/" target="_blank">Deliver Work Hub</a>
                <a href="https://atkins.sharepoint.com/sites/ESMS/SitePages/Glossary.aspx?OR=Teams-HL&CT=1649852129464&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjAzMjEwMDEwNyJ9" target="_blank">Glossary</a>
                <a href="">LoA Policy</a>
                 <a href="https://km.snclavalin.com/pdce/_layouts/15/WopiFrame2.aspx?sourcedoc=/pdce/Global/supplier-code-of-conduct-en.pdf&action=default&DefaultItemOpen=1" target="_blank">Supplier Code of Conduct</a> 
                 <a href="https://atkins.sharepoint.com/sites/CommercialHub/html/index.aspx#/" target="_blank">Commercial Hub</a>
                 <a href="https://km.snclavalin.com/pdce/Functional/2P-AG-100%20Subcontract%20administration%20FINAL.pdf" target="-blank"> SNC-L Subcontract Management Procedure</a>
              </div>
              <!-- <div class="ult-links">
                <h4>Training</h4>
                <a>None</a>
              </div> -->
              <div class="ult-links">
                <h4>Approved Deviations</h4>
                <a>None</a>
              </div>
            </div>
          </div> 
        </div>
      </div>
    </div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapActions } from "vuex";
// import RightInformationPannel from "../components/RightInformationPannel.vue";
export default {
  name: "DeliverWorkExternalProjectProcurementManagementComp",
  // components: {RightInformationPannel}
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  methods: {
    ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>