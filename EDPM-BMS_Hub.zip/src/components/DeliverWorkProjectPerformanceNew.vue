<template>
    <div> 

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Project Performance</h2>
      <p>Monitoring project performance is essential in ensuring the project is delivering in line with expectations and in line with the project plan. It includes recognizing and identifying issues or problems that might arise during the project’s execution, to enable prompt action to be taken to rectify and enhance overall project performance. It is about monitoring predictability of delivery, understanding any variances, and therefore providing confidence in the overall project performance.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkProjectPerformance';">Requirements</button>
    <button class="tab-link active"> Additional Detail</button>
     <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button>  -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Identify proposal assumptions and exclusions aligned to proposal baseline reference levels</h4>
  <p>The PD and PM shall be identified when the procurement document is received. They should support the development of the proposal and be included in a kick off with the pursuit team. Key client requirements and objectives shall inform project expectations and ultimately project performance indicators.</p>
  <h4>Conduct formal handover meeting between proposal manager, PD and PMs</h4>
  <p>Project manager shall ensure that they have a complete set of proposal related materials including contract, issued proposal, proposal risk register, commercial data, client drivers, aspirations, expectations and other pertinent information.</p>
  <h4>Establish project baseline reference levels to monitor and control the project</h4>
  <p>Setting the right level of project baseline is an essential prerequisite for a successful project. The baseline is the reference levels against which a project, program or portfolio is monitored and controlled.
    The MPU Baseline Process should be used on all projects proportionally. As a minimum cost, schedule, resource and deliverables baselines shall be established to enable monitoring and control of the project. For all projects meeting the Major Projects criteria the 7 MPU baseline elements shall be established.
    Projects shall establish appropriate project KPIs to monitor performance against baselines over the lifecycle of the project.</p>
  <h4>Document Project Management Plan, aligned to project risk categorization</h4>
  <p>The Project Management Plan (PMP) brings together all the plans for a project. The purpose of the project management plan is to document the outcomes of the planning process and to provide the reference document for managing the project. 
    The PMP sets the objectives and requirements for which the project will be reviewed and assessed against. It's the foundations for defining appropriate project KPIs. The PMP should be proportionate to the size, scale and complexity of the project.</p>
  <h4>Formally mobilize project and share project baseline reference levels </h4>
  <p>Mobilizing the project shall be planned and delivered in a timely manner, including team members from other divisions or business units and external third party suppliers to clearly communicate the requirements laid out in the PMP. The mobilization shall include performance indicators and reporting and be evidenced by project team members confirming they have read and understood the PMP.</p>

  <h4>Hold project progress meetings with key members of the project team in line with the Project Management Plan</h4>
  <p>The requirement for project progress meetings shall be defined in the Project Management Plan and will be proportionate to the size, scale and complexity of the project. Progress shall be monitored against project baselines including time, cost, quality and technical. Project Technical Reviewers and Technical Review Team shall undertake technical reviews during delivery phase at key milestones or dates as required by the Project Technical Reviewer
    Learning from the reviews shall be captured and fed back to the project team to inform improvements in project performance.</p>

  <h4>Conduct regular Project Reviews as defined in the Project Management Plan</h4>
  <p>The PD shall conduct a project review with the PD, in line with the size, scale and complexity of the project, to ensure the project is delivering to the plan and to agree the project is being managed effectively. Recommended actions should be documented and monitored to closure, to inform project improvements.</p>

  <h4>Provide progress updates to key stakeholders in line with PMP</h4>
  <p>The requirement and frequency of engagement with internal and external stakeholders shall be defined in the Stakeholder Management Plan and shall be proportionate to the size, scale and complexity of the project. It is important progress update meetings are delivered in a timely manner, in line with contractual obligations and sufficient to keep all interested parties up to date and engaged in the project.</p>
  <h4>Share key learning with Project Team </h4>
  <p>Feedback from project performance reviews, the client, technical reviews and audits shall be shared with the project team, during the lifecycle of the project, to inform and drive improvements.</p>
  <h4>Review and update Project Management Plan to reflect project delivery</h4>
  <p>The PMP is a dynamic document which needs to be relevant to the actual project delivery requirements. The PM shall review and update the PMP to reflect agreed changes, risks and opportunities and the associated impact on project performance measures.</p>
  <h4>Measure and document client satisfaction during delivery in line with Stakeholder Management Plan</h4>
  <p>Project performance feedback shall be sought and received from the client at relevant milestones during project delivery. This should include both overall project performance and feedback on individual technical performance.</p>

  <h4>Measure client satisfaction post delivery in line with Stakeholder Management Plan</h4>
  <p>It is important to understand client satisfaction on the overall performance of the project. Feedback received during the lifecycle of the project should be reviewed and final feedback sought once the project is substantially closed. It should be carried out immediately prior to demobilization of project resources to capture the wider team perspective. The feedback shall be used to collate and share learning on the project to inform future projects. 
    It should be carried out immediately prior to demobilization of project resources to capture the wider project team perspective.</p>

  <h4>Conduct End of Project Review</h4>
  <p>A review of project performance shall be undertaken, which may include complaints, good practice, management of risks, client feedback, successes and failures, technical innovations, staff performance and learning from the project. This information should be collated and documented to enable the sharing of learning  with future projects. All relevant project documentation shall be archived in line with contractual obligations and in line with PMP. 
    For qualifying projects under the gated Process a formal independent gated review shall be conducted and documented.</p>
</div>
</div>
</div>  
</div>
<!-- Main content Container section end here -->




</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "DeliverWorkProjectPerformanceNewComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>