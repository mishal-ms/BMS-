<template>
    <div>


<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
  <div class="tabs">
   <button class="tab-link" onclick="window.location.href='#/DeliverWorkAllSteps';">All</button>
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkStartJobTab';">Start the Job Right </button>
    <button class="tab-link active" onclick="window.location.href='#/DeliverWorkDoJobTab';">Do the Job Right </button>
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkFinishJobTab';">Finish the Job Right  </button>
</div>
  
 <div class="cont-row-wrapper mt">
    <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProposalHandover';"><div class="outline-cont-dl"><p>Proposal Handover</p></div></div>
   <div class="scroll-area-sgl">
   <ul class="list-box-dl">
      
      </ul>
    </div>
    </div>
    
<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectPlanning';"><div class="outline-cont-dl"><p>Project Planning</p></div>
 </div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="third-child-dl">Formally mobilise the project, appropriate to the project risk, scale & complexity </div></li>
     <li><div class="third-child-dl">Manage project delivery in line with the Project Management Plan </div></li>
     <li><div class="third-child-dl">Review, measure and monitor project performance against the Project Management Plan</div></li>
    </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectFinancialManagement';"><div class="outline-cont-dl"><p>Project Financial Management</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="third-child-dl">Formally mobilise project informing the project team of key project financial controls</div></li>
     <li><div class="third-child-dl">Assign budgets to discipline leads and interdivisional </div></li>
     <li><div class="third-child-dl">Monitor and review project costs against financial plan </div></li>
     <li><div class="third-child-dl">Review and update Project Summary Report monthly</div></li>
     <li><div class="third-child-dl">Invoice client against agreed payment terms in line with contractual requirements </div></li>
  </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverworkProjectMobilisation';"><div class="outline-cont-dl"><p>Project Mobilization</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="third-child-dl">Formally mobilise the project involving the project team </div></li>
     <li><div class="third-child-dl">Evidence project team have read and understood Project Management Plan</div></li>
    </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectRiskManagement';"><div class="outline-cont-dl"><p>Project Risk Management </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="third-child-dl">Formally mobilise project and share project risks with the project team </div></li>
     <li><div class="third-child-dl">Manage and review project risk register in line with the Project Management Plan</div></li>
     <li><div class="third-child-dl">Review and update risk register; identify new risks, review existing risks, analyse and evaluate all.</div></li>
     <li><div class="third-child-dl">Communicate any changes and actions to risk register to relevant stakeholders</div></li>
     <li><div class="third-child-dl">Treat risks</div></li>
 </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectInfoManagement';"><div class="outline-cont-dl"><p>Project Info Management</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
    <li><div class="third-child-dl">Formally mobilise project and share the Project Information Management plan with the project team</div></li>
     <li><div class="third-child-dl">Undertake information management assurance checks</div></li>
     <li><div class="third-child-dl"> Undertake reviews of information management approach as defined in Project Management Plan</div></li>
     <li><div class="third-child-dl">Update as required the information management approach following review</div></li>
     <li><div class="third-child-dl">Hand over information to client and confirm acceptance </div></li>
 </ul>
</div>
</div>
<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkClientSatisfaction';"><div class="outline-cont-dl"><p>Client Satisfaction </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="third-child-dl">Formally mobilise project outlining client requirements in line with Stakeholder Management plan </div></li>
     <li><div class="third-child-dl">Manage scope of services in line with Project Management Plan</div></li>
     <li><div class="third-child-dl">Measure and document client satisfaction as defined in the Project Management Plan</div></li>
     <li><div class="third-child-dl">Share key learning with Project Team</div></li>
     </ul>
</div>
</div>
<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkTechnicalAssurance';"><div class="outline-cont-dl"><p>Technical Assurance</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
    <li><div class="third-child-dl">Formally mobilise project and  evidence understanding of scope, schedule and technical assurance expectations</div></li>
     <li><div class="third-child-dl">Fully brief check, review and authorisers on key criteria for review</div></li>
     <li><div class="third-child-dl">Programme all technical assurance activities, including check and review</div></li>
     <li><div class="third-child-dl">Monitor progress and impact of delivery to technical assurance as part of planned project reviews</div></li>
     <li><div class="third-child-dl">Capture, document and ensure closure of actions resulting from reviews of deliverables, including check and review </div></li>
     <li><div class="third-child-dl">Proactively manage, assess and record change and risks on appropriate registers</div></li>
     <li><div class="third-child-dl">Seek and document client satisfaction in line with Project Management Plan, aligned to key milestone deliverables</div></li>
     <li><div class="third-child-dl">Share key learning from project reviews and client feedback with project team </div></li>
     <li><div class="third-child-dl">Check, review and authorise all deliverables in line with the Project Management Plan prior to issuing to any external parties </div></li>
     <li><div class="third-child-dl">Document and control all information shared with the client in line with Project Management Plan </div></li>
</ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectPerformance';"><div class="outline-cont-dl"><p>Project Performance </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="third-child-dl">Formally mobilise project and share project baseline reference levels </div></li>
     <li><div class="third-child-dl">Hold project progress meetings with key members of the project team in line with the Project Management Plan</div></li>
     <li><div class="third-child-dl">Conduct regular Project Financial Reviews as defined in the Project Management Plan</div></li>
     <li><div class="third-child-dl">Provide progress updates to key stakeholders in line with PMP</div></li>
     <li><div class="third-child-dl">Share key learning with Project Team </div></li>
     <li><div class="third-child-dl">Review and update Project Management Plan to reflect project delivery</div></li>
     <li><div class="third-child-dl">Measure and document client satisfaction during delivery in line with Stakeholder Management Plan</div></li>
</ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectChangeControl';"><div class="outline-cont-dl"><p>Project Change Control</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="third-child-dl">Inform Project Team of the change management plan as part of Project Mobilization</div></li>
     <li><div class="third-child-dl">Regularly review known changes and consider potential changes  </div></li>
     <li><div class="third-child-dl">Update change register to reflect potential and agreed changes</div></li>
     <li><div class="third-child-dl">Review and gain agreement for changes with the client</div></li>
     <li><div class="third-child-dl">Approve all changes in line with the gated approval process where required</div></li>
     <li><div class="third-child-dl">Quantify and assess the impact of changes against the project baseline</div></li>
     <li><div class="third-child-dl">Formally communicate the impact of the change to the project team</div></li>
     <li><div class="third-child-dl">Update project forecast to reflect changes </div></li>
     <li><div class="third-child-dl">Invoice changes as per contractual terms  </div></li>
  </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkExternalProjectProcurementManagement';"><div class="outline-cont-dl"><p>External Project Procurement Management </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
    <li><div class="third-child-dl"> Documented evidence from supplier received and contract accepted   </div></li>
     <li><div class="third-child-dl">Conduct contract mobilization meeting with supplier </div></li>
     <li><div class="third-child-dl">Monitor and review supplier performance and progress in accordance with contract administration plan  </div></li>
     <li><div class="third-child-dl">Manage change in accordance with the provisions of the contract and in line LoA</div></li>
</ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectClosure';"><div class="outline-cont-dl"><p>Project Closure</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
      <li><div class="third-child-dl">Define approach to capture learning from the project as part of the Project Management Plan</div></li>
     <li><div class="third-child-dl">Document project archive requirements as part of Project Management Plan</div></li>
     <li><div class="third-child-dl">Identify and plan for anticipated project closure date</div></li>
</ul>
</div>
</div>
</div>
</div>
<!-- Main content Container section end here -->




</div>

</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "DeliverWorkDoJobTabComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>