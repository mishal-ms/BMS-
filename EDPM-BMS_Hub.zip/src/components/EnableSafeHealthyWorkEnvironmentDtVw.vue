<template>
  <div>
    <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Safe & Healthy Work Environment</h2>
      <p>A safe and healthy work environment doesn’t just happen—it’s created by working together. A safe and healthy work environment is good for worker health, safety and wellbeing, business sustainability and the economy. The work environment is more than the physical surroundings. It includes the way that you do your work, the materials and equipment that you work with and also the emotional and psychological demands on workers.</p>
  </div>
  <div class="tabs">
        <button class="tab-link" onclick="window.location.href='#/EnableSafeHealthyWorkEnvironment';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='#/EnableSafeHealthyWorkEnvironmentDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Establish Sector Health, Safety Environmental & Wellbeing objectives </h4>
  <p>Health, Safety, Environment and Wellbeing objectives shall comply and be consistent with SNCL annual HSE Objectives</p>
  <h4> Identify competent resource to lead H&S</h4>
  <p>The business shall identify a suitable H&S lead. This should be a competent resource. In the absence of a competent resource, suitable support shall be provided (i.e., supervision, mentoring, checking / review)</p>
  <h4>Establish annual Health, Safety, Environmental and Wellbeing goals</h4>
  <p>HSEW performance will be used to establish annual Health, Safety, Environment and Wellbeing HSE goals to focus on specific areas of risk and opportunities for improvement.  
HSEW Performance (leading and lagging) will be recorded and reviewed throughout the year</p>
  <h4>Identify needs and expectations of relevant internal and external interested parties</h4>
  <p>As part of business planning, the sector and regions shall identify the needs and expectations of relevant internal and external interested parties having an interest in HSE performance.</p>
 <h4> Create and maintain an HSE business risk register</h4>
  <p>A HSE risk assessment shall be completed and appropriate controls identified for all business activities.</p>

   <h4>Embed and conform to HSE Blue Book requirements </h4>
  <p>Any Blue Book requirements that cannot be reasonably achieved shall be subject to the SNC-L deviation procedure and require appropriate approval. 
Corrective actions from audits and recordable / HiPo incidents must be entered in BlueSky within timescales stated in the Blue Book.  Corrective actions shall be implemented in a timely manner.</p>

  <h4> Establish a H&S Committee</h4>
  <p>Outputs of the HSE Committee and associated meetings shall be documented. Relevant HSE information shall be communicated to all applicable employees.</p>

  <h4>Report and review HSE incidents</h4>
  <p>All recordable incidents must be entered into BlueSky within 24 hours of occurrence. 
All recordable and HiPo incidents shall be reported to the President and CEO within 24 hours of occurrence.
For all HiPo incidents, a regional conference call must be held within 96 hours to discuss the condition of those impacted. A record of this call shall be retained.</p>

  <h4> Maintain a healthy workforce</h4>
  <p>Relevant health and wellbeing support and  guidance shall be made available internally and via an external Employee Assistance Programme (EAP). Employee engagement shall be undertaken to ensure wellbeing concerns are shared and appropriate improvement plans are established.</p>


</div>
</div>
  
  </div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "EnableSafeHealthyWorkEnvironmentDtVwComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>