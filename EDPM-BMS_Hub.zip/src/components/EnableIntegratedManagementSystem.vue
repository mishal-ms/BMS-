<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
    <div class="content-wt">
    <div class="content-hd-text">
      <h2>Integrated Management System</h2>
      <p>Management Systems are systematic frameworks designed to manage an organization's policies, procedures and processes and promote continual improvement within.  The implementation of a proven and effective Management System can help a business to improve operations, manage risk and promote stakeholder confidence.  A management system allows us to meet challenges by instilling good practice and validating, through certification we have a recognized and effective system to comply with client and external requirements; to protect the organization by embedding quality best practices and to grow our organization by extending our client reach and satisfaction. </p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/EnableIntegratedManagementSystemDtVw';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/EnableIntegratedManagementSystemDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <div class="row-box">
        <div class="box" v-on:click="show('A suitably competent person shall be identified to develop, manage and maintain an effective mangement system which documents core controls we expect everyone to follow.')">
          <div class="content content-enable"><p class="para-cont">Establish, implement and maintain a management system</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('The boundaries and applicability of the management system shall be established to determine its scope The scope of the management system shall be documented and communicated to all relevant parties. When determining scope the organization shall consider: a) the external and internal issues b) requirements of relevant interested parties c) products and services of the organization.')">
          <div class="content content-enable"><p class="para-cont">Document and publish the scope of the management system</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('The management system shall align to International standards; ISO9001; ISO14001 & ISO45001 and should consider all relelvant international standards which are applicable to the scope of the system. Relevant controls need to be identified and managed to ensure compliance to relevant ISO standards and enable external certification.')">
          <div class="content content-enable"><p class="para-cont">Define and document controls and processes needed to meet ISO requirements</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('All changes or deviations to a process need to be managed through the formal change and deviation procedure. Any changes to the management system shall be sponsored by the relevant process owner and approved by the BMS Steering Committee.')">
          <div class="content content-enable"><p class="para-cont">Document a change and deviation procedure</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt" v-on:click="show('An assurance programme shall be developed to enable conformance to the core controls documented on the BMS to be measured and monitored. Audit outcomes, including findings, will be documented and actions managed to closure.')">
          <div class="content content-enable"><p class="para-cont">Define an annual internal audit programme to measure conformance to the management system</p></div>
          </div>
      </div>
    

<div class="row-reverse-last-child">
  <div class="box" v-on:click="show('An annual sector management review shall be conducted to review the performance and effectiveness of the management system. It shall be documented, along with any actions identified to improve the effectiveness and relevance of the system. All actions shall be managed to closure. A regional mangement review should take place to inform the sector management review.')">
    <div class="content content-enable"><p class="para-cont">Conduct an annual management review at sector level  </p></div>
  </div>
  <div class="box" v-on:click="show('To ensure the ongoing alignment of the management system to ISO standards, client expectations and internal changes the management system shall be internally audited at least once every 3 years.')">
    <div class="content content-enable"><p class="para-cont">Conduct an internal system audit of the management system at least once every 3 years</p></div>
    <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
  </div>
</div>
  </div>
</div>

    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span></div>
      <div class="ult-links"><h4>Useful links</h4>
        <a href="https://atkins.sharepoint.com/sites/ESMS/SitePages/Certification.aspx" target="_blank">Management System certificates</a>
        <a href="https://km.snclavalin.com/pdce" target="_blank">Capability Hub</a>
        <a href="">Atkins Standards Page</a>
        <a href="https://atkins.sharepoint.com/sites/ESMS/SitePages/Deviation.aspx" target="_blank">BMS Hub Deviation Procedure </a>
        <a href="https://atkins.sharepoint.com/sites/ESMS/SitePages/Change.aspx" target="_blank">BMS Hub Change Procedure  </a>
      </div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>
</div>
</div> 
</div>
<!-- Main content Container section end here -->


</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions} from "vuex";
export default {
  name: "EnableIntegratedManagementSystemComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
   methods: {
        ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
   },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>