<template>
  <div>
    <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>External Compliance</h2>
      <p>External Compliance is important to ensure integrity, safety, and ethical behavior in business. External compliance involves following external legal mandates set forth by state, federal, or international government, regulations, codes, standards or client requirements. </p>
  </div>
  <div class="tabs">
        <button class="tab-link" onclick="window.location.href='#/EnableExternalCompliance';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='#/EnableExternalComplianceDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Identify Subject Matter Expert to be accountable for each relevant service or function</h4>
  <p>Each function or business unit shall identify a relevant subject matter expert who is accountable for the identification, management and review of applicable external compliance within their defined scope of control. </p>
  <h4> Identify, record and maintain a regional register of compliance obligations for each service or function</h4>
  <p>Each function or business unit shall document external compliance requirements on a register which is accessible and available to those required to operate with in the identified requirements. The register should document specific owners, audience and scope of the requirement.</p>
  <h4>Define controls required to manage compliance requirements</h4>
  <p>The subject matter experts will identify and document any controls required to ensure compliance to external requirements. </p>
  <h4> Review compliance register annually</h4>
  <p>Each register shall be reviewed at least annually to ensure it is relevant, up to date and includes all requirements</p>

  <h4> Assure compliance to identified controls</h4>
  <p>Each function or region shall ensure an appropriate assurance programme is in place to measure and monitor both conformance to controls and the effectiveness of each control in ensuring compliance to external requirements.</p>


</div>
</div>
  
  </div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "EnableExternalComplianceDtVwComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>