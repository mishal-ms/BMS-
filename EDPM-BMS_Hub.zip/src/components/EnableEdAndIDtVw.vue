<template>
  <div>
    <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Equality Diversity And Integraty</h2>
      <p>Given the right environment every person has the opportunity to contribute to creating a workplace where people can feel valued, listened to and cared about. Creating an inclusive environment will enable our organization to tap into a diverse strong talent pool, better serving our diverse client base and leading to better business outcomes.  </p>
  </div>
  <div class="tabs">
       <button class="tab-link" onclick="window.location.href='#/EnableEdAndI';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='#/EnableEdAndIDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4> SNC-L ED&I Strategy to provide the framework for sector plans </h4>
  <h4> Everyone shall be treated with dignity and respect  </h4>
  <h4>Create inclusive networks</h4>
  <p>Create and support ED&I networks where there is employee need and alignment to the ED&I strategy </p>
  <h4>Foster a culture of openness  </h4>
  <p>Everyone is supported to speak up if they see or hear something that contradicts the standards of behaviour set out in the code of conduct</p>

  <h4> Develop a clear set of HR policies which support the ED&I Strategy</h4>
  <p>Develop supportive policies and procedures which reflect the differing needs of diverse groups.</p>
  <h4> Provide training and awareness to support an inclusive culture</h4>
  <h4>Adopt a fair, objective and inclusive recruitment and selection process</h4>
</div>
</div>
</div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "EnableEdAndIDtVwComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>