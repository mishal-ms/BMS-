<template>
    <div>
        <div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Security</h2>
      <p>SNC-Lavalin is a multinational company operating in numerous countries worldwide, with offices on every continent. This diversity is our strength and our pride, but in a world of constant change, it also exposes us to many potential threats in regions with diverse realities. In the course of our operations, we must always be aware of risks to ensure the security of our employees, assets and reputation.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/EnableSecurity';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/EnableSecurityDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>

  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <div class="row-box-enable-wk">
            <div class="wrapper-cont"><h2>Personnel security</h2>
            <div class="box-wth-notxt">
              <div class="content content-enable-wdth"  v-on:click="show('The Deep Dive Security Assessment (DDSA) will be carried out by Global Security and shall identify risks, vulnerabilities and mitigation measures to be implemented if the project is awarded to Engineering Services.')">
                <p class="para-cont">Consult Global Security for a Deep Dive Security Assessment for all new bids in high-risk, extreme-risk and some specific-risk locations.</p></div> <div class="line-img-last-chd"><img src="../assets/images/link-line.png" /></div>
              <div class="content content-enable-wdth"  v-on:click="show('Prepare a Travel Security Plan for all employees travelling on business to a high, extreme risk and/or specific travel location.')">
              <p class="para-cont">Documented Travel Security Plan for high-risk locations</p></div> <div class="line-img-last-chd"><img src="../assets/images/link-line.png" /></div>
                <div class="content content-enable-wdth"  v-on:click="show('Global Security shall be consulted in advance of major high-risk company events and shall produce a Special Events Security Plan (SESP).')">
                  <p class="para-cont">Consult Global Security for major high-risk company events.</p></div> 
            </div> 
          </div>
        </div>

            <div class="row-box-enable-wk">
              <div class="wrapper-cont"><h2>Physical security</h2>
              <div class="box-wth-notxt">
                <div class="content content-enable-box-cust"  v-on:click="show('Ensure that appropriate physical measures are in place at offices that are commensurate to the specific threats and risks. A physical security assessment shall be carried out using the Security Assessment Vetting (SAV) process for all facilities. For new facilities this shall be carried out prior to moving in. A written SAV report shall be produced indicating vulnerabilities and mitigation measures which shall be implemented by local management. Employees operating inside a client or third-party property shall adhere to the security arrangements belonging to the client or third party.')">
                  <p class="para-cont">All facilities shall be security assessed.</p></div> 
              </div>
              </div>

               <div class="wrapper-cont"><h2>Travel</h2>
              <div class="box-wth-notxt">
                <div class="content content-enable-box-cust"  v-on:click="show('All travel arrangements (flights, hotels, train travel, car rental, etc.) shall be made through the Corporate Travel provider.')">
                  <p class="para-cont">Use corporate travel provider.</p></div> 
              </div>
              

              </div>
              
            <div class="wrapper-cont"><h2>Security management</h2>
              <div class="box-wth-notxt">
                <div class="content content-enable-box-cust"  v-on:click="show('All security incidents shall be reported as soon as possible to ensure potential issues are addressed and to avoid recurrence.')">
                  <p class="para-cont">Document security incidents </p></div>
               </div>
               </div>
              </div>

              <div class="row-box-enable-wk">
                <div class="wrapper-cont"><h2>Business resilience & recovery</h2>
                <div class="box-wth-notxt">
                  <div class="content content-enable-wdth"  v-on:click="show('A BRRP shall be implemented at all corporate, regional and local operations. The head of the BUs/entities/projects are responsible for implementing it within their respective sectors. The BRRP shall be developed in line with the BRRP Procedure.')">
                  <p class="para-cont">Develop a Business Resilience & Recovery Plan (BRRP)</p></div><div class="line-img-last-chd"><img src="../assets/images/link-line.png" /></div> 
                  <div class="content content-enable-wdth"  v-on:click="show('Develop a comprehensive Emergency Response plan (ERP) for all offices and projects.')">
                    <p class="para-cont">Document an Emergency Response Plan </p></div> 
                </div> 
              </div>
            </div>

    </div>
    </div>

    <div class="col-3">
    <div class="content-box mty2">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span></div>
      <div class="ult-links"><h4>Useful links</h4>
        <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/global-security/" target="_blank">Global Security</a>
        <a href="https://atkins.service-now.com/QSSE?id=sc_cat_item_qsse&sys_id=b117bb3e4fd49f0044434da28110c7cb" target="_blank">Security Incident Reporting</a>
      </div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>

</div>
</div>
</div>
    </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters,  mapActions } from  "vuex";
export default {
  name: "EnableSecurityComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
   methods: {
             ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
   },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
