<template>
  <div>
    <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Security</h2>
      <p>SNC-Lavalin is a multinational company operating in numerous countries worldwide, with offices on every continent. This diversity is our strength and our pride, but in a world of constant change, it also exposes us to many potential threats in regions with diverse realities. In the course of our operations, we must always be aware of risks to ensure the security of our employees, assets and reputation.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/EnableSecurity';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='#/EnableSecurityDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4><span class="text-underline-cl">Personal Security</span> - Consult Global Security for a Deep Dive Security Assessment for all new bids in high-risk, extreme-risk and some specific-risk locations.</h4>
  <p>The Deep Dive Security Assessment (DDSA) will be carried out by Global Security and shall identify risks, vulnerabilities and mitigation measures to be implemented if the project is awarded to Engineering Services.</p>
  <h4><span class="text-underline-cl">Personal Security</span> - Documented Travel Security Plan for high-risk locations</h4>
  <p>Prepare a Travel Security Plan for all employees travelling on business to a high, extreme risk and/or specific travel location.</p>
  <h4><span class="text-underline-cl">Personal Security</span> - Consult Global Security for major high-risk company events.</h4>
  <p>Global Security shall be consulted in advance of major high-risk company events and shall produce a Special Events Security Plan (SESP).</p>
  <h4><span class="text-underline-cl">Physical Security</span> - All facilities shall be security assessed. </h4>
  <p>Ensure that appropriate physical measures are in place at offices that are commensurate to the specific threats and risks.  

A physical security assessment shall be carried out using the Security Assessment Vetting (SAV) process for all facilities. For new facilities this shall be carried out prior to moving in. A written SAV report shall be produced indicating vulnerabilities and mitigation measures which shall be implemented by local management. 

Employees operating inside a client or third-party property shall adhere to the security arrangements belonging to the client or third party.</p>
 <h4><span class="text-underline-cl">Travel</span> -  Use corporate travel provider. </h4>
  <p>All travel arrangements (flights, hotels, train travel, car rental, etc.) shall be made through the Corporate Travel provider. </p>

   <h4><span class="text-underline-cl">Security Management</span> - Document security incidents</h4>
  <p>All security incidents shall be reported as soon as possible to ensure potential issues are addressed and to avoid recurrence.</p>

  <h4>Develop a <span class="text-underline-cl">Business Resilience & Recovery Plan</span> (BRRP) </h4>
  <p>A BRRP shall be implemented at all corporate, regional and local operations. The head of the BUs/entities/projects are responsible for implementing it within their respective sectors. The BRRP shall be developed in line with the BRRP Procedure.</p>

   <h4>Document an <span class="text-underline-cl">Emergency Response Plan</span></h4>
  <p>Develop a comprehensive Emergency Response plan (ERP) for all offices and projects.</p>


</div>
</div>
  
  </div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "EnableSecurityDtVwComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>