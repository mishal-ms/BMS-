<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Performance</h2>
      <p>Monitoring business performance is key to improving business processes which underpin and enable delivery to our clients needs and expectations. Measuring performance is a vital part of monitoring delivery to our strategy and plans and gives the organization a sense of how we are performing. It enables the business to identify issues quickly and to make decisions to change direction based on evidence and facts.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='xxxxx.html';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/LeadProcessPerformanceAndImproveDetailedView';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">

      <div class="row-box">
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Establish mechanisms to monitor business performance</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Collect, analyze and report against established KPIs</p></div>
          <div class="arrow-img"><img src="../assets/images//arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Formal Quarterly review of performance to business plan</p></div>
          <div class="arrow-img"><img src="../assets/images//arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Update Business plan to reflect deviations from the plan</p></div>
        </div>
      </div>  


<div class="content-hd-text">
      <h2>Improve</h2>
      <p>Improvement is about constantly and consistently seeking opportunities to improve our delivery to client expectations to enhance client satisfaction. Improvements can include how we correct mistakes, how we continually improve what we do based on experience, or it could focus on breakthrough change, innovation or re-organization. Whatever the driver, always focussing on, and capturing learning to inform improvements is critical to the success of the organization. In today's world we cannot stand still we must always have an eye on the future and be challenging ourselves to do more and be better.</p>
  </div>
      <div class="row-box">
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Identify and prioritize opportunities for improvements</p></div>
          <div class="arrow-img"><img src="../assets/images//arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Manage Nonconformities</p></div>
          <div class="arrow-img"><img src="../assets/images//arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Continually improve the management system</p></div>
        </div>
    </div>   
</div>
</div>

    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Martina Perrin</strong></span> <span>Key Contact: <strong class="bld-txt">Joann Clarke</strong></span></div>
      <div class="ult-links"><h4>Useful links</h4> <a>Win Work Hub</a> <a>Glossary</a> <a>Community</a></div>
      <!-- <div class="ult-links"><h4>Training</h4> <a>xxxxxxx</a> </div> -->
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>
  </div>
  </div>
  </div>
<!-- Main content Container section end here -->


</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "LeadProcessPerformanceAndImprovecomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>