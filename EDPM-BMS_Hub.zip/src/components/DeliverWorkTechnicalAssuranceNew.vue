<template>
<div>



<!-- Main content Container section start from here -->
 <div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
       <h2>Technical Assurance</h2>
                <p>
                    Our reputation depends on the quality of our work. Effective
                    Technical Assurance is key to ensuring that the right level of
                    quality has been achieved for our clients through the application of
                    reasonable skill, care and diligence and ensures errors, omissions,
                    incomplete advice, delay and deficiencies are avoided. The purpose
                    of this process is to ensure that this expectation is delivered, and
                    our excellent quality culture maintained
                </p>
  </div>
  <div class="tabs">
   <button
            class="tab-link"
            onclick="window.location.href='#/DeliverWorkTechnicalAssurance';">
            Requirements
          </button>
          <button
            class="tab-link active"
            onclick="window.location.href='#/DeliverWorkTechnicalAssuranceNew';">
            Additional Detail
          </button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4> Understand client requirements aligned to proposal commitments</h4>
  <p>It is important to understand, prior to any formal contract signing, what commitments, promises or obligations have been made to the client in relation to our level of service or deliverables. Obligations may arise as a result of competitive dialogue, formal proposal discussions or single source negotiations</p>
  <h4>Conduct formal handover meeting between proposal manager, PD and PM</h4>
  <p>All technical bid assumptions, including check and review requirements, shall be documented and handed over to the Project Manager (if different from the proposal manager). A record of the handover shall be documented.</p>
  <h4> Identify approach to ensure deliverables meet proposal offer commitments and contractual obligations</h4>
  <p>The PM shall understand how we meet the customer's requirements and have confidence we will deliver their aspirations, meet legal obligations, and achieve this within the agreed commercial framework. The PM shall clarify any conflict or ambiguity in the above.</p>
  <h4>Identify and document external compliance requirements  </h4>
  <p>Identify and record all external legal, regulatory and client requirements relevant and applicable to the project. How these are to be monitored to ensure compliance shall be defined in the PMP.</p>
  <h4>Document learning from previous projects and updated guidance  </h4>
  <p>Learning captured as part of projects already executed should be referenced to make sure the project benefits from experience. Relevant reference projects should be identified either based on similar scope or client.</p>

  <h4>Document technical methodology and deliverables  </h4>
  <p>This shall take into account the most appropriate solutions to be determined within the available budget; critical delivery decisions to be made in an informed manner to avoid abortive downstream work and re-work and clarity is achieved before convergence on a solution</p>

  <h4>Identify competencies required to deliver the project</h4>
  <p>The resources required to deliver the project shall be assessed and confirmed they are available. The delivery team shall be established with the right balance of technical leadership, management and technical delivery skills, knowledge and experience to minimize the risk of technical error resulting in commercial loss.</p>

  <h4>Identify competent people to undertake technical assurance responsibilities</h4>
  <p>The people performing technical assurance roles shall have the required competence to do so.  The competence of the person carrying out each role shall be objectively assessed against the role’s requirements. The level of independence of each check and review role shall be commensurate with the amount of risk posed by the deliverable being incorrect (based on the likelihood of error and the overall consequences of errors)  The method of assessment shall be specified in the Project Management Plan.</p>

  <h4>Identify benchmark criteria for check and review assessment</h4>
  <p>The checking and review approach shall be determined by a competent project reviewer and implemented by the Project Manager.</p>

  <h4>Document technical assurance requirements as part of Project Management Plan</h4>
  <p>The PMP shall document the methodology for technical assurance and the roles and responsibilities for carrying out key technical assurance activities. The role-holders and duties shall be specified accordingly in the Project Management Plan for each deliverable type.  

The level of independence of each OCRA role shall be commensurate with the amount of risk posed by the deliverable being incorrect (based on the likelihood of error and the overall consequences of errors) and the OCRA role-holders and duties specified accordingly in the Project Quality Plan for each deliverable type.  
</p>



<h4> Document technical risks on the risk register</h4>
  <p>Failure to understand the implications of technical risk and to address them can have severe commercial, contractual and legal consequences. Therefore ensuring that all parties have addressed all reasonable risks is fundamental to successful delivery.</p>
  <h4>Formally mobilize project and  evidence understanding of scope, schedule and technical assurance expectations </h4>
  <p>As part of mobilization the project team, including third party suppliers and project team members working in other divisions or business units shall be briefed on the requirements within the PMP to ensure they understand how the technical elements of the project will be managed, including key roles and responsibilities, project programe, scope and key deliverables. This gives a common understanding of the technical assurance requirements and expectations of the project and ensures the project starts with everyone understanding their role within the project team.</p>
  <h4> Fully brief people undertaking technical assurance roles on key criteria for review</h4>
  <p>Those undertaking technical assurance roles shall be briefed on the specific requirements and criteria relevant to the scope of their responsibility.</p>
  <h4>Programe all technical assurance activities, including check and review</h4>
  <p>Technical Assurance activities shall be planned and programmed at the start of the project. Technical Leads shall be consulted to ensure the project programe is realistic and that Technical Assurance activities, including risk-based reviews and checking procedures have been appropriately, planned, costed and programmed.</p>
  <h4>Monitor progress and ensure  technical assurance activities are carried out as planned</h4>
  <p>Project reviews shall ensure the chosen solution is sensible and optimal as far as possible within the project constraints and the  assumptions made in the brief.
Technical reviews should be held sufficiently early in the delivery process to provide useful feedback that can be incorporated to enhance the project. 
</p>

  <h4>Capture, document and ensure closure of actions resulting from reviews of deliverables, including check and review</h4>
  <p>All projects shall use an auditable system for recording and closing out actions identified as part of project review or client comments. This shall include actions identified as part of check and review.  Capturing learning, knowledge and experiences from actions should follow an agreed method outlined in the PMP to allow knowledge to be shared across the project team and for the benefit of future projects.</p>

  <h4>Proactively assess, record and manage change and risks on appropriate registers</h4>
  <p>Any change on a project to staffing, client requirements, project data, programe, scope etc. shall be documented on the Change register and reviewed with any adverse consequences mitigated.  Any technical delivery risks shall be documented on the project risk register, assigned, and addressed in a timely manner before completion. All teams need to be using up to date information to reduce the likelihood of error and abortive work and to improve delivery efficiency.</p>

  <h4>Document client satisfaction in line with Project Management Plan, aligned to key milestone deliverables </h4>

  <h4>Share key learning from project reviews and client feedback with project team </h4>
  <p>Feedback from project performance reviews, the client, technical reviews and audits shall be shared with the project team, during the lifecycle of the project, to share learning,  inform and drive improvements</p>

  <h4>Check, review and authorize all deliverables in line with the Project Management Plan prior to issuing to any external parties</h4>
  <p>Deliverables shall only be issued to the client (or any other external parties) once they have been authorized as checked and reviewed in accordance with the PMP. The level of independence of each check and review role shall be commensurate with the amount of risk posed by the deliverable being incorrect (based on the likelihood of error and the overall consequences of errors)</p>


  <h4>Document and control all information shared with the client in line with Project Management Plan</h4>
  <p>A suitable system should be in place for strict document control and data management for all incoming and outgoing communication, documents and calculations, which includes strict revision control.</p>
  <h4>Confirm with the client all deliverables are complete</h4>
  <p>The PM shall confirm with the client all final deliverables have been issued and address all contractual obligations prior to formally closing the project.</p>

  <h4>Ensure technical learning from the project captured during delivery is collated and shared</h4>
  <p>All learning captured during  project delivery shall be systematically recorded and stored in a consistent, clear, findable form. Learning should be transferred into guidance notes and made available for future projects to search and access.</p>

  <h4>Archive project information in line with contractual obligations</h4>
  <p>Project data shall be retained and archived in line with contractual obligations and the requirements laid out in the PMP.</p>

</div>
</div>
</div>
</div>
<!-- Main content Container section end here -->


</div>

</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "DeliverWorkClientSatisfactionNewComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>