<template>
<div>



<!-- Main content Container section start from here -->
 <div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Project Financial Management</h2>
                <p>
                    Financial Management is an essential means of controlling a project.
                    Good financial management brings benefits, such as good cash-flow,
                    early-warning of overspends, accurate forecasts of project outturns,
                    and accurate cost capture for future estimating and bidding.
                </p>
  </div>
  <div class="tabs">
   <button
            class="tab-link"
            onclick="window.location.href='#/DeliverWorkProjectFinancialManagement';">
            Requirements
          </button>
          <button
            class="tab-link active"
            onclick="window.location.href='#/DeliverWorkProjectFinancialManagementNew';">
            Additional Detail
          </button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Handover the proposal commercial strategy to the delivery team</h4>
  <p>The commercial and financial plan created at proposal stage shall be handed from the proposal team to the delivery team </p>
  <h4>Finalise project estimating and pricing model </h4>
  <p>Pricing model should be reviewed against bid commitments, contractual obligations and delivery plan. It shall identify any third party obligations and internal trading. 
Prior to any internal trading being undertaken the buying business should define the scope of the task to be performed and agree terms with the selling business. Details of the trading arrangement shall be formally documented to ensure clarity of the respective responsibilities, resources, rewards and risk so as to provide a seamless service to the client and minimise the opportunity for internal dispute.</p>
  <h4> Confirm project financial baselines and create initial summary financial forecast </h4>
    <p>The project financial baseline shall be created, ensuring that all aspects of the contractual obligations have been incorporated.  This should be approved by the project director.  The initial baseline shall be created in the relevant finance system </p>

  <h4>Generate financial project summary report on relevant finance system </h4>
  <p>The financial details shall be input into the relevant system and appropriately approved by the Project Director.</p>
  <h4>Document Financial Management Plan </h4>
  <p>The Financial Management plan shall include all aspects of the financial delivery of the project.  It shall be time phased for both costs and revenues and should include a work breakdown structure aligned to the project delivery plan.</p>

  <h4>Formally mobilize project informing the project team of key project financial controls   </h4>
  <p>The project team shall be informed of the financial budget for delivery of the project and any particular delivery plans that may influence the financial success of the project.</p>

  <h4>Assign budgets to discipline/work package leads   </h4>
  <p>Detailed budget targets shall be assigned to relevant individuals to ensure there is clarity around effort and cost commitments to deliver the project.</p>


  <h4>Monitor and review project costs and cashflow against the financial plan </h4>
  <p>Project costs, revenues and lockup shall be formally reviewed and appropriate forecasts submitted to allow the accurate reporting of project revenue, margin and cashflow in the monthly management accounts</p>

  <h4>Review and update Project Summary Report monthly</h4>
  <p>The project financial forecast is the principal driver to recognise revenue and margin in the management accounts and as such, it is vital for accurate financial reporting that all forecasts are reviewed and approved monthly.  Any changes shall be incorporated on a timely basis. The Project Manager shall review the project forecast and ensure it represents the best current estimate of the eventual project outturn</p>


  <h4>Invoice client in line with contractual requirements</h4>
  <p>The project manager shall ensure that the client is invoiced in line with the contract.  This activity shall be supported by the relevant finance team</p>


  <h4>Close Project Finances </h4>
  <p>Once all contractual deliverables are complete, the project forecast is equal to actual costs and invoicing, and all cash has been received, the project can be formally closed in the relevant systems. Job Records shall be closed as soon as possible after financial completion by the Project Manager with support from relevant functional staff.  
</p>

  <h4>Archive project information in line with contractual obligations</h4>


</div>
</div>
</div>
</div>
<!-- Main content Container section end here -->


</div>

</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "DeliverWorkClientSatisfactionNewComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>