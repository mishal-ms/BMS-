<template>
    <section class="stages">
        <b-container>
			<b-row class="stages-tabs col-5px-spacing">
				
				<b-col v-if="slugID==='Detail'">
					<button v-for="(type, index) in stagesType" :key="index" :class="{ 'active' : (index+1) === stageTypeNum }" v-on:click="getActive(index+1, getDefaultValue(type.Id))"  >{{type.Title}}</button>
				</b-col>
			</b-row>
			<b-row class="stages-spacer">
				<b-col>
					<hr>
				</b-col>
			</b-row>
			
		
			<b-row class="stages-cards col-5px-spacing" v-if="slugID==='Detail'">
				<b-col v-for="(stage, index) in stagesWithStageType" :key="index+1" >
						<a  href="#"
						class="stage" 
						 @click.prevent="getActive(stageTypeNum,stage.Id)" 
						:class="[ 
							stageNum === stage.Id ? 'active' : '', 
							'stage-color-' + (index+1)
						]"
					>
						<div class="stage-no">{{ index+1 }}.</div>
						<div class="stage-info">
							<p>{{ stage.Title }}</p>
						</div>
					</a>
				</b-col>
			</b-row>
		</b-container>
    </section>
</template>
<script>
import mixin from '../mixins/common.js';
import api from '@/service'
import { mapActions,mapGetters } from 'vuex'
export default {
	 mixins: [mixin],
	name: 'bimstagesdetail',

	computed: {
		...mapGetters([
			'stages','stagesType','combinedResults','stageTypeNum','stageNum'
		]),
		
		slugID() {
			return this.$route.name
		},
		
		stagesWithStageType() {
			return this.getCorrectStages()
        }
	},
    data() {
        return {
			childData: '',
			stageType:'',
			selectedStage:this.stageNum,		
        }
	},
    methods: {
		...mapActions([
			'SET_STAGE','SET_STAGE_TYPE'
		]),
		
		getCorrectStages(){
			var result=  _.chain(this.stages).groupBy("StageTypeId").value();
			return _.orderBy(result[this.stageTypeNum], 'OrderNumber', 'asc')
		},

		getDefaultValue(stagesTypeID) {
			var result= _.find(this.stages,{StageTypeId: stagesTypeID,OrderNumber: 1});
			this.selectedStage=result
			return result.Id;
		},

		getActive(stageTypeId,stageId){ 
			const vm = this;
			this.SET_STAGE(stageId);
			this.SET_STAGE_TYPE(stageTypeId);
			this.$router.push('/')
		},
		
	}
}
</script>
