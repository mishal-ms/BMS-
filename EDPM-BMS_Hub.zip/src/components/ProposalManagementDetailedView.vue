
<template>
    <div>


<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Proposal Management</h2>
      <p><strong class="bld-txt">Proposal management</strong> Involves implementing and scaling a common SNCL-wide capture and proposal process for major opportunities, based on 3-phase approach: capture phase; proposal preparation; post-submission. This process is enabled by a set of tools, capabilities and behaviours including: a greater emphasis on leveraging our Global Networks to address resource issues and identify opportunities for horizontal collaboration; using Digital Marketing techniques to generate data-driven insights that strengthen sales enablement; maintaining a competitive intelligence knowledge bank and supporting with the development of work winning talent.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/ProposalManagement';">Requirements</button>
    <button class="tab-link active"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>

  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
<h3>Commercial Proposal</h3>
<h4>Analyse how pricing can be structured to maximise scoring</h4>
<h4>Develop the price to win strategy</h4>
<h4>Identify commercial risks and add to risk register</h4>
<h4>Define supply chain strategy</h4>
<h4>Identify resource requirements and cost</h4>
<h4>Develop pricing proposal</h4>

<h3>Qualifying Proposal</h3>
  <h4>Procurement document received</h4>
  <p> Formal documents received via formal channel</p>
  <h4>Review Procurement documentation  </h4>
  <p> Bid teams should review the procurement documentation collectively as soon as possible, noting the key points and potential issues to query.</p>
  <h4> Decision to confirm continued pursuit and investment</h4>
  <h4>Agree Bid Director / Pursuit Lead</h4>
  <p>Bid Director / Pursuit Lead formally appointed to Pursuit</p>
  <h4>Agree Pursuit budget</h4>
  <p>Should produce an itemized costing of internal and external costs related to bid activity</p>

  <h4>Identify additional risks and update register </h4>

  <h4>Conduct Go/No Go to confirm investment</h4>


  <h4>Confirm the Pursuit team, including the delivery project director and project manager.</h4>
  <p>Bid teams should agree Pursuit team structure and provide list of Pursuit team members and brief profiles as part of Pursuit kick-off materials</p>
  <h4>Develop the Proposal Management Plan</h4>
  <p>The core Pursuits team should produce a Proposal Management Plan. It shall document tasks, schedules, delivery milestones, roles and responsibilities. The plan should be used to keep the Pursuit on track and accountable.</p>
  <h4>Share capture planning information via a kick off meeting with pursuit team</h4>
  <p>The completed Capture Plan should be shared / presented by core Pursuits team with relevant Pursuit stakeholders</p>
  <h4>Submit clarifying questions to client and monitor responses</h4>
  <h4>Define key messages and differentiators for win strategy </h4>

  <h4>Develop answer plans and technical response strategy</h4>
  

  <h4>Pursuit responses completed </h4>

    <h4> Full pursuit response review conducted </h4>
  <h4> Submit response to client </h4>
  <h4> Update sales database </h4>

</div>
</div>

</div>
</div>
<!-- Main content Container section end here -->



    </div>
</template>

<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "ProposalManagementDetailedViewComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>