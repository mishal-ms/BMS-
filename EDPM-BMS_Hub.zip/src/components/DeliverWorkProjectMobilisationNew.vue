<template>
    <div>
        


<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Project Mobilization</h2>
      <p>Project mobilization is one of the most important events in the course of a project. It is the start of project execution for the wider project team.  Everyone on the project team needs to be aware the project is up and running and to understand their role and responsibility in the delivery of the  the clients expectations and contractual obligations.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkProjectMobilisation';">Requirements</button>
    <button class="tab-link active" > Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button>  -->
  </div>
  
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Document required Project Management Plans</h4>
  <p>The Project Management Plan (PMP) brings together all the plans for a project. The purpose of the PMP is to provide the reference document for managing the project. The scale of the PMP shall be proportionate to the risk, scale and complexity of the project. All projects >£10m (or equivalent value) shall follow the requirements of the MPU. The mobilization of the project team shall ensure everyone on the project is aware of the requirements laid out in the PMP.</p>
  <h4>Define project team roles and responsibilities, and identify competent individuals</h4>
  <p>A successful project requires a balance of technical, managerial, commercial and leadership skills. The team as a whole should provide all these skills.    
    Staff competencies regarding requisite skills and experience shall be assessed as satisfactory by a suitably competent person using an objective approach such as knowledge of individual capabilities; feedback from qualified others on individual capabilities; a competency framework.
    The project team shall be aware of who is responsible for key roles on the project, including Technical Leads and Technical Reviewers.</p>
  <h4>Identify competent Technical Leads and Technical Reviewers</h4>
  <p>Competent Technical Leads shall be appointed for each discipline earlier in the project lifecycle to ensure early engagement to shape the delivery strategy. Technical Reviewers shall be assessed as competent in the discipline and fields they are required to review. Technical reviewers shall be able to demonstrate and evidence their suitability and expertise to act as reviewer for different work packages and/or the overall project.</p>
  <h4>Hold Client kick off meeting</h4>
  <p>Before undertaking substantial delivery activity, a discussion of appropriate length to match the scope of the project should be held with a suitable person in the client organization to verify the project requirements. This shall include a discussion on the technical delivery strategy and assumptions, along with clarification on deliverables. </p>
  <h4>Brief Technical Reviewers on expectations, budget and requirements</h4>
  <p>A specific project briefing shall be held with Technical Reviewers to ensure they fully understand the contractual and client obligations in relation to delivery and/or design constraints aligned to external compliance requirements i.e. legal, regulatory, client defined parameters. The schedule and budget to conduct the reviews shall be shared to ensure the reviews are planned and costed.</p>

  <h4>Formally mobilise the project involving the project team</h4>
  <p>It is essential that the project team, including third party suppliers and project team members working in other divisions or business units, shall be briefed on the requirements within the PMP to ensure they understand how the project will be managed, including key roles and responsibilities, project programme, scope and key deliverables. This ensures a common understanding of the requirements and expectations of the project and ensures the project starts with everyone understanding their role  within the project team.</p>

  <h4>Evidence project team have read and understood Project Management Plan</h4>
  <p>Evidence will be gathered to demonstrate the project team, including third party suppliers and project team members working in other divisions or business units, have read and understood the PMP.</p>

</div>
</div>
</div> 
</div>
<!-- Main content Container section end here -->




</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "DeliverWorkProjectMobilisationNewComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>