<template>
<div>
<div class="pr-fn-ctrl">
  <ul>
    <li>Project Functional Controls</li>
    <!-- <li>Function Control</li> -->
    <!-- <li>Procurement</li> -->
    <!-- <li>Project Management</li> -->
    <!-- <li>Risk Management</li> -->
    <li class="highLite"><a target="_blank" href="https://atkins.sharepoint.com/sites/CommercialHub/html/index.aspx?OR=Teams-HL&CT=1649056004208&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjAzMDcwMTYxMCJ9#/">Commercial Hub</a></li>
    <!-- <li>Construction</li> -->
    <!-- <li>O&M</li> -->
    <!-- <li>Engineering</li> -->
  </ul>
</div>
<div class="corp-fun">
  <ul>
    <li>Corporate Functions</li>
    <li class="highLite"><a target="_blank" href="https://atkins.sharepoint.com/sites/EDPMQuality/SitePages/EDPM-Quality.aspx">Quality</a></li>
    <li class="highLite"><a target="_blank" href="https://infozone.snclavalin.com/en/global-health-safety/">HSE</a></li>
    <li class="highLite"><a target="_blank" href="https://infozone.snclavalin.com/en/corporate/corporate-information/sustainability/">Sustainability</a></li>
    <li class="highLite"><a target="_blank" href="https://infozone.snclavalin.com/en/sectors-functions/functions/ethics-compliance/">Integrity</a></li>
    <li class="highLite"><a target="_blank" href="https://infozone.snclavalin.com/en/sectors-functions/functions/global-security/">Global Security</a></li>
    <li class="highLite"><a target="_blank" href="https://infozone.snclavalin.com/en/sectors-functions/functions/human-resources/">Human Resources</a></li> 
    <li class="highLite"><a target="_blank" href="https://infozone.snclavalin.com/en/sectors-functions/functions/finance/">Finance</a></li>
    <li class="highLite"><a target="_blank" href="https://infozone.snclavalin.com/en/sectors-functions/functions/information-technology/">Information Technology</a></li>

  </ul>
</div>
</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "FunctionalComp",
  data() {
    return {
      // banner: Banner,
      // searchText: "",
      // search: false,
      // sr: "",
      // searchResults: [],
    };
  },
  computed: {
    
  },
  methods: {
   
  },
  watch: {
    
  },
};
</script>