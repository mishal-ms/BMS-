<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Controls and Assurance</h2>
      <p>Controls are put in place to drive efficiency and effectiveness in our delivery to clients. They enable the organization to grow and innovate based on continual improvement, providing predictability of our services and products. Assurance is about meeting the delivery and accountability needs of the organization, providing evidence-based assurances on the management of risks and internal controls, that may threaten the successful achievement of our plan.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/ProcessImplement';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='#/LeadProcessImplementDetailedView';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Establish management system</h4>
  <p>A management system defining the controls associated with Quality, Health, Safety and Environment shall be established, published and available to all employees,  aligned to ISO 9001, ISO 14001 & ISO 45001. The scope and audience for the management system shall be defined and reviewed annually to determine what is covered and who shall comply with the requirements.</p>
  <h4>Embed the management system</h4>
  <p>The management system shall be actively shared with all decisions makers using the system. Top management shall ensure conformity to the management system and where it cannot be followed ensure a formal deviation is sought. </p>
  <h4>Demonstrate leadership and commitment to the management system.</h4>
  <p>Top management shall be accountable for the management system ensuring reviews are undertaken at planned intervals to measure and monitor conformity and effectiveness.  All governance shall align and decision makers shall ensure all governance established within their span of control is aligned to the Management System.</p>
  <h4>Establish mechanism to monitor and maintain effectiveness of Management System</h4>
  <p>The management system shall be reviewed by top management at planned intervals to ensure its continued suitability, adequacy, effectiveness and alignment with the strategic direction of the organization. Decisions and actions arising from reviews shall be documented and managed to  closure.</p>
  <h4>Plan and schedule management system Internal Audits</h4>
  <p>An Internal Audit plan, aligned to the management system, shall be agreed annually with a documented audit schedule.  The internal audit plan shall cover Quality, Health, Safety and Environment audits aligned to the requirements of the relevant ISO standards.</p>

  <h4>Measure conformance to the management system</h4>
  <p>Internal Audit findings shall measure and identify conformity to the management system. Internal audits shall be documented and findings shall be communicated to all relevant stakeholders. Internal Audit actions shall be documented and tracked to closure and the outcomes of internal audits shall be reported to top management.</p>

  <h4>Establish problem and incident management mechanisms</h4>
  <p>Outputs that do not conform to defined requirements shall be identified and controlled to prevent unintended use or delivery. Mechanisms shall be established to highlight actual or potential risks in the business that may represent deviations from defined requirements to enable appropriate action to be taken.</p>

</div>
</div>
</div>
</div>
<!-- Main content Container section end here -->




</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "LeadProcessImplementDetailedViewcomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>