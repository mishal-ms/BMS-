<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Controls and Assurance</h2>
      <p>Controls are put in place to drive efficiency and effectiveness in our delivery to clients. They enable the organization to grow and innovate based on continual improvement, providing predictability of our services and products. Assurance is about meeting the delivery and accountability needs of the organization, providing evidence-based assurances on the management of risks and internal controls, that may threaten the successful achievement of our plan.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/LeadProcesscontrolassuranceDetailedView';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <div class="row-box">
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Establish management system</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Embed the management system</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Demonstrate leadership and commitment to the management system</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Establish mechanism to monitor and maintain effectiveness of Management System</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt">
          <div class="content bg-lead"><p class="para-cont">Plan and schedule management system Internal Audits</p></div>
          </div>
      </div>
    

<div class="row-reverse-last-child">
  <div class="box">
    <div class="content bg-lead"><p class="para-cont">Measure conformance to the management system</p></div>
  </div>
  <div class="box">
    <div class="content bg-lead"><p class="para-cont">Establish problem and incident management mechanisms</p></div>
    <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
  </div>
</div>
  </div>




    </div>

    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Martina Perrin</strong></span> <span>Key Contact: <strong class="bld-txt">Joann Clarke</strong></span></div>
      <div class="ult-links"><h4>Useful links</h4> <a>Win Work Hub</a> <a>Glossary</a> <a>Community</a></div>
      <!-- <div class="ult-links"><h4>Training</h4> <a>xxxxxxx</a> </div> -->
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>

    </div>
</div> 
</div>
<!-- Main content Container section end here -->




</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "LeadProcessControlassurancecomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>