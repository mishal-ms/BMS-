<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Equality, Diversity & Inclusion</h2>
      <p>Given the right environment every person has the opportunity to contribute to creating a workplace where people can feel valued, listened to and cared about. Creating an inclusive environment will enable our organization to tap into a diverse strong talent pool, better serving our diverse client base and leading to better business outcomes.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/EnableEdAndI';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/EnableEdAndIDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="row-content"> 
    <div class="col-9">
    <div class="card-wrap">
      <div class="row-box">
        <div class="box">
          <div class="content content-enable cursor-none"><p class="para-cont"> SNC-L ED&I Strategy to provide the framework for sector plans </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content content-enable cursor-none"><p class="para-cont"> Everyone shall be treated with dignity and respect  </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Create and support ED&I networks where there is employee need and alignment to the ED&I strategy.')">
          <div class="content content-enable"><p class="para-cont">Create inclusive networks</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Everyone is supported to speak up if they see or hear something that contradicts the standards of behaviour set out in the code of conduct.')">
          <div class="content content-enable"><p class="para-cont">Foster a culture of openness   </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt" v-on:click="show('Develop supportive policies and procedures which reflect the differing needs of diverse groups.')">
          <div class="content content-enable"><p class="para-cont">Develop a clear set of HR policies which support the ED&I Strategy</p></div>
          </div>
      </div>
    

<div class="row-reverse-last-child">
  <div class="box">
    <div class="content content-enable cursor-none"><p class="para-cont">Provide training and awareness to support an inclusive culture</p></div>
  </div>
  <div class="box">
    <div class="content content-enable cursor-none"><p class="para-cont">Adopt a fair, objective and inclusive recruitment and selection process</p></div>
    <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
  </div>
 </div>
  </div>
</div>
    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span></div>
      <div class="ult-links"><h4>Useful links</h4>
        <a href="https://infozone.snclavalin.com/en/corporate/corporate-information/diversity-and-inclusion/" target="_blank">Equality, Diversity and Inclusion</a>
      </div>
      <div class="ult-links"><h4>Approved Deviations</h4><a>None</a></div>
    </div>
    </div>
 </div>
  </div>
</div>
<!-- Main content Container section end here -->


</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions } from "vuex";
export default {
  name: "EnableEdAndIcomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
   methods: {   ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
   },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
