<template>
<div></div>
</template>

<script>
// @ is an alias to /src
export default {
	name: 'Nav',
}
</script>
<style lang="scss">
// @import '../assets/scss/components-scoped/navigation.scss';
</style>
