<template>
    <div> 

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>High Performing Culture</h2>
      <p>A high-performance culture is an organizational culture built on a set of universally accepted behaviors and norms that are encouraged by leaders and facilitated by optimal tools and processes. These help employees work as effectively as possible to achieve business goals and create value.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/EnableHighPerformingCulture';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/EnableHighPerformingCultureDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <div class="row-box">
        <div class="box" v-on:click="show('An annual training budget shall be identified as part of the business plan.  Individual training and development needs shall be assessed following the annual Performance Develoment Review (PDR) process. L&D needs shall be objectively reviewed to manage all requests in line with the business plan, budget and personal development needs.')">
          <div class="content content-enable"><p class="para-cont">Plan employee learning and development with associated investment </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Everyone shall have access to relevant learning and development essential to performing their current role.')">
          <div class="content content-enable"><p class="para-cont">Access is provided to the skills everyone needs to be effective in their role</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Appropriate controls shall be identified to encourage, manage, review and support innovation and improvements that align to the strategy or business plan. Investment in innovation shall be appropriately approved and supported by a documented business case.')">
          <div class="content content-enable"><p class="para-cont">Establish controls at the right level to enable innovations and improvements </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Managing a diverse workforce requires the recognition that everyone comes with different challenges, expectations, needs and opportunities. In order to support high performance consideration shall be given to how diverse needs can be accommodated such that we benefit from a diverse talent pool that is motivated, engaged and able to deliver to their potential.')">
          <div class="content content-enable"><p class="para-cont">Provide a physical environment that promotes the productivity requirements of a diverse workforce</p></div>
            <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
          </div>
          <div class="box arrow-rt" v-on:click="show('Technology is critical to enabling high performance. Having the right tools and systems to be effective, efficient and connected is vital. Making sure technology meets the needs of everyone today and into the future is a key priority and shall be considered as part of the business planning process.')">
    <div class="content content-enable"><p class="para-cont">Prioritize technology and tools to support an agile organization</p></div>
  </div>
      </div>
    

<div class="row-reverse-last-child">
  <div class="box" v-on:click="show('Performance management reviews shall formally be conducted annually to measure performance, identify future objectives and agree development needs. Regular discussions should take place during the year to enable everyone to learn from their experiences, share feedback and gain valuable support in reaching their full potential.')">
    <div class="content content-enable"><p class="para-cont">Establish performance management reviews</p></div>
  </div>
  <div class="box" v-on:click="show('Access to knowledge is fundamental in developing high performing teams. Learning from experience shall be captured and shared across relevant networks.  Technical leaders shall be identified and shall share knowledge and updates within their technical field.')">
    <div class="content content-enable"><p class="para-cont">Plan and effectively share knowledge managament</p></div>
    <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
  </div>
</div>
  </div>
</div>
    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span></div>
      <div class="ult-links"><h4>Useful links</h4>
        <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/human-resources/academy/learning-development.aspx" target="_blank">HR - Learning and Development</a>
        <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/human-resources/learning-zone.aspx" target="_blank">Learning Zone</a>
      </div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>

    </div>
  </div> 
</div>
<!-- Main content Container section end here -->
</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions} from "vuex";
export default {
  name: "EnableHighPerformingCultureComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
   methods: {
     ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
   },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>