<template>
    <div>
        <div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Integrity</h2>
      <p>Integrity is important to provide opportunities for people to achieve their potential, enabling them to feel valued not just for what they offer now but for their future potential. It provides opportunity for people to grow and increase their levels of engagement and satisfaction through the achievement of their goals and those of the organization.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/EnableIntegrity';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/EnableIntegrityDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>

  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <div class="row-box-single mb">
        <div class="box-wth-txt">
          <h2>Gifts and<br/>Hospitality</h2>
          <div class="content content-enable-wt-gap" v-on:click="show('A Gifts & Hospitality Scorecard shall be completed when: any government official is involved; where any other kind of third party is involved and it exceeds local country thresholds.')">
            <p class="para-cont">A Gifts and Hospitality Scorecard shall be completed in line with SNC-L requirements</p></div> 
        </div>
        <div class="box-wth-txt">
          <h2>Donations and<br/>Sponsorship</h2>
          <div class="content content-enable-wt-gap" v-on:click="show('All donations and sponsorships shall be recorded on the SNC-L Online Approval Tool and adhere to the LoA Policy Integrity Offices shall carry out due diligence on proposed beneficiaries.')">
            <p class="para-cont">All donations and sponsorships shall be recorded on the SNC-L Online Approval Tool and adhere to the LoA Policy</p></div>
        </div>
        <div class="box-wth-txt">
          <h2>Counterparty<br/>Checks</h2>
          <div class="content content-enable-wt-gap" v-on:click="show('Counterparty checks shall be undertaken at the inception of all new business relationships')">
            <p class="para-cont">Counterparty checks shall be undertaken at the inception of all new business relationships</p></div>
        </div>
        <div class="box-wth-txt">
          <h2>Trade Compliance/<br/>Sanction Control</h2>
          <div class="content content-enable-wt-gap" v-on:click="show('Prior to undertaking any business activities in a foreign country SNC-L Personnel shall ensure the country in which the work would take place is not sanctioned or embargoed.')">
            <p class="para-cont">Personnel shall ensure any country in which work would take place is not sanctioned or embargoed </p></div>
        </div>
        <div class="box-wth-txt">
          <h2>Integrity Project<br/>Endorsement</h2>
          <div class="content content-enable-wt-gap" v-on:click="show('Prior to undertaking any business and as part of preparation and Bid approval Client Check; Country Check, Supplier Checks shall be completed.')">
            <p class="para-cont">Supplier Checks shall be completed prior to undertaking business</p></div>
          </div>
        </div>
        <div class="row-box-single mb">
          <div class="box-wth-txt">
            <h2>SNC-L Code<br/>of Conduct</h2>
            <div class="content content-enable-wt-gap cursor-none">
              <p class="para-cont">All SNC-L Personnel must follow the Code of Conduct and on an annual basis complete the Code of Conduct Certification</p></div> 
          </div> 
          <div class="box-wth-txt">
            <h2>Governance<br/>Framework </h2>
            <div class="content content-enable-wt-gap cursor-none">
              <p class="para-cont">SNC-L Personnel must seek a formal deviation when unable to follow Level 1 and Level 2 SNC-L governance requirements.</p></div>
          </div> 
          <div class="box-wth-txt">
            <h2>Data<br/>Compliance </h2>
            <div class="content content-enable-wt-gap cursor-none">
              <p class="para-cont">Data Compliance principles and requirements shall be followed</p></div>
          </div> 
          <div class="box-wth-txt">
            <h2>Modern Slavery and<br/>Human Trafficking </h2>
            <div class="content content-enable-wt-gap cursor-none">
              <p class="para-cont">All supply chain partners shall agree to follow the Supplier Code of Conduct </p></div>
          </div>
          </div>

          <div class="row-box-single">
            <div class="wrapper-cont"><h2>Business Partners</h2>
            <div class="box-wth-notxt">
              <div class="content content-enable-last-chld" v-on:click="show('Risk based due diligence shall be completed to verify prospective Business Partners are persons or entities of integrity and possess the necessary background, reputation and qualifications for the service to be rendered.')">
                <p class="para-cont">Risk based due diligence shall be completed to verify prospective Business Partners</p></div>
                 <div class="line-img-last-chd"><img src="../assets/images/link-line.png" /></div>
              <div class="content content-enable-last-chld-custom" v-on:click="show('Any agreement where a Third Party may be acting as a representative or Sponsor shall require the approval of the Sector President and Chief Integrity Officer.')">
                <p class="para-cont">Approval of the Sector President and Chief Integrity Officer is required for representatives or sponsors </p></div> 
                <!-- <div class="line-img-last-chd"><img src="../assets/images/link-line.png" /></div> -->
            </div>
            
          </div>
          <div class="wrapper-cont-cust"><h2>Duty to Report/Investigation</h2>
            <div class="box-wth-notxt">
              <div class="content content-enable-last-chld-custom cursor-none">
                <p class="para-cont">Personnel shall act appropriately and in a timely manner to prevent or detect improper conduct arising from illegal or unethical behaviour.</p></div>
                <div class="line-img-last-chd"><img src="../assets/images/link-line.png" /></div>
              <div class="content content-enable-last-chld-custom cursor-none">
                <p class="para-cont">Personnel shall disclose any concerns, complaints or allegations of known or suspected wrongdoing or misconduct</p></div>

             </div>
             </div>
            </div>

    </div>
    </div>

    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span></div>
      <div class="ult-links"><h4>Useful links</h4>
      <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/ethics-compliance/">Integrity</a>
      <a href="http://axis.eu.atkinsglobal.com/uk/ourstandards/compliance/Pages/world_askintegrity.aspx">Axis Ask Integrity Page</a>
      <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/ethics-compliance/services-responsibilities/code-training-certification.aspx">Code of Conduct</a>
      <a href="https://bpcdd.snclavalin.com/bpc/nui/home?x=AszCAnva_oY">Business Partner Compliance Tool</a>
      <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/ethics-compliance/services-responsibilities/hotline-reporting-issue.aspx">Integrity issue reporting</a>
      <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/ethics-compliance/services-responsibilities/supplier-code-of-conduct.aspx">Supplier Code of Conduct </a>
      <a href="https://atkins.sharepoint.com/sites/corpDVP/SitePages/DeviationToolPortal.aspx">SNC-L Deviation Tool </a>
      <a href="https://km.snclavalin.com/pdce/Functional/Vendor%20Integrity%20Verification%20SOP%202P-AG-050%20FINAL.pdf">Vendor Integrity Verification Procedure </a>
      <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/ethics-compliance/services-responsibilities/Export-Control-and-Trade-Compliance-Program.aspx">Trade Compliance</a>
      <a href="https://infozone.snclavalin.com/en/files/documents/Country-Position-Register-en.pdf">Country Position Register</a>
      <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/ethics-compliance/services-responsibilities/snc-lavalin-data-privacy-principles.aspx">Data Compliance</a>
      <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/ethics-compliance/services-responsibilities/modern-slavery-and-human-trafficking.aspx">Modern Slavery & Human Trafficking</a>



      



      </div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>

</div>
</div>
</div>
    </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions} from "vuex";
export default {
  name: "EnableIntegrityComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
   methods: {
     ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
 },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
