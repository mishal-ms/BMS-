<template>
    <div>



<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Client development</h2>
      <p>Building and sustaining close client relationships is key to the success of our business. <strong class="bld-txt">Client development</strong> is about listening to our clients and identifying and providing solutions to their problems, sometimes even before they realize they have a problem. Our key accounts make up the majority of our business income and therefore it is essential we remain close to these clients. Our Client development process provides guidance on how to build long-term relationships with our most valuable clients.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/ClientDevelopment';">Requirements</button>
    <button class="tab-link active" > Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>

  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Market priorities identified </h4>
  <p>Should be aligned to Regional Market Strategies and shall comprise common tools for assessing Market priorities, including (but not limited to): Addressable Market Sizing; Market Forecasting (including by Segment); Analysis of Customer Demand Drivers.</p>
  <h4>Key clients identified</h4>
  <p>Should be aligned to Regional Market Strategies and should be informed by an understanding of where customer demand drivers meet Engineering Services capabilities. A variety of tools and methodologies shall be available to help identify Key Clients.</p>
  <h4> Undertake Client research to build understanding </h4>
  <p>Should utilise a variety of qualitative and quantitative research methodologies and strategic marketing tools e.g. PESTEL / SWOT analysis, and internal interviews, to gain a deeper understanding of client demand drivers and spending priorities.</p>
  <h4>Identify Key Accounts based on defined criteria</h4>
  <p>Should utilize Client Research and the Win Work Client Selection Tools that are available to help define and priortize key clients</p>
  <h4>Develop Client Account Management Plan for every client</h4>
  <p>Consult Win Work collaboration platforms to access guidance for KAM Plan structure, required content and tools (such as annual targets, market analysis, pipeline opportunities and a Client Engagement Plan and Customer Value Proposition Development tools)</p>

  <h4>Identify measures to monitor performance against Client Account Management Plan</h4>
  <p> Formal KPIs and Metrics shall be agreed to measure performance against KAM Plan. Formal Win Work KAM Metrics shall be required by the Global Growth Team and Key Account Managers should be responsble for implementing mechanisms to track Lead and Lag indicators on an quarterly basis.</p>

  <h4> Define and align client engagement at all levels</h4>
  <p>A relationship plan should cover influential/key people in a client we want to build a relationship with. It should identify who is the Atkins member who will do the engagement.</p>


  <h4>Review delivery to the Client Account Management Plan</h4>
  <p> The client account plan should be reviewed and updated annually</p>
  <h4>Formal Client perception feedback received</h4>
  <p>Client Perception Survey issued to client, completed by client, revceived from client.</p>
  <h4>Feedback from Client perception incorporated into Client Account Plan</h4>
  <p>Formal Client Perception findings (e.g. via Surveys) should be analysed and key findings incorporated into Client Account Plans in the form of Client Research and Intelligence. Access to feedback should be disseminated to other parts of the business, including by making it available of Win Work collaboration platforms.</p>
</div>
</div>
  
</div>
  </div>
<!-- Main content Container section end here -->





    </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "ClientDevelopmentDetailedViewComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>