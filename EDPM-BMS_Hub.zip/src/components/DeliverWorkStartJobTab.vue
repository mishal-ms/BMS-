<template>
  <div>
    <!-- Main content Container section start from here -->
    <div class="cont-container">
  <div class="content-wt">
    <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkAllSteps';">All</button>
    <button class="tab-link active" onclick="window.location.href='#/DeliverWorkStartJobTab';">Start the Job Right </button>
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkDoJobTab';">Do the Job Right </button>
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkFinishJobTab';">Finish the Job Right  </button>
</div>
  
 <div class="cont-row-wrapper mt">
    <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProposalHandover';"><div class="outline-cont-dl"><p>Proposal Handover</p></div></div>
   <div class="scroll-area-sgl">
   <ul class="list-box-dl">
      <li><div class="first-child-dl">Identify appropriately assessed and competent PD and PM when procurement document received</div></li>
      <li><div class="first-child-dl">Involve PD and PM in establishing the proposed baselines/deliverables</div></li>
      <li><div class="first-child-dl">Document proposal baselines, deliverables and outline delivery principles</div></li>
      <li><div class="first-child-dl">Conduct formal handover meeting between proposal manager, PD and PM</div></li>
      <li><div class="second-child-dl">Finalise and document the Project Management Plan</div></li>
      <li><div class="second-child-dl">Engage competent project resources</div></li>
      </ul>
    </div>
    </div>
    
<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectPlanning';"><div class="outline-cont-dl"><p>Project Planning</p></div>
 </div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Identify appropriately assessed and competent PD and PM when procurement document received</div></li>
     <li><div class="first-child-dl">Involve PD and PM in establishing proposed baselines/deliverables</div></li>
     <li><div class="first-child-dl">Conduct formal handover between Proposal Manager, PD and PM</div></li>
     <li><div class="second-child-dl">Understand client and contractual obligations</div></li>
     <li><div class="second-child-dl">Confirm deliverables with client</div></li>
     <li><div class="second-child-dl">Establish project baseline reference levels to monitor and control the project</div></li>
     <li><div class="second-child-dl">Set up relevent financial management system for the project</div></li>
     <li><div class="second-child-dl">Document required Project Management Plans aligned to project risk categorisation</div></li>
    </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectFinancialManagement';"><div class="outline-cont-dl"><p>Project Financial Management</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Handover the proposal commercial strategy to the delivery team</div></li>
     <li><div class="second-child-dl">Review proposal pricing against contractual obligations</div></li>
     <li><div class="second-child-dl">Finalise project estimating and pricing model </div></li>
     <li><div class="second-child-dl">Confirm project financial baselines</div></li>
     <li><div class="second-child-dl">Generate financial project summary report on relevant finance system </div></li>
     <li><div class="second-child-dl">Document Financial Management Plan </div></li>
     
  </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverworkProjectMobilisation';"><div class="outline-cont-dl"><p>Project Mobilization</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="second-child-dl">Document required Project Management Plans  </div></li>
     <li><div class="second-child-dl">Define project team roles and responsibilities, and identify competent individuals</div></li>
     <li><div class="second-child-dl">Identify competent Technical Leads and Technical Reviewers </div></li>
     <li><div class="second-child-dl">Hold Client kick off meeting  </div></li>
     <li><div class="second-child-dl">Brief Technical Reviewers on expectations, budget and requirements </div></li>
    </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectRiskManagement';"><div class="outline-cont-dl"><p>Project Risk Management </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Document risk categorisation of the project</div></li>
     <li><div class="first-child-dl">Identify proposal risks, assumptions and exclusions</div></li>
     <li><div class="first-child-dl">Conduct formal handover meeting between proposal manager, PD and PM</div></li>
     <li><div class="second-child-dl"> Understand client expectations aligned to contractual obligations and proposal commitments</div></li>
     <li><div class="second-child-dl">Review and validate risks and assumptions identified as part of the proposal </div></li>
     <li><div class="second-child-dl">Review project requirements and identify additional risks</div></li>
     <li><div class="second-child-dl">Document Risk Management Plan as part of the Project Management Plan</div></li>
     <li><div class="second-child-dl">Document the Project Risk Register</div></li>
     <li><div class="second-child-dl">Analyse and evaluate risks, identify owners and document mitigation plan</div></li>
     <li><div class="second-child-dl">Treat risks and/or schedule subsequent treatment</div></li>
</ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectInfoManagement';"><div class="outline-cont-dl"><p>Project Info Management</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl"> Identify proposal assumptions for management of Information </div></li>
     <li><div class="second-child-dl">Establish project information requirements and standards to be met </div></li>
     <li><div class="second-child-dl"> Establish information deliverables required and milestones</div></li>
     <li><div class="second-child-dl"> Establish information exchange requirements and means of sharing/publishing</div></li>
     <li><div class="second-child-dl">Confirm how information management responsibilities will be addressed within team </div></li>
     <li><div class="second-child-dl">Agree information delivery approach with client</div></li>
     <li><div class="second-child-dl"> Document Project Information Management plan as part of the Project Management Plan</div></li>
     <li><div class="second-child-dl">Update risk register with information management assumptions </div></li>
 </ul>
</div>
</div>
<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkClientSatisfaction';"><div class="outline-cont-dl"><p>Client Satisfaction </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Understand client requirements aligned to proposal commitments </div></li>
     <li><div class="first-child-dl">Conduct formal handover meeting between proposal manager, PD and PM </div></li>
     <li><div class="second-child-dl">Identify client requirements from offer commitments and contractual obligations</div></li>
     <li><div class="second-child-dl">Document Stakeholder Management Plan as part of the Project Management Plan</div></li>
  </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkTechnicalAssurance';"><div class="outline-cont-dl"><p>Technical Assurance</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Understand client requirements aligned to proposal commitments </div></li>
     <li><div class="first-child-dl">Conduct formal handover meeting between proposal manager, PD and PM </div></li>
     <li><div class="second-child-dl">Identify approach to ensure deliverables meet proposal offer commitments and contractual obligations</div></li>
     <li><div class="second-child-dl">Identify and document external compliance requirements </div></li>
     <li><div class="second-child-dl">Document learning from previous projects and updated guidance</div></li>
     <li><div class="second-child-dl">Document technical methodology and deliverables </div></li>
     <li><div class="second-child-dl">Identify competencies required to deliver the project</div></li>
     <li><div class="second-child-dl">Identify competent people to undertake technical assurance responsibilities</div></li>
     <li><div class="second-child-dl">Identify benchmark criteria for check and review assessment</div></li>
     <li><div class="second-child-dl">Document technical assurance requirements as part of Project Management Plan</div></li>
     <li><div class="second-child-dl">Document technical risks on the risk register</div></li>
</ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectPerformance';"><div class="outline-cont-dl"><p>Project Performance </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Identify proposal assumptions and exclusions aligned to proposal baseline reference levels</div></li>
     <li><div class="first-child-dl">Conduct formal handover meeting between proposal manager, PD and PM </div></li>
     <li><div class="second-child-dl">Establish project baseline reference levels to monitor and control the project</div></li>
     <li><div class="second-child-dl">Document Project Management Plan, aligned to project risk categorisation</div></li>
</ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectChangeControl';"><div class="outline-cont-dl"><p>Project Change Control</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Understand client requirements aligned to proposal commitments</div></li>
     <li><div class="second-child-dl">Understand contractual change mechanism aligned to contractual obligations</div></li>
     <li><div class="second-child-dl">Document Contract Administration Plan as part of the Project Management Plan  </div></li>
     <li><div class="second-child-dl">Develop Change Management Plan as part of the Project Management Plan</div></li>
     <li><div class="second-child-dl">Create change register </div></li>
  </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkExternalProjectProcurementManagement';"><div class="outline-cont-dl"><p>External Project Procurement Management </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl"> Document proposed procurement need in a plan</div></li>
     <li><div class="first-child-dl">Identify approved suppliers in line with procurement plan</div></li>
     <li><div class="first-child-dl">Consider commercial risk and ensure relevant protection in place </div></li>
     <li><div class="first-child-dl">Engage suppliers to obtain budgetary pricing </div></li>
     <li><div class="first-child-dl">Conduct formal handover meeting between proposal manager, PD and PM</div></li>
     <li><div class="second-child-dl">Review and document procurement requirements</div></li>
     <li><div class="second-child-dl">Document Procurement Plan as part of the Project Management Plan   </div></li>
     <li><div class="second-child-dl">Approve competent supplier(s)  </div></li>
     <li><div class="second-child-dl">Agree criteria for the evaluation of tenders</div></li>
     <li><div class="second-child-dl">Complete purchase requisition (or equivalent as required)</div></li>
     <li><div class="second-child-dl"> Complete tender process in line with documented plan </div></li>
     <li><div class="second-child-dl">Select preferred supplier</div></li>
     <li><div class="second-child-dl">Agree formal contract with supplier in line with LOA </div></li>
     <li><div class="second-child-dl">Document Contract Administration plan </div></li>
</ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectClosure';"><div class="outline-cont-dl"><p>Project Closure</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="second-child-dl">Understand contractual obligations in relation to archiving of project information </div></li>
     <li><div class="second-child-dl">Document project key success measures as part of the Project Management Plan </div></li>
     <li><div class="second-child-dl">Document client feedback requirements  </div></li>

</ul>
</div>
</div>
</div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "DeliverWorkStartJobTabComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>