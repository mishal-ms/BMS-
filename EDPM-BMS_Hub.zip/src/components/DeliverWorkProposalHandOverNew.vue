<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Proposal Handover</h2>
      <p>Starting a project right is critical to its success. Making sure there is an effective transition from the bid team to the delivery team significantly increases the chances of the project achieving its desired performance levels. Making sure handover is planned and executed at the right time enables the delivery team to quickly and efficiently understand any risks, opportunities, assumptions or exclusion that will impact delivery and to mobilize the project team appropriately.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkProposalHandover';">Requirements</button>
    <button class="tab-link active"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>

  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Identify appropriately assessed and competent PD and PM when procurement document received</h4>
  <p>The competence level of the PM and PD shall be commensurate with the risk, scale and complexity of the project. Mitigation measures shall be documented and implemented where competency of the PD and/or PM is not at the required level. This should be discussed as part of the gated process. For medium and high risk projects the PM and PD shall have completed the formal PM competency assessment procedure relevant to their business unit. The Project Technical Lead, Engineering Manager or equivalent should be appointed at the proposal stage to inform and influence the technical validity and commercial viability of the proposal.</p>
  <h4>Involve PD and PM in establishing the proposed baselines/deliverables</h4>
  <p>Where PM and PD is different to the proposal leads they shall be engaged and involved in the development of the proposed baselines to aid the seamless transition from proposal to delivery and to ensure validity and optimality of the technical proposal and pricing strategy. Before commitments are made to a client or internally to the business, a project baseline shall be established.</p>
  <h4>Document proposal baselines, deliverables and outline delivery principles</h4>
  <p>Proposed baseline reference levels shall be embeded in the draft PMP to ensure consistency between the proposal to the client and delivery of the project. The draft PMP shall define the principles, assumptions, exclusions and methodologies proposed to deliver the project. The draft PMP needs to outline the delivery strategy and should be informed by the PM and PD and technical leads.</p>
  <h4>Conduct formal handover meeting between proposal manager, PD and PM</h4>
  <p>Where the PM is different to the proposal lead the PM shall ensure a handover is conducted so they have a complete set of proposal related materials including contract, issued proposal, bid risk register, commercial data and other pertinent information. They shall gain assurance that correct Stage Gate and LOA approvals are in place prior to commencing delivery. The method of handover shall be dependent on the size, scale and complexity of the project. For large, complex projects the handover shall also involve Technical Leads. All  projects that meet the Major Project criteria shall follow the MPU requirements.</p>
  <h4>Finalise and document the Project Management Plan</h4>
  <p>The PM shall develop and document the Project Management Plan . This should be based on the draft PMP developed during the proposal phase.  The scale of the PMP shall be proportionate to the risk, scale and complexity of the project. For larger, complex projects the PMP should be the plan of plans containing multiple sub plans e.g. Project Execution Plan, Quality Plan, HSE Plan etc. For smaller. low complexity projects the PMP may be a single document.
    All projects that meet the Major Project criteria shall follow the MPU requirements.</p>

  <h4>Engage competent project resources</h4>
  <p>A successful project requires a balance of technical, managerial, commercial and leadership skills combined with intuitive judgement. The PM and PD should conduct appropriate searches for these resources. Staff competencies regarding requisite skills and experience shall be assessed as satisfactory by a suitably competent person using an objective approach such as knowledge of individual capabilities; feedback from qualified others on individual capabilities; past experiences; a competency framework.</p>
</div>
</div>
</div> 
</div>
<!-- Main content Container section end here -->


</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "DeliverWorkProposalHandoverNewComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>