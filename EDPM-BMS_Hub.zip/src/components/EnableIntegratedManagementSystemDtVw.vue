<template>
  <div>
    <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Integrated Management System</h2>
      <p>Management Systems are systematic frameworks designed to manage an organization's policies, procedures and processes and promote continual improvement within.  The implementation of a proven and effective Management System can help a business to improve operations, manage risk and promote stakeholder confidence.  A management system allows us to meet challenges by instilling good practice and validating, through certification we have a recognized and effective system to comply with client and external requirements; to protect the organization by embedding quality best practices and to grow our organization by extending our client reach and satisfaction. </p>
  </div>
  <div class="tabs">
        <button class="tab-link" onclick="window.location.href='#/EnableIntegratedManagementSystem';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='#/EnableIntegratedManagementSystemDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Establish, implement and maintain a management system  </h4>
  <p>A suitably competent person shall be identified to develop, manage and maintain an effective mangement system which documents core controls we expect everyone to follow.</p>
  <h4> Document and publish the scope of the management system</h4>
  <p>The boundaries and applicability of the management system shall be established to determine its scope The scope of the management system shall be documented and communicated to all relevant parties. When determining scope the organization shall consider: 
a) the external and internal issues 
b) requirements of relevant interested parties
c) products and services of the organization </p>
  <h4>Define and document controls and processes needed to meet ISO requirements  </h4>
  <p>The management system shall align to International standards; ISO9001; ISO14001 & ISO45001 and should consider all relelvant international standards which are applicable to the scope of the system. Relevant controls need to be identified and managed to ensure compliance to relevant ISO standards and enable external certification.</p>
  <h4>Document a change and deviation procedure</h4>
  <p>All changes or deviations to a process need to be managed through the formal change and deviation procedure. Any changes to the management system shall be sponsored by the relevant process owner and approved by the BMS Steering Committee.</p>
 <h4> Define an annual internal audit programme to measure conformance to the management system</h4>
  <p>An assurance programme shall be developed to enable conformance to the core controls documented on the BMS to be measured and monitored. Audit outcomes, including findings, will be documented and actions managed to closure.</p>

   <h4>Conduct an annual management review at sector level</h4>
  <p>An annual sector management review shall be conducted to review the performance and effectiveness of the management system. It shall be documented, along with any actions identified to improve the effectiveness and relevance of the system. All actions shall be managed to closure. A regional mangement review should take place to inform the sector management review.</p>

  <h4> Conduct an internal system audit of the management system at least once every 3 years</h4>
  <p>To ensure the ongoing alignment of the management system to ISO standards, client expectations and internal changes the management system shall be internally audited at least once every 3 years.</p>


</div>
</div>
  
  </div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "EnableIntegratedManagementSystemDtVwComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>