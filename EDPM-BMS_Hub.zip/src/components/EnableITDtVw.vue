<template>
  <div>
    <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>IT</h2>
      <p>IT is necessary to keep businesses running and growing. IT management and support is critical to leveraging and maximizing our business’s productivity, security, and growth. Without the right IT equipment, systems, procedures and security we will not be able to deliver to our clients needs and expectations and we could expose ourselves to cyber security breaches which could impact our reputation.</p>
  </div>
  <div class="tabs">
       <button class="tab-link" onclick="window.location.href='#/EnableIT';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='#/EnableITDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Approval for IT purchases must be in line with LOA</h4>
  <p>Approve all requests, purchase commitments, contracts or other agreements for IT equipment and related components, software and services in line with LOA.</p>
  <h4> Follow the technologocal standards set by IT Services</h4>
  <p>Ensure all IT equipment or computer software purchased meets the technologocal standards set by IT Services</p>
  <h4>Manage IT agreements and negotiations in line with Corporate procedures</h4>
  <p>Any agreement or negotiaton with an IT equipment supplier shall conform with the Procurement of Corporate Indirect Goods and Services Procedure and Cyber and Data Security Procedure</p>
  <h4>Dispose of all hardware through a company authorised by IT Services</h4>
  <p>Hardware must be disposed of through a disposal company authorized by IT Services according to the juridical and environmental norms concerning recycling and also following the corporate commitments in regards to High Level Sustainability Targets and Net Zero Carbon Routemap.</p>
 <h4> Use IT services for all software</h4>
  <p>All Software, including freeware or shareware, shall be provided and installed/deployed by IT Services.</p>
  <h4>Password protect all IT systems</h4>
  <p>SNC-Lavalin IT systems shall be password protected. Passwords shall never be shared or revealed to anyone, including IT Personnel. An account shall never be used by anyone but the individual to whom it has been issued.</p>

  <h4> Appropriately classify documents </h4>
  <p>All Engineering Services documents containing classified information shall have a formal document marking identifying the classification of the document. All documents should be classified. Employees shall prevent inappropriate or unauthorized access to, or disclosure of, any  information belonging to Engineering Services or entrusted by third parties</p>

  <h4> Document data security requirements for third party suppliers</h4>
  <p>Third party suppliers shall offer the same level of data protection as that required by Engineering Services. Before signing a contract with a third party that will handle SNC-Lavalin information a level of protection equivalent to the one specified in the SNC-L Cyber & Data Security procedure or better will be provided.</p>

</div>
</div>
  
  </div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "EnableITDtVwComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>