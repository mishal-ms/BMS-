<template>
  <div>
    <!-- Main content Container section start from here -->
    <div class="cont-container">
      <div class="content-wt">
        <div class="content-hd-text">
          <h2>Client Satisfaction</h2>
          <p>
            A quality deliverable begins and ends with understanding our client
            requirements and ensuring we deliver to these requirements. Only our
            clients can tell us if we meet their expectations. Collecting client
            feedback throughout the lifecycle of a project is key to helping us
            improve as a business, providing valuable insights as to whether our
            services, products and capabilities are fulfilling the needs and
            expectations of our clients, and informing where we should focus
            next to achieve even greater levels of client satisfaction.
          </p>
        </div>
        <div class="tabs">
          <button
            class="tab-link active"
            onclick="window.location.href='#/DeliverWorkClientSatisfaction';">
            Requirements
          </button>
          <button
            class="tab-link"
            onclick="window.location.href='#/DeliverWorkClientSatisfactionNew';">
            Additional Detail
          </button>
        <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
        </div>
        <div class="row-content">
          <div class="col-9">
            <div class="card-wrap">
              <div class="row-box">
                <div class="box" v-on:click="show('The Proposal lead shall fully understand client requirements, have assessed these as being reasonable and translated them into a clear scope of work. The project scope (deliverables and associated work to produce them) must be clearly defined in the contract. The PM shall ensure the project team and the client have a clear, shared understanding of the project scope and the allocation of responsibility for associated activities between ourselves, the client or other third parties. Any deviations in understanding or expectations from the contracted scope must be identified as potential changes There shall be an agreed process to record agreement of the scope.')">
                  <div class="content bg-fst-chld">
                    <p class="para-cont">
                      Understand client requirements aligned to proposal
                      commitments
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('To ensure understanding of the clients drivers and priorities all informaton & knowledge relating to the project shall be transferred between the proposal lead and PM where these are diifferent. The format of the handover shall be proportionate to the scale, risk and complexity of the project.')">
                  <div class="content bg-fst-chld">
                    <p class="para-cont">
                      Conduct formal handover meeting between proposal manager,
                      PD and PM
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Before commencing work there shall be documented evidence of a commitment from the client to procure and pay for our services. This should be a signed, agreed contract. Where a signed agreed contract is not in place appropriate approval, in  line with LoA approvals shall be in place. The client requirements and contract shall identify the client expectations on how they will be informed of project progress; change control and risk management etc. The PM shall ensure what we have commmitted to deliver has been translated into what we have contracted to deliver. The Project Management Plan needs to respond to our contractual obligations and agreed client commitments.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Identify client requirements from offer commitments and
                      contractual obligations
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The Stakeholder Management Plan sets out the preferred procedures, tools and techniques to be used in managing stakeholders. Stakeholder management involves identifying people or organizations that may be impacted or affected by the project, including the client. The Stakeholder Management Plan shall document the approach to gathering client feedbackat all levels during the lifecycle of the project.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Document Stakeholder Management Plan as part of the
                      Project Management Plan
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-rt" v-on:click="show('Mobilizing the project shall be planned and delivered in a timely manner to clearly communicate key stakeholders and the roles and responsibilities within the project team for engaging with key stakeholders. The PM shall  ensure internal and external project team members know who to communicate with and understand their level of delegated authority. The method for capturing and sharing client feedback, including client complaints shall be shared with the project team. ')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Formally mobilizing project outlining client requirements in
                      line with Stakeholder Management plan
                    </p>
                  </div>
                </div>
              </div>

              <div class="row-reverse">
                <div class="box" v-on:click="show('The PM shall deliver the brief to the defined scope ensuring the client is communicated with in a timely manner to understand project progress, any emerging risks and potential changes. Change and risk are the key drivers that impact on delivery. Failure to understand the implications of either and to address them can have severe commercial, contractual and legal consequences. Therefore ensuring that all parties are using current data and have addressed all reasonable risks is fundamental to successful delivery')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Manage scope of services in line with Project Management
                      Plan
                    </p>
                  </div>
                </div>
                <div class="box" v-on:click="show('Client satisfication may be measured formally through client surveys, agreed KPIs or client audit requirements or it may be through informal discussions. The Stakeholder Management Plan should define how formal feedback will be sought and shall agree milestones for a formal client satisfaction survey. The frequency and requirement for formally defined feedback shall be proportionate to the size, scale and complexity of the project but shall ensure the client has the opportunity to share feedback during, and at the end, of the project.')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Measure and document client satisfaction as defined in the
                      Project Management Plan
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Learning from client feedback should be shared with the wider project team during the project to inform improvements which will increase client satisfaction.')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Share key learning with Project Team
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Once the project is substantially closed client feedback shall be sought to document the level of client satisfaction; enable any issues to be resolved prior to project closure and to provide valuable learning for future projects. It should be carried out immediately prior to demobilisation of project resources to capture the wider project team perspective.')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Measure and document client satisfaction post deliverables
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Learning that has been captured during the delivery of the project shall be documented in a format that can be shared. All client feedback shall be archived with the wider project documentation.')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Archive client satisfaction information in line with
                      contractual obligations
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
              </div>
            </div>
          </div>
   <!-- <RightInformationPannel/> -->

           <div class="col-3">
            <div class="content-box">
              <div class="own-detail">
                <span
                  >Process Owner:
                  <strong class="bld-txt">Nick Welch</strong></span
                >
                <!-- <span
                  >Key Contact:
                  <strong class="bld-txt">Joann Clarke</strong></span
                > -->
              </div>
              <div class="ult-links">
                <h4>Useful links</h4>
                <a href="https://atkins.sharepoint.com/sites/dwh/html/index.aspx?OR=Teams-HL&CT=1649844968359&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjA0MDExMTQwMCJ9#/" target="_blank">Deliver Work Hub</a>
                <a href="https://atkins.sharepoint.com/sites/ESMS/SitePages/Glossary.aspx?OR=Teams-HL&CT=1649852129464&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjAzMjEwMDEwNyJ9" target="_blank">Glossary</a>
                <a href="https://atkins.sharepoint.com/sites/dwh/html/index.aspx#/design-principles" target="_blank">Design Principles</a>
                 <a href="https://atkins.sharepoint.com/sites/CommercialHub/html/index.aspx#/" target="_blank">Commercial Hub</a>
                  <a href="http://axis.eu.atkinsglobal.com/uk/projectbids/majorprojects/Pages/world_pmplan.aspx" target="_blank">MPU PMP</a>
                  <!-- <a href="http://communities.eu.atkinsglobal.com/sites/winworkhub/Pages/home.aspx">Win Work Hub</a> -->
                  <a href="https://atkins.sharepoint.com/sites/digitalservices/productportal/ClientPerception/Pages/default.aspx" target="_blank">Client Perception & Project Feedback</a>
              </div>
              <!-- <div class="ult-links">
                <h4>Training</h4>
                <a>xxxxxxx</a>
              </div> -->
              <div class="ult-links">
                <h4>Approved Deviations</h4>
                <a>None</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Main content Container section end here -->
    <!-- 
    <div class="row-reverse">
        <div class="box">
            <div class="content bg-th-chld">
                <p class="para-cont">Manage scope of services in line with Project Management Plan</p>
            </div>
        </div>
        <div class="box">
            <div class="content bg-th-chld">
                <p class="para-cont">Measure and document client satisfaction as defined in the Project Management Plan</p>
            </div>
            <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png" /></div>
        </div>
        <div class="box">
            <div class="content bg-th-chld">
                <p class="para-cont">Share key learning with Project Team </p>
            </div>
            <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png" /></div>
        </div>
        <div class="box">
            <div class="content bg-frth-chld">
                <p class="para-cont">Measure and document client satisfaction post deliverables</p>
            </div>
            <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png" /></div>
        </div>
        <div class="box">
            <div class="content bg-frth-chld">
                <p class="para-cont">Archive client satisfaction information in line with contractual obligations</p>
            </div>
            <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png" /></div>
        </div>
    </div> -->

    <!-- <div class="col-3">
    <div class="content-box">
        <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Martina Perrin</strong></span> <span>Key Contact: <strong class="bld-txt">Joann Clarke</strong></span></div>
        <div class="ult-links">
            <h4>Useful links</h4> <a>Win Work Hub</a> <a>Glossary</a> <a>Community</a>
        </div>
        <div class="ult-links">
            <h4>Training</h4> <a>xxxxxxx</a>
        </div>
        <div class="ult-links">
            <h4>Approved Deviations</h4> <a>xxxxxxx</a>
        </div>
    </div>
</div> -->
  </div>
</template>

<script>
import api from "@/service";
import router from "@/router";
import { mapActions } from "vuex";
import RightInformationPannel from "../components/RightInformationPannel.vue";
export default {
  name: "DeliverWorkClientSatisfactionComp",
  components: {RightInformationPannel},
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  methods: {
    ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
