<template>
    <div>
        


<!-- Main content Container section start from here -->
<div class="cont-container">
<div class="content-wt">
  <div class="content-hd-text">
      <h2>Controls and Assurance</h2>
      <p>Controls are put in place to drive efficiency and effectiveness in our delivery to clients. They enable the organization to grow and innovate based on continual improvement, providing predictability of our services and products. Assurance is about meeting the delivery and accountability needs of the organization, providing evidence-based assurances on the management of risks and internal controls, that may threaten the successful achievement of our plan.</p>
  </div>
  <div class="tabs">
     <button class="tab-link active" onclick="window.location.href='#/ProcessImplement';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/LeadProcessImplementDetailedView';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <div class="row-box">
        <div class="box" v-on:click="show('A management system defining the controls associated with Quality, Health, Safety and Environment shall be established, published and available to all employees,  aligned to ISO 9001, ISO 14001 & ISO 45001. The scope and audience for the management system shall be defined and reviewed annually to determine what is covered and who shall comply with the requirements.')">
          <div class="content bg-lead"><p class="para-cont">Establish management system</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('The management system shall be actively shared with all decisions makers using the system. Top management shall ensure conformity to the management system and where it cannot be followed ensure a formal deviation is sought.')">
          <div class="content bg-lead"><p class="para-cont">Embed the management system</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Top management shall be accountable for the management system ensuring reviews are undertaken at planned intervals to measure and monitor conformity and effectiveness.  All governance shall align and decision makers shall ensure all governance established within their span of control is aligned to the Management System.')">
          <div class="content bg-lead"><p class="para-cont">Demonstrate leadership and commitment to the management system</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('The management system shall be reviewed by top management at planned intervals to ensure its continued suitability, adequacy, effectiveness and alignment with the strategic direction of the organization. Decisions and actions arising from reviews shall be documented and managed to  closure.')">
          <div class="content bg-lead"><p class="para-cont">Establish mechanism to monitor and maintain effectiveness of Management System</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt" v-on:click="show('An Internal Audit plan, aligned to the management system, shall be agreed annually with a documented audit schedule.  The internal audit plan shall cover Quality, Health, Safety and Environment audits aligned to the requirements of the relevant ISO standards.')">
          <div class="content bg-lead"><p class="para-cont">Plan and schedule management system Internal Audits</p></div>
          </div>
      </div>
    

<div class="row-reverse-last-child">
  <div class="box" v-on:click="show('Internal Audit findings shall measure and identify conformity to the management system. Internal audits shall be documented and findings shall be communicated to all relevant stakeholders. Internal Audit actions shall be documented and tracked to closure and the outcomes of internal audits shall be reported to top management.')">
    <div class="content bg-lead"><p class="para-cont">Measure conformance to the management system</p></div>
  </div>
  <div class="box" v-on:click="show('Outputs that do not conform to defined requirements shall be identified and controlled to prevent unintended use or delivery. Mechanisms shall be established to highlight actual or potential risks in the business that may represent deviations from defined requirements to enable appropriate action to be taken.')">
    <div class="content bg-lead"><p class="para-cont">Establish problem and incident management mechanisms</p></div>
    <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
  </div>
</div>
  </div>




    </div>

    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span> </div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>

</div>
</div>  
</div>
<!-- Main content Container section end here -->



    </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions} from "vuex";
export default {
  name: "ProcessImplementComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
   methods: {
         ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
   },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
