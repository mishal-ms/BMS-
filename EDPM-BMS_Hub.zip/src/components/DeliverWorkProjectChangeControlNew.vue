<template>
    <div> 

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Project Change Control</h2>
      <p>It is important to manage change effectively in order to
            successfully deliver and realize the benefits of projects,
            programs and portfolios. The management of project change is the
            approach taken to move from the current to a future desired state
            using a controlled, coordinated and structured approach, in
            collaboration with stakeholders, and using the change mechanisms
            included in the contract.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkProjectChangeControl';">Requirements</button>
    <button class="tab-link active"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Understand client requirements aligned to proposal commitments</h4>
  <p>It is important to understand, prior to any formal contract signing, what commitments, promises or obligations have been made to the client in relation to our level of service or deliverables. Obligations may arise as a result of competitive dialogue, formal proposal discussions or singe source negotiations</p>
  <h4>Understand contractual change mechanism aligned to contractual obligations</h4>
  <p>The contract shall specify the mechanism or requirements for managing change. Under any contract there will be a defined change control mechanism, These may be standard change clauses or pre-agreed, amended or additional clauses. The requirements will be dependent on the contract type.</p>
  <h4>Document Contract Administration Plan as part of the Project Management Plan  </h4>
  <p>The Contract Administration Plan is the plan to deliver to the contract requirements. It summarizes how the contract will be managed between the client and ourselves. It confirms systems and processes to ensure we comply with the terms and conditions of the contract and performance, communications and non-conformities are effectively managed. The content of the contract administration plan should be proportionate to the value, risk and complexity of the contract.</p>

  <h4>Develop Change Management Plan as part of the Project Management Plan</h4>
  <p>The Change Management Plan summarizes how change shall be managed during the lifecycle of the project and who at the client organization shall instruct and authorize change. It is largely determined by the contractual agreement in place with the client. Before commencing delivery, appropriate procedures for change control should be established and agreed internally, aligned to the Contract Administration Plan. The Change Management Plan identifies the parameters of what constitutes change based on the scope and how the project team will manage change to ensure compliance to contractual obligations.</p>

  <h4>Create change register</h4>
  <p>It is essential to establish a register to capture and record changes which can be used to discuss and agree changes with the client during project delivery. Along with the register all correspondence relating to a change shall be saved in accordance with the agreed filing structure to provide a record of the change agreement.</p>

  <h4>Inform Project Team of the change management plan as part of Project Mobilization </h4>
  <p>Any person involved on the project may initiate or identify a change.  All members of the project team shall be aware of the potential for change and the consequences of any change. It is essential that the project team, including third party suppliers and project team members working in other divisions or business units, shall be briefed on the requirements within the Change Management Plan. This shall be communicated during project mobilization so that everyone is clear on approach to escalating changes and authority to approve changes.</p>

  <h4>Regularly review known changes and consider potential changes</h4>
  <p>When a change is identified by any member of the Project Team an initial review of the change shall identify the likely extent of the change in terms of effect on scope, budget, price, margin and program to the project; this is applied equally if the change is either an internal or external change. Any potential changes shall be communicated to the client and the project team to keep them fully informed so that everyone is aware of potential alterations to contract completion and price, including changes to internal budget and margin, thus creating a "no surprises" culture. The frequency of review should be proportionate to the size, scale and complexity of the project and the extent and scale of changes identified and shall take place prior to any changes being approved. 
    The Project Manager shall obtain the necessary approval for changes in advance of proceeding with any changes in line with the LOA.</p>

    <h4>Update change register to reflect potential and agreed changes </h4>
    <p>Its important that all potential and agreed changes are appropriately documented on the Change Register to ensure they are managed in line with the plan and any associated risks are managed and mitigated.</p>
  
    <h4>Review and gain agreement for changes with the client</h4>
    <p>A change to the project brief must be agreed in writing with the client whenever it becomes apparent that the input required is to change, or has changed, from the original brief.

      If the change has not been instigated by the client then, at the earliest opportunity, the source and impact of the change should be advised to the client to agree whether this change is required. At all stages contractual obligations, including time frames for communicating changes, shall be complied with.  
      
      If the client agrees there is merit in the change, then the impact shall be formally documented (sometimes called a change request) and communicated to the client for their written approval. The change request should focus upon the impact on the project (e.g. deliverables, program, including impacts to the critical path, resources, sub-contractors, costs), any mitigation measures being taken, requirements for authorization to proceed, the impact of delaying decisions and where it has been necessary to hold work or proceed at risk.</p>
      <h4>Approve all changes in line with the gated approval process where required</h4>
      <p>For significant changes the Service Delivery Process shall be followed. An independent review in line with the gated process shall be conducted upon awareness of significant change or on the request of a senior member of the business e.g. project director, commercial director, business unit head. A gated review shall also be conducted prior to working on any significant unapproved change or submitting a change request/order in response to a client request for a significant change.

        The Project Manager shall obtain the necessary approval for changes in advance of proceeding with any changes in line with the LOA.</p>
    
      <h4>Quantify and assess the impact of changes against the project baseline</h4>
      <p>The project baseline reference levels shall be reviewed and updated to reflect the impact of approved changes on project performance assumptions, including time, cost and quality, e.g. programme, schedule, scope, critical path, contingency, resources, sub-contractors, costs and any mitigation measures being taken.</p>
        <h4>Formally communicate the impact of the change to the project team</h4>
        <p>The project team, including third party suppliers and project team members from other divisions or business units, must be updated throughout the project on important changes that impact the project such as new design data, changes to requirements or customer instructions so that all teams are using relevant data and information.</p>
      
        <h4>Update project forecast to reflect changes </h4>
        <p>The Project Manager shall review the project forecast to ensure it represents the best current estimate of the eventual project out turn. Any changes impacting the financial performance of the project shall be reflected in the project finance system in a timely manner</p>
          <h4>Invoice changes as per contractual terms  </h4>
          <p>All changes need to be agreed with the client and invoiced in line with contractual obligations</p>
        
          <h4>Confirm with client contractual obligations are complete</h4>
          <p>The PM shall confirm with the client all final deliverables have addressed all changes identified during the project and contractual obligations have been met.</p>
            <h4>Collate and share learning from the project </h4>
            <p>Once the project is substantially closed a project review shall be carried out. The review shall collate the reasons for and impact of changes captured during project delivery that can be translated into future learning for projects.</p>
          
            <h4>Close project finances</h4>
            <p>The PM shall ensure all actual and potential changes have been realized, invoiced and paid before closing project finances. Any residual risks should be identified, assessed and documented on the project risk register. Project finances can only close once all risks have been mitigated.</p>
              <h4>Archive project change information in line with contractual obligations</h4>
              <p>All change records shall be retained and archived with the wider project documentation and in line with contractual obligations.</p>
            </div>
</div>  
</div>  
</div>
<!-- Main content Container section end here -->




</div>


</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "DeliverWorkProjectChangeControlNewComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>