<template>
  <div>
    <!-- Main content Container section start from here -->
    <div class="cont-container">
      <div class="content-wt">
        <div class="content-hd-text">
          <h2>Capture Planning</h2>
          <p>
            <strong class="bld-txt">Capture planning</strong> is the process of
            identifying opportunities, assessing the environment, and devising
            and implementing winning strategies focused on capturing a specific
            business opportunity. It helps us to position ourselves with our
            clients, so they prefer us and our solution to the exclusion of our
            competitors, or to at least to get them to prefer to do business
            with us prior to proposals being submitted. 40 to 80 percent of
            clients often decide whom they would prefer to buy from before
            proposals are submitted. Therefore, successful capture planning
            requires well formulated, action-oriented capture plans.
          </p>
        </div>
        <div class="tabs">
          <button
            class="tab-link active"
            onclick="window.location.href='xxxxx.html';"
          >
            Requirements
          </button>
          <button
            class="tab-link"
            onclick="window.location.href='#/CapturePlanningDetailedView';"
          >
            Additional Detail
          </button>
           <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
        </div>

        <div class="row-content">
          <div class="col-9">
            <div class="card-wrap">
              <div class="row-box">
                <div class="box" v-on:click="show('Identify and continually monitor for risk issues that could result in a No Go or that may require mitigation strategy, including contractual, pricing, & other risk. ')">
                  <div class="content bg-base">
                    <p class="para-cont">
                      Go/No Go conducted and opportunity confirmed to pursue
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Employ a mix of primary (interviews) and secondary (desk-based)research to develop a detailed understanding on client needs and demand drivers, spepcifically in the context of overall project spend goals.')">
                  <div class="content bg-base">
                    <p class="para-cont">
                      Analyse client context and drivers for pursuit
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Utilize a mix of available strategic marketing and bid tools to capture knowledge about client needs and demand drivers. Consult Win Work platforms and portals to access available resources and tools e.g. Blue Sheet and Gold Sheet.')">
                  <div class="content bg-base">
                    <p class="para-cont">Capture client intelligence</p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show(' Win Strategy should be informed by extensive client and competitor intelligence gathering. Win Strategy should clearly articulate why the the client would want to award us the opportunity over a competitor. ')">
                  <div class="content bg-base">
                    <p class="para-cont">Develop draft win strategy</p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-rt" v-on:click="show(' Should undertake basic assessments of competitive strengths and weakness. Shall utilize a variety of tools and research methodologies to undertake deep-dives on competitors and inform offensive and defensive bidding strategies. ')">
                  <div class="content bg-base">
                    <p class="para-cont">Complete competitor analysis</p>
                  </div>
                </div>
              </div>

              <div class="row-reverse-last-child">
                <div class="box" v-on:click="show('Bid Leads should complete an Opportunity Risk Register')">
                  <div class="content bg-base">
                    <p class="para-cont">Identify and document key risks</p>
                  </div>
                </div>
                <div class="box" v-on:click="show('Bid Teams shall be required to produce a Delivery Strategy document detailing aspects including (but not limited to) Win Themes, Partnering Strategy, Supply Chain Strategy, Resourcing Strategy.')">
                  <div class="content bg-base">
                    <p class="para-cont">
                      Identify delivery strategy including any partnering
                      requirements
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Identify resource requirements in Delivery Plan. ')">
                  <div class="content bg-base">
                    <p class="para-cont">
                      Identify competency requirements for key delivery team
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Identify and continually monitor for risk issues that could result in a No Go or that may require mitigation strategy, including contractual, pricing, & other risk.')">
                  <div class="content bg-base">
                    <p class="para-cont">Confirm Go/No Go</p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <RightInformationPannel/>
        </div>
      </div>
    </div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapActions } from "vuex";
import RightInformationPannel from "../components/RightInformationPannel";
export default {
  name: "CapturePlanningComp",
  components: {
    RightInformationPannel
  },
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  methods: {
     ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>