<template>
  <div>
    <!-- Main content Container section start from here -->
   <div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Capture Planning</h2>
      <p><strong class="bld-txt">Capture planning</strong> is the process of identifying opportunities, assessing the environment, and devising and implementing winning strategies focused on capturing a specific business opportunity. It helps us to position ourselves with our clients, so they prefer us and our solution to the exclusion of our competitors, or to at least to get them to prefer to do business with us prior to proposals being submitted. 40 to 80 percent of clients often decide whom they would prefer to buy from before proposals are submitted. Therefore, successful capture planning requires well formulated, action-oriented capture plans.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/CapturePlanning';">Requirements</button>
    <button class="tab-link active" > Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Go/No Go conducted and opportunity confirmed to pursue</h4>
  <p>Identify and continually monitor for risk issues that could result in a No Go or that may require mitigation strategy, including contractual, pricing, & other risk.</p>
  <h4>Analyse client context and drivers for pursuit</h4>
  <p>Employ a mix of primary (interviews) and secondary (desk-based)research to develop a detailed understanding on client needs and demand drivers, spepcifically in the context of overall project spend goals.</p>
  <h4>Capture client intelligence </h4>
  <p>Utilize a mix of available strategic marketing and bid tools to capture knowledge about client needs and demand drivers. Consult Win Work platforms and portals to access available resources and tools e.g. Blue Sheet and Gold Sheet.</p>
  <h4>Develop draft win strategy </h4>
  <p> Win Strategy should be informed by extensive client and competitor intelligence gathering. Win Strategy should clearly articulate why the the client would want to award us the opportunity over a competitor.</p>
  <h4>Complete Competitor analysis</h4>
  <p> Should undertake basic assessments of competitive strengths and weakness. Shall Utilize a variety of tools and research methodologies to undertake deep-dives on competitors and inform offensive and defensive bidding strategies.</p>

  <h4>Identify and document key risks  </h4>
  <p>Bid Leads should complete an Opportunity Risk Register</p>

  <h4>Identify Delivery strategy including any partnering requirements</h4>
  <p>Bid Teams shall be required to produce a "Delivery Strategy" document detailing aspects including (but not limited to) "Win Themes", "Partnering Strategy", "Supply Chain Strategy", "Resourcing Strategy".</p>


  <h4>Identify competency requirements for key delivery team </h4>
  <p>Identify resource requirements in Delivery Plan.</p>
  <h4>Confirm Go/No Go </h4>
  <p>Identify and continually monitor for risk issues that could result in a No Go or that may require mitigation strategy, including contractual, pricing, & other risk.</p>
</div>
</div>
  
</div>  
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "CapturePlanningDetailedViewComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>