<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Business Performance Management</h2>
      <p>Good business performance management is so much more than just delivering to our financial promises. It is about doing this in a way which is sustainable, within a strong ethical and moral framework, creating an environment where our people feel safe, included and considered and where we can all be proud of what we achieve and the success of our business. </p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/EnableBusinessPerformanceManagement';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/EnableBusinessPerformanceManagementDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <div class="row-box">
        <div class="box" v-on:click="show('An operational leadership team with suitable qualifications and experience shall be appointed to ensure delivery to the management system, including making sure the resources needed are available. Documented roles and responsibilities aligned to quality, health, safety and environment shall be establish within the sector.')">
          <div class="content content-enable"><p class="para-cont">Appoint suitable senior leadership  to ensure delivery to the management system</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('The appointed operational leadership team shall identify, document and share suitable governance to ensure the predictability and consistency of outcomes aligned to corporate and sector expectations. They shall publish the governance controls in a manner that is easily accessed and understood and conformance can be monitored.  ')">
          <div class="content content-enable"><p class="para-cont"> Establish suitable controls to enable delivery to the sector plan </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('The operational leadership team must comply with all legal, accounting standards and Corporate procedures, in maintaining financial records.  Business financial records and performance shall be reviewed monthly by the Sector, Region and Divisional leadership.  Business financial records shall be signed quarterly by the Sector President and Sector Senior Vice President Finance.')">
          <div class="content content-enable"><p class="para-cont">Maintain financial records </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Operational leaders shall put in place mechanisms to ensure client feedback is captured, monitored and shared to inform improvements and increase client satisfaction')">
          <div class="content content-enable"><p class="para-cont">Implement actions to meet customer requirements and enhance satisfaction</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt" v-on:click="show('Senior Leadership shall maintain awareness and compliance to legal and client requirements. relevant laws, regulations and Corporate requirements to drive compliance and continuous improvements in HSE. A suitably competent person shall be appointed to provide leadership and direction in safety on behalf of the leadership team.')">
          <div class="content content-enable"><p class="para-cont">Appoint responsible person to lead safety</p></div>
          </div>
      </div>
    

<div class="row-reverse-last-child">
  <div class="box" v-on:click="show('Demonstrating through our plans and controls our focus on keeping everyone out of harm and caring for the environment. Ensuring appropriate consultation and engagement with employees to drive improvements. Providing the right culture to attract, retain and motivate talented people as an employer of choice.')">
    <div class="content content-enable"><p class="para-cont">Provide a safe working place, managing the impact of our operations</p></div>
  </div>
  <div class="box" v-on:click="show('Senior leadership will identify, maintain and monitor the assurance programme necessary to deliver conformance to internal requirements. The responsibility of leadership shall be to drive improvements through the closure of identified actions.')">
    <div class="content content-enable"><p class="para-cont">Maintain and monitor conformance to internal requirements</p></div>
    <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
  </div>
  <div class="box" v-on:click="show('Leadership shall ensure the business is compliant with all relevant external requirements including; Legal, regulations, standards, client specifications, codes.')">
    <div class="content content-enable"><p class="para-cont">Drive and monitor compliance to external requirements</p></div>
    <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
  </div>
  <div class="box" v-on:click="show('Leadership shall ensure relevant health and wellbeing guidance and collateral is available to staff. They shall engage with employees to ensure wellbeing concerns are shared and appropriate improvement plans are established')">
    <div class="content content-enable"><p class="para-cont">Maintain a healthy workforce</p></div>
    <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
  </div>
</div>
  </div>
</div>
    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span></div>
      <div class="ult-links"><h4>Useful links</h4>
      <a href="https://km.snclavalin.com/pdce" target="_blank">Capability Hub</a></div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>
 </div>
  </div>
</div>
<!-- Main content Container section end here -->


</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions } from "vuex";
export default {
  name: "EnableBusinessPerformanceManagementcomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
   methods: {
     
          ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  // },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
   },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
