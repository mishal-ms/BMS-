<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>IT</h2>
      <p>IT is necessary to keep businesses running and growing. IT management and support is critical to leveraging and maximizing our business’s productivity, security, and growth. Without the right IT equipment, systems, procedures and security we will not be able to deliver to our clients needs and expectations and we could expose ourselves to cyber security breaches which could impact our reputation.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/EnableIT';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/EnableITDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <div class="row-box">
        <div class="box" v-on:click="show('Approve all requests, purchase commitments, contracts or other agreements for IT equipment and related components, software and services in line with LOA.')">
          <div class="content content-enable"><p class="para-cont">Approval for IT purchases must be in line with LOA</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Ensure all IT equipment or computer software purchased meets the technologocal standards set by IT Services.')">
          <div class="content content-enable"><p class="para-cont">Follow the technologocal standards set by IT Services</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Any agreement or negotiaton with an IT equipment supplier shall conform with the Procurement of Corporate Indirect Goods and Services Procedure and Cyber and Data Security Procedure.')">
          <div class="content content-enable"><p class="para-cont">Manage IT agreements and negotiations in line with Corporate procedures</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Hardware must be disposed of through a disposal company authorized by IT Services according to the juridical and environmental norms concerning recycling and also following the corporate commitments in regards to High Level Sustainability Targets and Net Zero Carbon Routemap.')"> 
          <div class="content content-enable"><p class="para-cont">Dispose of all hardware through a company authorised by IT Services</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt" v-on:click="show('All Software, including freeware or shareware, shall be provided and installed/deployed by IT Services.')">
          <div class="content content-enable"><p class="para-cont">Use IT services for all software </p></div>
          </div>
      </div>
    

<div class="row-reverse-last-child">
  <div class="box" v-on:click="show('SNC-Lavalin IT systems shall be password protected. Passwords shall never be shared or revealed to anyone, including IT Personnel. An account shall never be used by anyone but the individual to whom it has been issued.')">
    <div class="content content-enable"><p class="para-cont">Password protect all IT systems</p></div>
  </div>
  <div class="box" v-on:click="show('All Engineering Services documents containing classified information shall have a formal document marking identifying the classification of the document. All documents should be classified. Employees shall prevent inappropriate or unauthorized access to, or disclosure of, any  information belonging to Engineering Services or entrusted by third parties.')">
    <div class="content content-enable"><p class="para-cont">Appropriately classify documents </p></div>
    <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
  </div>
  <div class="box" v-on:click="show('Third party suppliers shall offer the same level of data protection as that required by Engineering Services. Before signing a contract with a third party that will handle SNC-Lavalin information a level of protection equivalent to the one specified in the SNC-L Cyber & Data Security procedure or better will be provided.')">
    <div class="content content-enable"><p class="para-cont">Document data security requirements for third party suppliers</p></div>
    <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
  </div>
  
</div>
  </div>
</div>

    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span> </div>
      <div class="ult-links"><h4>Useful links</h4>
        <a href="https://atkins.service-now.com/MyIT" target="_blank">My IT</a>
        <a href="https://infozone.snclavalin.com/en/sectors-functions/functions/information-technology/" target="_blank">SNC-Lavalin IT page on Infozone</a>
      </div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>

    </div>
  </div>
</div>
<!-- Main content Container section end here -->


</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions} from "vuex";
export default {
  name: "EnableITcomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
   methods: {
          ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
   },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
