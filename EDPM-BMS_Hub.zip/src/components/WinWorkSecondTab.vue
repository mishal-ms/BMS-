<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
 <!-- <div class="cont-row-wrapper">
   <div class="exp-box"><p>Explore the Market</p></div>
   <div class="outline-box">
     <div class="outline-cont" onclick="window.location.href='#/StragicPositioning';"><p>Strategic Positioning</p></div>
     <div class="outline-cont" onclick="window.location.href='#/ClientDevelopment';"><p>Client Development</p></div>
  </div>
   <div class="scroll-area-fx">
   <ul class="list-box">
      <li><div class="box-pklight">Corporate Strategy communicated</div></li>
      <li><div class="box-pklight">Strategic Markets identified globally</div></li>
      <li><div class="box-pklight">Global Market Strategies defined and shared with relevant market networks</div></li>
      <li><div class="box-pklight">Regional Market priorities defined and documented in line with Market Strategy</div></li>
      <li><div class="box-pklight">Formal measures identified to enable monitoring of delivery to strategy and priorities</div></li>
      </ul>
  <ul class="list-box">
    <li><div class="box-pklight">Market priorities identified</div></li>
    <li><div class="box-pklight">Key clients identified</div></li>
    <li><div class="box-pklight">Identify measures to monitor performance against Client Account Management Plan</div></li>
    <li><div class="box-pklight">Undertake Client research to build understanding</div></li>
    <li><div class="box-pklight">Identify Key Accounts based on defined criteria</div></li>
    <li><div class="box-pklight">Develop Client Account Management Plan for every client</div></li>
    <li><div class="box-pklight">Define and align client engagement at all levels</div></li>
    <li><div class="box-pklight">Review delivery to the Client Account Management Plan</div></li>
    <li><div class="box-pklight">Formal Client perception feedback received</div></li>
    <li><div class="box-pklight">Feedback from Client perception incorporated into Client Account Plan</div></li>
  </ul>
</div>
</div> -->


 <div class="cont-row-wrapper">
  <div class="exp-box"><p>Develop the opportunity</p></div>
  <div class="outline-box">
    <div class="outline-cont-sd-row" onclick="window.location.href='#/OpportunityIdentification';"><p>Opportunity Identification</p></div>
    <div class="outline-cont-sd-row" onclick="window.location.href='#/CapturePlanning';"><p>Capture Planning</p></div>
 </div>
  <div class="scroll-area-fx">
  <ul class="list-box">
     <li><div class="box-pkdark">Identify strategy and market priorities</div></li>
     <li><div class="box-pkdark">Identify target clients</div></li>
     <li><div class="box-pkdark">Identify pipeline of opportunities aligned to market priorities</div></li>
     <li><div class="box-pkdark">Record pipeline of opportunties on relevant client management system</div></li>
     <li><div class="box-pkdark">Review opportunities in pipeline and manage weighting based on client and competitor analysis</div></li>
     <li><div class="box-pkdark">Review and monitor the capture plan relevant to size of opportunity</div></li>
     <li><div class="box-pkdark">Identify pursuit investment</div></li>
     <li><div class="box-pkdark">Select opportunities and confirm Go/No Go</div></li>
     <li><div class="box-pkdark">Prepare for the potential opportunity using the capture planning process</div></li>
  </ul>
 <ul class="list-box">
   <li><div class="box-pkdark">Go/No Go conducted and opportunity confirmed to pursue</div></li>
   <li><div class="box-pkdark">Analyse client context and drivers for pursuit</div></li>
   <li><div class="box-pkdark">Capture client intelligence</div></li>
   <li><div class="box-pkdark">Develop draft win strategy</div></li>
   <li><div class="box-pkdark">Complete competitor analysis</div></li>
   <li><div class="box-pkdark">Identify and document key risks</div></li>
   <li><div class="box-pkdark">Identify delivery strategy including any partnering requirements</div></li>
   <li><div class="box-pkdark">Identify competency requirements for key delivery team</div></li>
   <li><div class="box-pkdark">Confirm Go/No Go</div></li>
 </ul>
</div>
</div>

<!-- <div class="cont-row-wrapper">
  <div class="exp-box-bd-last"><p>Bid it and Win It</p></div>
  <div class="outline-box">
    <div class="outline-cont-th-row" onclick="window.location.href='#/ProposalManagement';"><p>Proposal Management - Qualifying Proposal </p></div>
    <div class="outline-cont-th-row" onclick="window.location.href='#/ProposalManagement';"><p>Proposal Management - Commercial Proposal</p></div>
    <div class="outline-cont-th-last-chld" onclick="window.location.href='#/PostSubmission';"><p>Post Submission</p></div>
</div>
  <div class="scroll-area-fx">
  <ul class="list-box-last-child">
     <li><div class="box-bludk">Procurement document received</div></li>
     <li><div class="box-bludk">Review procuarement documentation</div></li>
     <li><div class="box-bludk">Decision to confirm continued pursuit and investment</div></li>
     <li><div class="box-bludk">Agree pursuit Manager/Director</div></li>
     <li><div class="box-bludk">Agree pursuit budget</div></li>
     <li><div class="box-bludk">Identify additional risks and update register</div></li>
     <li><div class="box-bludk">Conduct Go/No Go to confirm investment</div></li>
     <li><div class="box-bludk">Confirm the pursuit team and to include Delivery Project Director/Project Manager</div></li>
     <li><div class="box-bludk">Develop the Proposal Management Plan</div></li>
     <li><div class="box-bludk">Share capture planning information via a kick off meeting with pursuit team</div></li>
     <li><div class="box-bludk">Submit clarifying questions to client and monitor responses</div></li>
     <li><div class="box-bludk">Define key messages and differentiators for win strategy</div></li>
     <li><div class="box-bludk">Develop answer plans and technical response strategy</div></li>
     <li><div class="box-bludk">Complete pursuit responses</div></li>
     <li><div class="box-bludk">Conduct full pursuit response review</div></li>
     <li><div class="box-bludk">Submit response to client </div></li>
     <li><div class="box-bludk">Update sales database</div></li>
  </ul>
 <ul class="list-box-last-child">
   <li><div class="box-bludk">Analyse how pricing can be structured to maximise scoring</div></li>
   <li><div class="box-bludk">Develop the price to win strategy</div></li>
   <li><div class="box-bludk">Identify commercial risks and add to risk registe</div></li>
   <li><div class="box-bludk">Define supply chain strategy</div></li>
   <li><div class="box-bludk">Identify resource requirements and cost</div></li>
   <li><div class="box-bludk">Develop pricing proposal</div></li>
 </ul>
 <ul class="list-box-last-child">
  <li><div class="box-bludk">Submit response to client</div></li>
  <li><div class="box-bludk">Update sales database</div></li>
  <li><div class="box-bludk">Monitor client instructions</div></li>
  <li><div class="box-bludk">Identify presentation and/or interview team</div></li>
  <li><div class="box-bludk">Draft relevant presentation/interview material</div></li>
  <li><div class="box-bludk">Rehearse presentation and embed learning</div></li>
  <li><div class="box-bludk">Attend client interview/presentation</div></li>
  <li><div class="box-bludk">Debrief with presentation team and document learning</div></li>
  <li><div class="box-bludk">Update sales database when outcome received</div></li>
  <li><div class="box-bludk">Negotiate contractual terms and conditions and pricing with client</div></li>
  <li><div class="box-bludk">Sign contract</div></li>
  <li><div class="box-bludk">Update sales database</div></li>
  <li><div class="box-bludk">Document learning from experience</div></li>
  <li><div class="box-bludk">Formal handover to delivery team</div></li>
</ul>
</div>
</div> -->
</div>
</div>
<!-- Main content Container section end here -->



    </div>
</template>

<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "WinWorkAllStepsComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>