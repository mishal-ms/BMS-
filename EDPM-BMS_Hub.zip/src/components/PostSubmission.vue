<template>
    <div>


<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Post Submission</h2>
      <p><strong class="bld-txt">Post submission:</strong> Involves taking a proactive approach to managing the Pursuit Opportunity post the submission, by establishing feedback mechanisms that help to drive the transfer of knowledge, intelligence, key lessons learned, and the continuous improvement of Bidding best practices. This can be achieved by a number of ways, including by driving a Growth Mindset in Project Feedback and implementing processes for capturing client feedback and “soft metrics” effectively and consistently, and by adopting common process for capturing and reporting Win/Loss data.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" >Requirements</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';"> Additional Detail</button> -->
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">

      <div class="row-box">
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Submit response to client</p></div>
          <div class="arrow-img"><img src="../assets/../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Update sales database</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Monitor client instructions</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Identify presentation and/or interview team</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt">
          <div class="content bg-prop cursor-none"><p class="para-cont">Draft relevant presentation/interview material</p></div>
          </div>
      </div>

       <div class="row-reverse">
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Rehearse presentation and embed learning</p></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Attend client interview/presentation</p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Debrief with presentation team and document learning</p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Update sales database when outcome received</p></div>
           <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-lt">
          <div class="content bg-prop cursor-none"><p class="para-cont">Negotiate contractual terms and conditions and pricing with client</p></div>
           <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        </div>

      <div class="row-box">
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Sign contract</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Update sales database</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Document learning from experience</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Formal handover to delivery team</p></div>
        </div>
        </div>
</div>
</div>

   <div class="col-3">
    <div class="content-box">
        <div class="own-detail">
            <span>Process Owner:
                <strong class="bld-txt">Martina Perrin</strong></span>
            <!-- <span>Key Contact:
                <strong class="bld-txt">Joann Clarke</strong></span> -->
        </div>
        <div class="ult-links">
            <h4>Useful links</h4>
            <a href="http://communities.eu.atkinsglobal.com/sites/winworkhub/Pages/home.aspx">Win Work Hub</a>
            <!-- <a>Community</a> -->
            <a href=" http://visionapp.na.atkinsglobal.com/VisionClient/">Vision Sales Database for US</a>
            <a href="https://sncl-d365.crm11.dynamics.com/apps/snclsales">SNCL Sales Enterprise Users</a>
            <a href="https://sncl-d365.crm11.dynamics.com/apps/snclstm">Sales Team Member</a>
            <a href="https://atkins.sharepoint.com/sites/GWWPDP/SitePages/Home.aspx">Engineering Services Capture & Pursuit Toolkit </a>
            <a href="https://atkins.sharepoint.com/sites/digitalservices/productportal/ClientPerception/Pages/default.aspx">Client Perception & Project Feedback </a>
            <a href="https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/" target="_blank">Global Design Framework </a>

           




        </div>
        <!-- <div class="ult-links">
                <h4>Training</h4>
                <a>None</a>
              </div> -->
        <div class="ult-links">
            <h4>Approved Deviations</h4>
            <a>None</a>
        </div>
    </div>
</div>

    </div>
  </div>
</div>
<!-- Main content Container section end here -->




    </div>
</template>


<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
import RightInformationPannel from "../components/RightInformationPannel.vue";
export default {
  name: "PostSubmissionComp",
  components: {
    RightInformationPannel
  }
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>