<template>
  <div>
    <!-- Main content Container section start from here -->
    <div class="cont-container">
      <div class="content-wt">
        <div class="content-hd-text">
          <h2>Project Change Control</h2>
          <p>
            It is important to manage change effectively in order to
            successfully deliver and realize the benefits of projects,
            programs and portfolios. The management of project change is the
            approach taken to move from the current to a future desired state
            using a controlled, coordinated and structured approach, in
            collaboration with stakeholders, and using the change mechanisms
            included in the contract.
          </p>
        </div>
        <div class="tabs">
          <button class="tab-link active">Requirements</button>
          <button
            class="tab-link"
            onclick="window.location.href='#/DeliverWorkProjectChangeControlNew';"
          >
            Additional Detail
          </button>
     <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button>  -->
        </div>
        <div class="row-content">
          <div class="col-9">
            <div class="card-wrap">
              <div class="row-box">
                <div class="box" v-on:click="show('It is important to understand, prior to any formal contract signing, what commitments, promises or obligations have been made to the client in relation to our level of service or deliverables. Obligations may arise as a result of competitive dialogue, formal proposal discussions or singe source negotiations')">
                  <div class="content bg-fst-chld">
                    <p class="para-cont">
                      Understand client requirements aligned to proposal
                      commitments
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The contract shall specify the mechanism or requirements for managing change. Under any contract there will be a defined change control mechanism, These may be standard change clauses or pre-agreed, amended or additional clauses. The requirements will be dependent on the contract type.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Understand contractual change mechanism aligned to
                      contractual obligations
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The Contract Administration Plan is the plan to deliver to the contract requirements. It summarizes how the contract will be managed between the client and ourselves. It confirms systems and processes to ensure we comply with the terms and conditions of the contract and performance, communications and non-conformities are effectively managed. The content of the contract administration plan should be proportionate to the value, risk and complexity of the contract. ')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Document Contract Administration Plan as part of the
                      Project Management Plan
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The Change Management Plan summarizes how change shall be managed during the lifecycle of the project and who at the client organization shall instruct and authorize change. It is largely determined by the contractual agreement in place with the client. Before commencing delivery, appropriate procedures for change control should be established and agreed internally, aligned to the Contract Administration Plan. The Change Management Plan identifies the parameters of what constitutes change based on the scope and how the project team will manage change to ensure compliance to contractual obligations.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Develop Change Management Plan as part of the Project
                      Management Plan
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-rt" v-on:click="show('It is essential to establish a register to capture and record changes which can be used to discuss and agree changes with the client during project delivery. Along with the register all correspondence relating to a change shall be saved in accordance with the agreed filing structure to provide a record of the change agreement.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">Create change register</p>
                  </div>
                </div>
              </div>

              <div class="row-reverse">
                <div class="box" v-on:click="show('Any person involved on the project may initiate or identify a change.  All members of the project team shall be aware of the potential for change and the consequences of any change. It is essential that the project team, including third party suppliers and project team members working in other divisions or business units, shall be briefed on the requirements within the Change Management Plan. This shall be communicated during project mobilisation so that everyone is clear on approach to escalating changes and authority to approve changes.')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Inform Project Team of the change management plan as part
                      of Project Mobilization
                    </p>
                  </div>
                </div>
                <div class="box" v-on:click='show("When a change is identified by any member of the Project Team an initial review of the change shall identify the likely extent of the change in terms of effect on scope, budget, price, margin and program to the project; this is applied equally if the change is either an internal or external change. Any potential changes shall be communicated to the client and the project team to keep them fully informed so that everyone is aware of potential alterations to contract completion and price, including changes to internal budget and margin, thus creating a \"no surprises\" culture. The frequency of review should be proportionate to the size, scale and complexity of the project and the extent and scale of changes identified and shall take place prior to any changes being approved. The Project Manager shall obtain the necessary approval for changes in advance of proceeding with any changes in line with the LOA.")'>
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Regularly review known changes and consider potential
                      changes
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Its important that all potential and agreed changes are appropriately documented on the Change Register to ensure they are managed in line with the plan and any associated risks are managed and mitigated.')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Update change register to reflect potential and agreed
                      changes
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('A change to the project brief must be agreed in writing with the client whenever it becomes apparent that the input required is to change, or has changed, from the original brief. If the change has not been instigated by the client then, at the earliest opportunity, the source and impact of the change should be advised to the client to agree whether this change is required. At all stages contractual obligations, including time frames for communicating changes, shall be complied with. If the client agrees there is merit in the change, then the impact shall be formally documented (sometimes called a change request) and communicated to the client for their written approval. The change request should focus upon the impact on the project (e.g. deliverables, program, including impacts to the critical path, resources, sub-contractors, costs), any mitigation measures being taken, requirements for authorization to proceed, the impact of delaying decisions and where it has been necessary to hold work or proceed at risk.')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Review and gain agreement for changes with the client
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-lt" v-on:click="show('For significant changes the Service Delivery Process shall be followed. An independent review in line with the gated process shall be conducted upon awareness of significant change or on the request of a senior member of the business e.g. project director, commercial director, business unit head. A gated review shall also be conducted prior to working on any significant unapproved change or submitting a change request/order in response to a client request for a significant change. The Project Manager shall obtain the necessary approval for changes in advance of proceeding with any changes in line with the LOA.')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Approve all changes in line with the gated approval
                      process where required
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
              </div>

              <div class="row-box">
                <div class="box" v-on:click="show('The project baseline reference levels shall be reviewed and updated to reflect the impact of approved changes on project performance assumptions, including time, cost and quality, e.g. programme, schedule, scope, critical path, contingency, resources, sub-contractors, costs and any mitigation measures being taken..')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Quantify and assess the impact of changes against the
                      project baseline
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The project team, including third party suppliers and project team members from other divisions or business units, must be updated throughout the project on important changes that impact the project such as new design data, changes to requirements or customer instructions so that all teams are using relevant data and information.')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Formally communicate the impact of the change to the
                      project team
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The Project Manager shall review the project forecast to ensure it represents the best current estimate of the eventual project out turn. Any changes impacting the financial performance of the project shall be reflected in the project finance system in a timely manner. ')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Update project forecast to reflect changes
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('All changes need to be agreed with the client and invoiced in line with contractual obligations')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Invoice changes as per contractual terms
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-lt" v-on:click="show('The PM shall confirm with the client all final deliverables have addressed all changes identified during the project and contractual obligations have been met. ')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont para-wrd">
                      Confirm with client contractual obligations are complete
                    </p>
                  </div>
                </div>
              </div>

              <div class="row-reverse-last-child">
                <div class="box" v-on:click="show('Once the project is substantially closed a project review shall be carried out. The review shall collate the reasons for and impact of changes captured during project delivery that can be translated into future learning for projects.')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Collate and share learning from the project
                    </p>
                  </div>
                </div>
                <div class="box" v-on:click="show('The PM shall ensure all actual and potential changes have been realized, invoiced and paid before closing project finances. Any residual risks should be identified, assessed and documented on the project risk register. Project finances can only close once all risks have been mitigated.')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">Close project finances</p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('All change records shall be retained and archived with the wider project documentation and in line with contractual obligations.')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Archive project change information in line with
                      contractual obligations
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
              </div>
            </div>
          </div>
   <!-- <RightInformationPannel/> -->

          <div class="col-3">
            <div class="content-box">
              <div class="own-detail">
                <span
                  >Process Owner:
                  <strong class="bld-txt">Nick Welch</strong></span
                >
                <!-- <span
                  >Key Contact:
                  <strong class="bld-txt">Joann Clarke</strong></span
                > -->
              </div>
              <div class="ult-links">
                <h4>Useful links</h4>
                <a href="https://atkins.sharepoint.com/sites/dwh/html/index.aspx?OR=Teams-HL&CT=1649844968359&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjA0MDExMTQwMCJ9#/" target="_blank">Deliver Work Hub</a>
                <a href="https://atkins.sharepoint.com/sites/ESMS/SitePages/Glossary.aspx?OR=Teams-HL&CT=1649852129464&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjAzMjEwMDEwNyJ9" target="_blank">Glossary</a>
                <a href="http://axis.eu.atkinsglobal.com/uk/projectbids/majorprojects/Pages/world_pmplan.aspx" target="_blank">MPU PMP</a> 
                <a href="https://atkins.sharepoint.com/sites/CommercialHub/html/index.aspx#/" target="_blank">Commercial Hub</a>
                <a href="https://atkins.sharepoint.com/sites/dwh/html/index.aspx#/design-principles" target="_blank">Design Principles</a>
                <a href="https://atkins.sharepoint.com/sites/CommercialHub/html/index.aspx#/theme/service-delivery-process" target="_blank">Service Delivery Procedure</a>
              </div>
              <!-- <div class="ult-links">
                <h4>Training</h4>
                <a>xxxxxxx</a>
              </div> -->
              <div class="ult-links">
                <h4>Approved Deviations</h4>
                <a>None</a>
              </div>
            </div>
          </div> 
        </div>
      </div>
    </div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapActions } from "vuex";
// import RightInformationPannel from "../components/RightInformationPannel.vue";
export default {
  name: "DeliverWorkProjectChangeControlComp",
  // components: {RightInformationPannel}
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  methods: {
    ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>