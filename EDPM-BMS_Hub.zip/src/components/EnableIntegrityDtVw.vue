<template>
  <div>
    <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
       <h2>Integrity</h2>
      <p>Integrity is important to provide opportunities for people to achieve their potential, enabling them to feel valued not just for what they offer now but for their future potential. It provides opportunity for people to grow and increase their levels of engagement and satisfaction through the achievement of their goals and those of the organization.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/EnableIntegrity';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='#/EnableIntegrityDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>A <span class="text-underline-cl">Gifts and Hospitality</span> Scorecard shall be completed in line with SNC-L requirements  </h4>
  <p>A Gifts & Hospitality Scorecard shall be completed when: any government official is involved; where any other kind of third party is involved and it exceeds local country thresholds.</p>

  <h4>All <span class="text-underline-cl">donations and sponsorships</span> shall be recorded on the SNC-L Online Approval Tool and adhere to the LoA Policy</h4>
  <p>All donations and sponsorships shall be recorded on the SNC-L Online Approval Tool and adhere to the LoA Policy Integrity Offices shall carry out due diligence on proposed beneficiaries.</p>

  <h4><span class="text-underline-cl">Counterparty checks</span> shall be undertaken at the inception of all new business relationships</h4>
  <p>Counterparty checks shall be undertaken at the inception of all new business relationships</p>
  
  <h4><span class="text-underline-cl">Trade Compliance/Sanction Control</span> - Personnel shall ensure any country in which work would take place is not sanctioned or embargoed </h4>
  <p>Prior to undertaking any business activities in a foreign country SNC-L Personnel shall ensure the country in which the work would take place is not sanctioned or embargoed.</p>

  <h4><span class="text-underline-cl">Integrity Project Endorsement</span> - Supplier Checks shall be completed prior to undertaking business</h4>
  <p>Prior to undertaking any business and as part of preparation and Bid approval Client Check; Country Check, Supplier Checks shall be completed.</p>

   <h4>All SNC-L Personnel must follow the <span class="text-underline-cl">Code of Conduct</span> and on an annual basis complete the Code of Conduct Certification</h4>

  <h4><span class="text-underline-cl">Governance Framework</span> - SNC-L Personnel must seek a formal deviation when unable to follow Level 1 and Level 2 SNC-L governance requirements.</h4>
  <h4><span class="text-underline-cl">Data Compliance</span> principles and requirements shall be followed.</h4>
  <h4><span class="text-underline-cl">Modern Slavery and Human Trafficking</span> - All supply chain partners shall agree to follow the Supplier Code of Conduct </h4>
  <h4><span class="text-underline-cl">Business Partners</span> - Risk based due diligence shall be completed to verify prospective Business Partners</h4>
  <p>Risk based due diligence shall be completed to verify prospective Business Partners are persons or entities of integrity and possess the necessary background, reputation and qualifications for the service to be rendered. </p>


  <h4><span class="text-underline-cl">Business Partners</span> - Approval of the Sector President and Chief Integrity Officer is required for representatives or sponsors </h4>
  <p>Any agreement where a Third Party may be acting as a representative or Sponsor shall require the approval of the Sector President and Chief Integrity Officer </p>
  <h4><span class="text-underline-cl">Duty to Report/Investigation</span> - Personnel shall act appropriately and in a timely manner to prevent or detect improper conduct arising from illegal or unethical behaviour.</h4>
  <h4><span class="text-underline-cl">Duty to Report/Investigation</span> - Personnel shall disclose any concerns, complaints or allegations of known or suspected wrongdoing or misconduct </h4>



</div>
</div>
  
  </div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "EnableIntegrityDtVwComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>