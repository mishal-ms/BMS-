<template>
    <div>
<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Enterprise Risk Management </h2>
      <p>Effective Enterprise Risk Management helps us manage our risks and maximize opportunities. It helps identify threats that could affect the functioning and capability of our organization to deliver to our strategy and achieve our objectives.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/EnableEnterpriseRiskManagement';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/EnableEnterpriseRiskManagementDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <div class="content-hd-text">
      <h2>Business Operational Risks</h2>
  </div>
      <div class="row-box">
        <div class="box" v-on:click="show('Business risks shall be identified and documented on the ARM Risk Register, identifying owners, risk level, and mitigation actions.')">
          <div class="content content-enable"><p class="para-cont">Identify and document Business risks</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Operational Business risks shall be reviewed by the region at least monthly.')">
          <div class="content content-enable"><p class="para-cont">Review operational business risks  </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Regional Commercial Director shall review risks and identify risks to be escalated to Regional leadership.')">
          <div class="content content-enable"><p class="para-cont">Escalate risks as appropriate</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Significant Operational Risks shall be reviewed and escalated, as appropriate, to Audit and Risk sector leadership team.')">
          <div class="content content-enable"><p class="para-cont">Escalate risks to Sector leadership at least quarterly</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Actions from the Audit and Risk review shall be reported to and actioned by the relevant Regional Commercial Director.')">
          <div class="content content-enable"><p class="para-cont">Actions resulting from reviews shall be managed to closure</p></div>
          </div>
      </div>  

<div class="content-hd-text">
      <h2>Sector Functional Risks </h2>
  </div>
      <div class="row-box">
        <div class="box" v-on:click="show('Sector functional risks shall be identified and documented on the ARM Risk Register, identifying owners, risk level, and mitigation actions.')">
          <div class="content content-enable"><p class="para-cont">Identify and document sector functional risks</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Sector Functional risks shall be reviewed by functional leadership at least quarterly.')">
          <div class="content content-enable"><p class="para-cont">Review sector functional risks </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Sector Function Lead shall review risks and identify risks to be escalated to Sector leadership.')">
          <div class="content content-enable"><p class="para-cont">Escalate risks as appropriate</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Sector Functional Risks shall be reviewed and escalated, as appropriate, to Audit and Risk sector leadership team.')">
          <div class="content content-enable"><p class="para-cont">Escalate risks to Sector leadership at least quarterly</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Actions from the Audit and Risk review shall be reported to and actioned by the relevant Sector Functional Lead.')">
          <div class="content content-enable"><p class="para-cont">Actions resulting from reviews shall be managed to closure</p></div>
          </div>
      </div>   
</div>
</div>

    <div class="col-3">
    <div class="content-box mty">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span></div>
      <div class="ult-links"><h4>Useful links</h4> 
      <a href="http://arm.atkinsglobal.com/arm/" target="_blank">Active Risk Manager (ARM)</a>
      </div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>
</div>
  </div>
  </div>
<!-- Main content Container section end here -->



</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions} from "vuex";
export default {
  name: "EnableEnterpriseRiskManagementcomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  methods: {   ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
   },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>