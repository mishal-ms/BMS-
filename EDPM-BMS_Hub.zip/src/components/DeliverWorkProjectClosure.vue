<template>
  <div>
    <!-- Main content Container section start from here -->
    <div class="cont-container">
      <div class="content-wt">
        <div class="content-hd-text">
          <h2>Project Closure</h2>
          <p>
            Project Closure serves an important purpose for the organization.
            Formally closing a project ensures a review of the project to check
            it met all the original objectives both for the organization and the
            client; it provides an opportunity to ensure learning has been
            captured on the project which can be used to inform future projects;
            and enables the performance of the project to be reviewed and its
            success to be recognized.
          </p>
        </div>
        <div class="tabs">
          <button class="tab-link active">Requirements</button>
          <button
            class="tab-link"
            onclick="window.location.href='#/DeliverWorkProjectClosureNew';"
          >
            Additional Detail
          </button>
          <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
        </div>
        <div class="row-content">
          <div class="col-9">
            <div class="card-wrap">
              <div class="row-box">
                <div class="box" v-on:click="show('Review the contract to understand the contractual obligations and identify the associated risks, opportunities and information flow needed to manage the project effectively. ')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Understand contractual obligations in relation to
                      archiving of project information
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Identify how the success of the project will be measured so that at project closure it can be assessed whether these have been achieved. The project success indicators should be verified with the client as part of the kick off meeting.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Document project key success measures as part of the
                      Project Management Plan
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Establish a planned programme of client feedback, as part of the Stakeholder Management Plan, to enable the confirmation that services are being delivered to client requirements and meet contractual obligations.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Document client feedback requirements
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The lessons, knowledge and experience gained from the project should be systematically recorded throughout the delivery of the project. Every project shall follow an agreed means of capturing learning to inform improvements during project delivery and to enable learning to be shared with future projects. ')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Define approach to capture learning from the project as
                      part of the Project Management Plan
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-rt" v-on:click="show('The requirements of archiving project information shall be in line with company requirements as a minimum expectation and include any additional contractual requirements. ')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Document project archive requirements as part of Project
                      Management Plan
                    </p>
                  </div>
                </div>
              </div>

              <div class="row-reverse">
                <div class="box" v-on:click="show('Projects shall plan the demobilisation of resources so that this occurs in a controlled manner at the relevant point during the course of the project. In some circumstances this may be after a key deliverable, at the end of a stage or a phase or at the close of the project. ')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Identify and plan for anticipated project closure date
                    </p>
                  </div>
                </div>
                <div class="box" v-on:click="show('The PM shall confirm with the client all final deliverables have addressed all contractual obligations prior to formally closing the project.  ')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Confirm with client the contractual obligations are
                      complete
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Once the project is substantially closed client feedback shall be sought to identify learning for this project and future projects. ')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Measure client satisfaction post deliverables
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('It is important any risks and/or liabiilities which cannot be mitigated and may present in the future are documented and archived in a manner that can be easily retrieved and understood should the risk/liability materialise at some point in the future.')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Document residual risks and ongoing liabilities
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-lt" v-on:click="show('At the end of the project, all outstanding payments must be paid by the client and the project summary must accurately reflect all the incurred project costs. Confirm that all valid invoices from subcontractors and supply chain partners have been received and paid. ')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">Close project finances</p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
              </div>
              <div class="row-box">
                <div class="box" v-on:click="show('A review of project performance shall be undertaken, which may include complaints, good practice, management of risks, client feedback, successes and failures, technical innovations, staff performance and learning from the project.')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Conduct end of project review in line with the project
                      risk categorisation
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Document any learning to enable continuous improvement in the future delivery of projects. It is important to capture learning in a manner which can be shared to inform future projects. ')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">Document learning from the project</p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Project data shall be retained and archived in line with contractual obligations and the requirements laid out in the PMP. ')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Archive project information in line with contractual
                      obligations
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
   <!-- <RightInformationPannel/> -->

          <div class="col-3">
            <div class="content-box">
              <div class="own-detail">
                <span
                  >Process Owner:
                  <strong class="bld-txt"> Nick Welch</strong></span
                >
                <!-- <span
                  >Key Contact:
                  <strong class="bld-txt">Joann Clarke</strong></span
                > -->
              </div>
              <div class="ult-links">
                <h4>Useful links</h4>
                <a href="https://atkins.sharepoint.com/sites/dwh/html/index.aspx?OR=Teams-HL&CT=1649844968359&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjA0MDExMTQwMCJ9#/" target="_blank">Deliver Work Hub</a>
                <a href="https://atkins.sharepoint.com/sites/ESMS/SitePages/Glossary.aspx?OR=Teams-HL&CT=1649852129464&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjAzMjEwMDEwNyJ9" target="_blank">Glossary</a>
                <a href="https://atkins.sharepoint.com/sites/dwh/Documents/Forms/AllItems.aspx?id=%2Fsites%2Fdwh%2FDocuments%2FDeliver%20Work%20Governance%2FTechnical%20Assurance%20Standard%2FTechnical%20Assurance%20Standard%2Epdf&parent=%2Fsites%2Fdwh%2FDocuments%2FDeliver%20Work%20Governance%2FTechnical%20Assurance%20Standard" target="_blank">Technical Assurance Standard</a>
                 <a href="https://atkins.sharepoint.com/sites/CommercialHub/html/index.aspx#/theme/service-delivery-process" target="_blank">Service Delilvery Procedure</a> 
                 <a href="https://atkins.sharepoint.com/sites/CommercialHub/html/index.aspx#/" target="_blank">Commercial Hub</a>
                 <a href="https://atkins.sharepoint.com/sites/digitalservices/productportal/ClientPerception/Pages/default.aspx" target="_blank">Client Perception & Project Feedback</a>
              </div>
              <!-- <div class="ult-links">
                <h4>Training</h4>
                <a>xxxxxxx</a>
              </div> -->
              <div class="ult-links">
                <h4>Approved Deviations</h4>
                <a>None</a>
              </div>
            </div>
          </div> 
        </div>
      </div>
    </div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapActions } from "vuex";
// import RightInformationPannel from "../components/RightInformationPannel.vue";
export default {
  name: "DeliverWorkProjectClosureComp",
  // components: {RightInformationPannel}
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  methods: {
    ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>