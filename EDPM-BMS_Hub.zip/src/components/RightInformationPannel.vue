<template>
<div class="col-3">
    <div class="content-box">
        <div class="own-detail">
            <span>Process Owner:
                <strong class="bld-txt">Martina Perrin</strong></span>
            <!-- <span>Key Contact:
                <strong class="bld-txt">Joann Clarke</strong></span> -->
        </div>
        <div class="ult-links">
            <h4>Useful links</h4>
            <a href="http://communities.eu.atkinsglobal.com/sites/winworkhub/Pages/home.aspx" target="_blank">Win Work Hub</a>
            <!-- <a>Community</a> -->
            <a href=" http://visionapp.na.atkinsglobal.com/VisionClient/" target="_blank">Vision Sales Database for US</a>
            <a href="https://sncl-d365.crm11.dynamics.com/apps/snclsales" target="_blank">SNCL Sales Enterprise Users</a>
            <a href="https://sncl-d365.crm11.dynamics.com/apps/snclstm" target="_blank">Sales Team Member</a>
            <a href="https://atkins.sharepoint.com/sites/GWWPDP/SitePages/Home.aspx" target="_blank">Engineering Services Capture & Pursuit Toolkit </a>
            <a href="https://atkins.sharepoint.com/sites/digitalservices/productportal/ClientPerception/Pages/default.aspx" target="_blank">Client Perception & Project Feedback </a>
            <a href="https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/" target="_blank">Global Design Framework </a>

           




        </div>
        <!-- <div class="ult-links">
                <h4>Training</h4>
                <a>None</a>
              </div> -->
        <div class="ult-links">
            <h4>Approved Deviations</h4>
            <a>None</a>
        </div>
    </div>
</div>
</template>

<script>
import api from "@/service";
import router from "@/router";
export default {
    name: "RightInformationPannel",
}
</script>
