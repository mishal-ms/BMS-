<template>

<!-- footer section start from here -->
<footer class="content-row">
  <div class="content-wt row-ft">
<div class="quick-link">
  <h4>Some Important Links</h4>
<a target="_blank" href="http://communities.eu.atkinsglobal.com/sites/winworkhub/Pages/home.aspx">Win Work Hub</a>
<a target="_blank" href="https://atkins.sharepoint.com/sites/dwh/html/index.aspx#/">Deliver Work Hub </a>
<a target="_blank" href="https://km.snclavalin.com/pdce/_layouts/15/WopiFrame2.aspx?sourcedoc=/pdce/Functional/2022-EN-BlueBook_(e-viewing).pdf&action=default">Blue Book</a>
<a target="_blank" href="https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/">Global Design Framework</a>
<a target="_blank" href="https://km.snclavalin.com/pdce">SNC-L Capability Hub</a>
<a href="https://atkins.sharepoint.com/sites/ESMS/SitePages/Glossary.aspx?OR=Teams-HL&CT=1649059942288&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjAzMjEwMDEwNyJ9" target="_blank">Engineering Services Glossary</a> 


</div>

<div class="quick-link" style="cursor:pointer" onclick='window.open("https://atkins.sharepoint.com/sites/ESMS/SitePages/Process-Images.aspx?OR=Teams-HL&CT=1649655788339&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjAzMjEwMDEwNyJ9")'>
  <h4>BMS Hub image library for bids</h4>
<!-- <span>The Key components to support project delivery:</span> -->

</div>

<div class="quick-link">
  <h4>Contacts</h4>
  <span>Product Owner: Sarah Ryan</span>
  <span>Product Manager: Gary Kinsman</span>
  <a target="_blank" href="https://atkins.sharepoint.com/sites/ESMS/SitePages/Contact.aspx">Comments or suggestions</a>
</div>
</div>
<div class="ft-info">
    <p>Disclaimer: for best view of this site please use Microsoft Edge or Google Chrome. Browser zoom level should be 100%".</p>
    </div>
</footer>
<!-- footer section end  here -->
    <!-- <footer> -->
        <!-- <b-container>
            <b-row>
                <b-col lg="3" v-for="(foot, index) in footer" :key="index">
                    <div class="content-wrapper">
                        <p class="heading">{{foot.Title}}</p>
                        <p v-html="foot.Desc"></p>
                    </div>
                </b-col>
            </b-row>
        </b-container> -->
    <!-- </footer> -->
</template>
<script>
import { mapGetters } from 'vuex'
import api from '@/service'
export default {
	name: 'FooterComp',
    data() {
        return {
        }
    },
    computed: {
        // ...mapGetters([
        //     'footer'
        // ]),
	},
    methods: {
	}
}
</script>
<style lang="scss">
// @import '../assets/scss/components-scoped/footer.scss';
</style>