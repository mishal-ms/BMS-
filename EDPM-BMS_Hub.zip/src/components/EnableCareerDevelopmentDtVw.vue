<template>
  <div>
    <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Career Development</h2>
      <p>Career development is important to provide opportunities for people to achieve their potential, enabling them to feel valued not just for what they offer now but for their future potential. It provides opportunity for people to grow and increase their levels of engagement and satisfaction through the achievement of their goals and those of the organization. </p>
  </div>
  <div class="tabs">
        <button class="tab-link" onclick="window.location.href='#/EnableCareerDevelopment';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='#/EnableCareerDevelopmentDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4> Conduct a career discussion with every employee at least annually </h4>
  <p>Everyone shall have the opportunity to discuss their performance in year, their development needs and identify objectives for the coming year at least annually. Career and performance discussions should happen throughout the year to provide meaningful feedback to help improve performance.</p>
  <h4>Identify clear objectives annually for every employee  </h4>
  <p>Everyone shall have documented objectives to help them achieve personal stretch targets and support in the delivery of the business plan. These objectives should be specific, measurable, achievable, relevant and timely. 
</p>
  <h4>Ensure a Development Plan is in place for every employee and is reviewed at least annually  </h4>
  <p>Everyone shall have the opportunity to identify relevant development to help them achieve their objectives.  Development should consider both requirements now and in the future to enable employees to grow and succeed.  Development shall be relevant and identified on the best method to achieve the outcomes required taking into account cost, quality and time. </p>
  <h4>ED&I strategy documented to support fair and transparent career development </h4>
  <p>Everyone shall have access to the same opportunities based on need and objectives. This shall include open and transparent access to development opportunities.</p>

</div>
</div>
  
  </div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "EnableCareerDevelopmentDtVwComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>