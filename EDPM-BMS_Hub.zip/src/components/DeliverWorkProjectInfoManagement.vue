<template>
  <div>
    <!-- Main content Container section start from here -->
    <div class="cont-container">
      <div class="content-wt">
        <div class="content-hd-text">
          <h2>Project Information Management</h2>
          <p>
            Information Management aims to get the right information to the
            right person at the right place in the right time (Robertson, 2005).
            It includes the collection, management, processing and delivery of
            information, which is the cornerstone of providing value to our
            clients. Effective management of information is an integral part of
            our quality management system ensuring we consistently and
            appropriately manage information to drive improved project
            performance.
          </p>
        </div>
        <div class="tabs">
          <button class="tab-link active">Requirements</button>
          <button
            class="tab-link"
            onclick="window.location.href='#/DeliverWorkProjectInfoManagementNew';"
          >
            Additional Detail
          </button>
          <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
        </div>
        <div class="row-content">
          <div class="col-9">
            <div class="card-wrap">
              <div class="row-box">
                <div class="box" v-on:click="show('Projects should consider what we know about the client information requirements, review requirements in the client proposal documents and consider what standards we have to work to. Projects involving design should follow the Global Design Framework Stages 1, 2 and 3 ')">
                  <div class="content bg-fst-chld">
                    <p class="para-cont">
                      Identify proposal assumptions for management of
                      Information
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Consider what we know about the client and their information requirements, review requirements included in the contract/scope, consider what standards we have to work to, what information will be needed/gathered/provided by the client or others, and what will be analysed/interpreted and shared/transmitted in the course of delivering the project by us and other parties to the project.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Establish project information requirements and standards
                      to be met
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Consider what we have to deliver, what the outputs will be, where and how information will be stored, shared and transmitted/issued for use by others and where responsibilities will lie.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Establish information deliverables required and milestones
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Consider what we have to deliver, what the outputs will be, where and how information will be stored, shared and transmitted/issued for use by others and where responsibilities will lie.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Establish information exchange requirements and means of
                      sharing/publishing
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-rt" v-on:click="show('The Project Manager shall ensure  internal and external parties know who to communicate with and understand their level of delegated authority. It is important roles and responsibilities for the check, review, approval, issuing and receiving of information  is clearly communicated to the project team to ensure information is only shared once it has received appropriate check, review and approval.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Confirm how information management responsibilities will
                      be addressed within team
                    </p>
                  </div>
                </div>
              </div>

              <div class="row-reverse">
                <div class="box" v-on:click="show('The Project Manager shall ensure  internal and external parties know who to communicate with and understand their level of delegated authority.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Agree information delivery approach with client
                    </p>
                  </div>
                </div>
                <div class="box" v-on:click="show('Projects involving design should prepare and implement Global Design Framework Stage 4 (Appointment) and 5 (Mobilization). Non-design projects should review proposal stage plans and assumptions relating to information management, develop into delivery stage Project Information Management Plan')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Develop Project Information Management plan as part of the Project Management Plan
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Risks associated with the production, management, storage, version control, sharing and issuing of deliverables must be considered and included on the project risk register.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Update risk register with information management
                      assumptions
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The project teams shall have a clear understanding of the expectations of what is to be delivered, by when and for how much with all internal and client deliverables identified, and their timings set out. Mobilization shall set out all key roles, responsibilities, accountabilities, and authorities;  the significance of information which needs to be communicated between disciplines is shared; customer and third-party requirements, and the circumstances in which they should be consulted or informed, are fully understood')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Formally mobilize project and share the Project
                      Information Management plan with the project team
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-lt" v-on:click="show('Projects shall implement assurance checks in line with the Project Information Management Plan to ensure all teams are using up to date information to reduce the likelihood of error and abortive work and to improve delivery efficiency. Projects involving design should follow the Global Design Framework Stages 6 (Collaborative Production of Information) and 7 (Information Model Delivery) and in particular SMP 65 - Quality Assurance. ')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Undertake information management assurance checks
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
              </div>
              <div class="row-box">
                <div class="box" v-on:click="show('Projects shall implement information reviews in line with the Project Information Management Plan. Projects involving design should follow the Global Design Framework Stages 6 (Collaborative Production of Information) and 7 (Information Model Delivery). ')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Undertake reviews of information management approach as
                      defined in Project Management Plan
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Projects shall update the Project Information Management Plan and ensure the project team is made aware of relevant changes to the management of project information requirements. Projects involving design should follow the Global Design Framework Stages 6 (Collaborative Production of Information) and 7 (Information Model Delivery). ')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Update information management approach following review
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Projects shall manage the sharing and transmitting of information to the client in line with the Project Information Plan. Projects involving design should follow the Global Design Framework Stage 8 (Project Close-out) and in particular ensure SMP 81 - Customer Satisfaction is followed at appropriate intervals. ')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Hand over information to client and confirm acceptance
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Projects shall document learning to enable continuous improvement in the future management of information on projects. It is important to capture learning in a manner which can be shared to inform future projects. Projects involving design should follow the Global Design Framework Stage 8 (Project Close-out) and in particular SMP 81 - Customer Satisfaction and SMP 82 - Digital Lessons Learned ')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Review and document information management learning from
                      the project
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Project data shall be retained and archived in line with contractual obligations and the requirements laid out in the PMP. Projects involving design should follow the Global Design Framework')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Archive project information in line with contractual
                      obligations
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
   <!-- <RightInformationPannel/> -->
           <div class="col-3">
            <div class="content-box">
              <div class="own-detail">
                <span
                  >Process Owner:
                  <strong class="bld-txt"> Nick Welch</strong></span
                >
                <!-- <span
                  >Key Contact:
                  <strong class="bld-txt">Joann Clarke</strong></span
                > -->
              </div>
              <div class="ult-links">
                <h4>Useful links</h4>
                <a href="http://axis.eu.atkinsglobal.com/uk/projectbids/majorprojects/Pages/world_pmplan.aspx" target="_blank">MPU PMP</a>
                 <a href="https://atkins.sharepoint.com/sites/dwh/html/index.aspx#/design-principles" target="_blank">Design Principles</a>
                  <a href="https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/" target="_blank">Global Design Framework</a>
              </div>
              <!-- <div class="ult-links">
                <h4>Training</h4>
                <a>xxxxxxx</a>
              </div> -->
              <div class="ult-links">
                <h4>Approved Deviations</h4>
                <a>None</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapActions } from "vuex";
// import RightInformationPannel from "../components/RightInformationPannel.vue";
export default {
  name: "DeliverWorkProjectInfoManagementComp",
  // components: {RightInformationPannel}
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  methods: {
     ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>