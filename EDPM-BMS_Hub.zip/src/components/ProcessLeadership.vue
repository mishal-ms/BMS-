<template>
    <div>



<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Leadership and Commitment</h2>
      <p>Top management leadership and commitment demonstrates to us all the value and importance of what we do and why we do it. Their focus on driving the best outcomes through strong and visible leadership is important. This is demonstrated through the controls they put in place, the expectations they drive and the activities they sponsor.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/ProcessLeadership';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/LeadProcessLeadershipDetailedView';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">

      <div class="row-box">
        <div class="box" v-on:click="show('Top management shall take accountability for the effectiveness of the management system and the integration of requirements into business processes. They shall ensure the resources needed for the management system are available and communicate the importance of effective quality, health, safety and environmental management.')">
          <div class="content bg-lead"><p class="para-cont">Deliver an effective Management System</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Top management shall ensure the focus on enhancing client satisfaction is maintained, client, statutory and regulatory requirements are determined, understood and consistently met and risks and opportunities that can affect conformity are determined and addressed.')"> 
          <div class="content bg-lead"><p class="para-cont">Promote client focus</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Top management shall ensure the Quality and HSE policy is available, communicated, understood and applied across the sector.')">
          <div class="content bg-lead"><p class="para-cont">Document and share Quality and HSE Policy</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Top management shall establish quality and HSE objectives for the management system. Objectives shall be compatible with the context and strategic direction of the organization.')">
          <div class="content bg-lead"><p class="para-cont">Establish Quality  and HSE Objectives</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Top management shall ensure responsibilities and authorities for relevant roles are assigned, communicated and understood across the sector. Relevant roles shall include ensuring the management system conforms to the ISO standard; ensuring processes are delivering intended outputs; reporting on the performance of the management system; ensuring promotion of customer focus; and ensuring integrity of the management system when changes are planned and implemented.')">
          <div class="content bg-lead"><p class="para-cont">Assign responsibilities and authorities for relevant roles</p></div>
          </div>
      </div>  
</div>
</div>

    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span></div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>

</div>
</div>
</div>
<!-- Main content Container section end here -->



    </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions } from "vuex";
export default {
  name: "ProcessLeadershipComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
   methods: {
           ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
   },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
