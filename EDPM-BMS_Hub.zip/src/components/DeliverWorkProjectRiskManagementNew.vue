<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Project Risk Mangement</h2>
      <p>Effective risk management is fundamental to helping us achieve our project objectives. Risk management is important during project planning, mobilization and execution; well-managed risks and opportunities significantly increase the likelihood of project success. A structured and proactive approach to risk management leads to better decision making and therefore better project outcomes.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkProjectRiskManagement';">Requirements</button>
    <button class="tab-link active"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Identify proposal risks, assumptions and exclusions</h4>
  <p>The PM and PD shall be engaged during the proposal stage to understand the assumptions and exclusions which shall be factored into the proposal and the associated risks to delivery</p>
  <h4>Conduct formal proposal handover</h4>
  <p>The Project manager shall ensure that they have a complete set of proposal related materials including the proposal risk register.</p>
  <h4> Understand Client expectations aligned to contractual obligations and bid commitments</h4>
  <p>The PM shall review the contract to understand the contractual obligations and identify the associated plans needed to manage and control the project. The Project Management Plans shall also take into account any commitments made to the client as part of engagement during the proposal phase.</p>
  <h4>Review & validate risks & assumptions identified as part of the bid</h4>
  <p>Following review of the contractual obligations the proposal risk register shall be reviewed to confirm that the identified risks are appropriate.</p>
  <h4>Review project requirements and identify additional  risks</h4>
  <p>When developing the project plans and identifying the delivery methodology, additional risks should be identified and included on the project risk register</p>
  <h4> Develop Risk Management Plan as part of the Project Management Plan</h4>
  <p>The approach to risk management shall be documented. For smaller projects this is typically part of the project management plan but for more complex project it may require a separate risk management plan.</p>

  <h4>Develop and document the Project Risk Register</h4>
  <p>Construct a quantified risk log on the basis of known risks, assumption, exclusions & dependencies. This shall include mitigation plans where necessary.
    The PM should engage subject matter experts and/or the project team as appropriate to identify risks.</p>
  <h4>Analyse and evaluate risks, identify owners and document mitigation plan</h4>
  <p>Risks shall be quantified and include as a minimum an assessment of Impact & Probability. An appropriate mitigation strategy shall be identified. There are four mitigation strategies available:
    1. Terminate – e.g. the scheme is too risky to offer a bid, risks exceed rewards – avoid
    2. Transfer the risk – transfer to a third party, contractor, subcontractor, client, insurance company
    3. Treat – reduce the likelihood, or reduce the impact, do more investigative work
    4. Tolerate – keep the risk and manage it within our contingency provision in accordance with the 
    agreed action plan</p>
  <h4> Treat risks and/or schedule subsequent treatment</h4>
  <p>Treatment shall be in line with the PMP and any individual mitigation strategy.</p>
  <h4>Formally mobilize the project and share project risks with the project team </h4>
  <p> Accountability and ownership for individual risks shall be documented and understood. Mitigation strategies shall be shared with the wider project team to ensure risks are appropriately managed and controlled.</p>
  <h4>Manage and review Project Risk Register in line with PMP</h4>
  <p>The PM should declare the status and progress of risks in line with the Project plan and review cycle. The communication and escalation approach shall be described within the PMP.</p>
  <h4>Review and update risk register; identify new risks, review existing risks, analyse and evaluate all.</h4>
  <p>The risk register is a dynamic document that shall be regularly reviewed to ensure all project risks are identified and being suitably managed.  The identification, update, review and analysis required to effectively manage risks shall be documented within the PMP.</p>

  <h4>Escalate / communicate any changes and actions to risk register to  relevant stakeholders</h4>
  <p>Risks need to be reviewed and assessed to identify those which require escalation. Escalation may result in additional LoA or gated approval levels being required or management as part of the wider Business Enterprise Risk Management process</p>
  <h4>Treat risks</h4>
  <p>Treatment shall be in line with the PMP and any individual mitigation strategy.</p>
  <h4>Confirm with client the contractual obligations are complete</h4>
  <p>The PM shall confirm with the client all final deliverables have addressed all contractual obligations prior to formally closing the project.</p>
  <h4>Close out residual risks, where possible</h4>
  <p> Any risks and/or liabilities which cannot be mitigated and may present in the future shall be documented and archived in a manner that can be easily retrieved and understood should the risk/liability materialise at some point in the future.</p>
  <h4>Archive risk register, (including outstanding Project Risks not mitigated), in line with contractual requirements</h4>
  <p>Project data shall be retained and archived in line with contractual obligations and the requirements laid out in the PMP. Any residual risks beyond the project shall be clearly documented and appropriately escalated.</p>
  
</div>
</div>
 </div> 
</div>
<!-- Main content Container section end here -->


</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "DeliverWorkProjectRiskManagementNewComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>