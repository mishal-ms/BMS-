<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Safe & Healthy Work Environment</h2>
      <p>A safe and healthy work environment doesn’t just happen—it’s created by working together. A safe and healthy work environment is good for worker health, safety and wellbeing, business sustainability and the economy. The work environment is more than the physical surroundings. It includes the way that you do your work, the materials and equipment that you work with and also the emotional and psychological demands on workers.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/EnableSafeHealthyWorkEnvironment';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/EnableSafeHealthyWorkEnvironmentDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <div class="row-box">
        <div class="box"  v-on:click="show('Health, Safety, Environment and Wellbeing objectives shall comply and be consistent with SNCL annual HSE Objectives.')">
          <div class="content content-enable"><p class="para-cont">Establish Sector Health, Safety Environmental & Wellbeing objectives </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box"  v-on:click="show('The business shall identify a suitable H&S lead. This should be a competent resource. In the absence of a competent resource, suitable support shall be provided (i.e., supervision, mentoring, checking / review).')">
          <div class="content content-enable"><p class="para-cont">Identify competent resource to lead H&S</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box"  v-on:click="show('HSEW performance will be used to establish annual Health, Safety, Environment and Wellbeing HSE goals to focus on specific areas of risk and opportunities for improvement.Performance (leading and lagging) will be recorded and reviewed throughout the year.')">
          <div class="content content-enable"><p class="para-cont">Establish annual Health, Safety, Environmental and Wellbeing goals</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box"  v-on:click="show('As part of business planning, the sector and regions shall identify the needs and expectations of relevant internal and external interested parties having an interest in HSE performance.')">
          <div class="content content-enable"><p class="para-cont">Identify needs and expectations of relevant internal and external interested parties</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt"  v-on:click="show('A HSE risk assessment shall be completed and appropriate controls identified for all business activities.')">
          <div class="content content-enable"><p class="para-cont">Create and maintain an HSE business risk register</p></div>
          </div>
      </div>
    <div class="row-reverse-last-child">
  <div class="box"  v-on:click="show('Any Blue Book requirements that cannot be reasonably achieved shall be subject to the SNC-L deviation procedure and require appropriate approval. Corrective actions from audits and recordable / HiPo incidents must be entered in BlueSky within timescales stated in the Blue Book. Corrective actions shall be implemented in a timely manner.')">
    <div class="content content-enable"><p class="para-cont">Embed and conform to HSE Blue Book requirements </p></div>
  </div>
  <div class="box"  v-on:click="show('Outputs of the HSE Committee and associated meetings shall be documented. Relevant HSE information shall be communicated to all applicable employees.')">
    <div class="content content-enable"><p class="para-cont">Establish a H&S Committee</p></div>
    <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
  </div>
  <div class="box"  v-on:click="show('All recordable incidents must be entered into BlueSky within 24 hours of occurrence. All recordable and HiPo incidents shall be reported to the President and CEO within 24 hours of occurrence. For all HiPo incidents, a regional conference call must be held within 96 hours to discuss the condition of those impacted. A record of this call shall be retained.')">
    <div class="content content-enable"><p class="para-cont">Report and review HSE incidents</p></div>
    <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
  </div>
  <div class="box"  v-on:click="show('Relevant health and wellbeing support and  guidance shall be made available internally and via an external Employee Assistance Programme (EAP). Employee engagement shall be undertaken to ensure wellbeing concerns are shared and appropriate improvement plans are established.')">
    <div class="content content-enable"><p class="para-cont">Maintain a healthy workforce</p></div>
    <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
  </div>
</div>
  </div>
</div>

    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span></div>
      <div class="ult-links"><h4>Useful links</h4> 
      <a href="https://infozone.snclavalin.com/en/global-health-safety/" target="_blank">Global HSE</a> 
      <a href="https://atkins.service-now.com/QSSE?id=sc_cat_item&sys_id=b117bb3e4fd49f0044434da28110c7cb" target="_blank">HSE Incident Reporting</a>
      </div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>

    </div>
  </div>
  </div>
<!-- Main content Container section end here -->


</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions } from "vuex";
export default {
  name: "EnableSafeHealthyWorkEnvironmentcomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // }
   methods: {
             ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
   },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
