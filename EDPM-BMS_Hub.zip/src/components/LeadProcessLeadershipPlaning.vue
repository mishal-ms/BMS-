<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Leadership and Commitment</h2>
      <p>Top management leadership and commitment demonstrates to us all the value and importance of what we do and why we do it. Their focus on driving the best outcomes through strong and visible leadership is important. This is demonstrated through the controls they put in place, the expectations they drive and the activities they sponsor.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='xxxxx.html';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/LeadProcessLeadershipDetailedView';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">

      <div class="row-box">
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Deliver an effective Management System</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Promote client focus</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Document and share Quality and HSE Policy</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Establish Quality  and HSE Objectives</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-lead"><p class="para-cont">Assign responsibilities and authorities for relevant roles</p></div>
          </div>
      </div>  
</div>
</div>

    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Martina Perrin</strong></span> <span>Key Contact: <strong class="bld-txt">Joann Clarke</strong></span></div>
      <div class="ult-links"><h4>Useful links</h4> <a>Win Work Hub</a> <a>Glossary</a> <a>Community</a></div>
      <!-- <div class="ult-links"><h4>Training</h4> <a>xxxxxxx</a> </div> -->
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>

</div>
</div>
</div>
<!-- Main content Container section end here -->




</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "LeadProcessLeadershipPlaningcomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>