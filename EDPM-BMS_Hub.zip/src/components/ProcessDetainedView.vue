<template>
    <div>
    

<!-- Main content Container section start from here -->
<div class="cont-container">
    <div class="content-wt">
    <div class="content-hd-text">
      <h2>Leadership and Commitment</h2>
      <p>Top management leadership and commitment demonstrates to us all the value and importance of what we do and why we do it. There focus on driving the best outcomes through strong and visible leadership is important. This is demonstrated through the controls they put in place, the expectations they drive and the activities they sponsor.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" >Requirements</button>
    <button class="tab-link active"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>

  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-file-excel"></i> Export as Exl</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
              <a href="#"><i class="fas fa-share-alt"></i> Share</a>
          </div>
        
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Deliver an effective Management System</h4>
  <p>Top management shall take accountability for the effectiveness of the management system and the integration of requirements into business processes. They shall ensure the resources needed for the management system are available and communicate the importance of effective quality, health, safety and environmental management. </p>
  <h4>Promote client focus </h4>
  <p>Top management shall ensure the focus on enhancing client satisfaction is maintained, client, statutory and regulatory requirements are determined, understood and consistently met and risks and opportunities that can affect conformity are determined and addressed.</p>
  <h4>Document and share Quality and HSE Policy</h4>
  <p>Top management shall ensure the Quality and HSE policy is available, communicated, understood and applied across the sector.</p>
  <h4>Establish Quality  and HSE Objectives</h4>
  <p>Top management shall establish quality and HSE objectives for the management system. Objectives shall be compatible with the context and strategic direction of the organization.</p>
  <h4>Assign responsibilities and authorities for relevant roles </h4>
  <p>Top management shall ensure responsibilities and authorities for relevant roles are assigned, communicated and understood across the sector.  Relevant roles shall include ensuring the management system conforms to the ISO standard; ensuring processes are delivering intended outputs; reporting on the performance of the management system; ensuring promotion of customer focus; and ensuring integrity of the management system when changes are planned and implemented.</p>
</div>
</div>
</div>
</div>
<!-- Main content Container section end here -->




</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "ProcessDetainedView",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
