<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Improve</h2>
      <p>Improvement is about constantly and consistently seeking opportunities to improve our delivery to client expectations to enhance client satisfaction. Improvements can include how we correct mistakes, how we continually improve what we do based on experience, or it could focus on breakthrough change, innovation or re-organization. Whatever the driver, always focusing on, and capturing learning to inform improvements is critical to the success of the organization. In today's world we cannot stand still we must always have an eye on the future and be challenging ourselves to do more and be better.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/ProcessImprovement';">Requirements</button>
    <button class="tab-link active"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  
<h4>Identify and prioritise opportunities for improvements</h4>
  <p>Opportunities shall be identified to enhance client engagement, safety of our people and the care for the environment to drive enhanced satsifaction.   They shall include improving products and services to meet requirements as well as to address future needs and expectations; correcting, preventing or reducing undesired effects; and improving performance and effectiveness of the management system.</p>

  <h4>Manage Nonconformities</h4>
  <p>When a nonconformity arises, including complaints, action shall be taken to react by correcting it and dealing with the consequences; evaluating the need to take action to eliminate the cause of the nonconformity to prevent reoccurrence; and to implement any actions needed. The effectiveness of any actions taken shall be reviewed and the risk and opportunity register updated if necessary, along with any identified changes needed to the management system. </p>

  <h4>Continually improve the management system </h4>
  <p>The management system shall be continually improved to ensure suitability, adequacy and effectiveness. The management system shall be reviewed by top management at planned intervals and any decisions and actions shall be documented and managed through to closure.</p>

</div>
</div>
</div>
</div>
<!-- Main content Container section end here -->




</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "LeadProcessPlanMonitorDetailedViewcomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>