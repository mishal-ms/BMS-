<template>
    <div>
        <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Opportunity Identification</h2>
      <p><strong class="bld-txt">Opportunity identification and classification</strong> refers to the process of identifying, quantifying and classifying Win Work Pursuit Opportunities. A consistently applied methodology and set of practices for doing this helps in the prioritization or Pursuits; helping to inform key decisions around where to allocate resource and investment, and where there are opportunities to leverage global capabilities to maximize chances of bidding success.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/OpportunityIdentification';">Requirements</button>
    <button class="tab-link active" > Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>

  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Identify strategy and market priorities </h4>
  <p> Should be aligned to Regional Market Strategies and informed by basic market analysis that identifies market drivers and trends.</p>
  <h4>Target clients identified  </h4>
  <p> Should be aligned to Regional Market Strategies and should be informed by an understanding of where customer demand drivers meet Engineering Services capabilities</p>
  <h4>Identify pipeline of opportunities aligned to market priorities </h4>
  <p>Should be derived from by ongoing client engagement and monitoring of formal procurement portals and channels.</p>
  <h4>Record pipeline of opportunities on relevant client management system</h4>
  <p>New opportunities should be uploaded to local CRM system and should include as much relevant information as is possible to record.</p>
  <h4>Review opportunities in pipeline and manage weighting based on client and competitor analysis</h4>
  <p>Opportunity pipeline data should analysed and critically assessed to apportion appropriate weighting. Pipeline analysis and assessment should be informed by client and competitor intelligence.</p>

  <h4>Identify pursuit investment </h4>
  <p>Review total costs of bid activity for the period - direct and indirect.</p>

  <h4>Select opportunities and confirm Go/No Go</h4>
  <p>Identify suitable opportunities to pursue. Assess risks and conduct go/no go to identify opportunities to pursue further.</p>
  <h4>Prepare for the potential opportunity using the capture planning process</h4>
  <p>A Capture Planning process should be initiated, utilizing the tools, processes and guidance available</p>
  <h4>Review and monitor the capture plan relevant to size of opportunity</h4>

</div>
</div>
 
</div>
</div>
<!-- Main content Container section end here -->
    </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "OpportunityIdentificationDetailedViewcomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>