<template>
    <div>
    


<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Project Closure</h2>
      <p>Project Closure serves an important purpose for the organization. Formally closing a project ensures a review of the project to check it met all the original objectives both for the organization and the client; it provides an opportunity to ensure learning has been captured on the project which can be used to inform future projects; and enables the performance of the project to be reviewed and its success to be recognized.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkProjectClosure';">Requirements</button>
    <button class="tab-link active"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button>  -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Understand contractual obligations in relation to archiving of project information </h4>
  <p>Review the contract to understand the contractual obligations and identify the associated risks, opportunities and information flow needed to manage the project effectively.</p>
  <h4>Document project key success measures as part of the Project Management Plan</h4>
  <p>Identify how the success of the project will be measured so that at project closure it can be assessed whether these have been achieved. The project success indicators should be verified with the client as part of the kick off meeting.</p>
  <h4>Document client feedback requirements</h4>
  <p>Establish a planned programme of client feedback, as part of the Stakeholder Management Plan, to enable the confirmation that services are being delivered to client requirements and meet contractual obligations.</p>
  <h4>Define approach to capture learning from the project as part of the Project Management Plan</h4>
  <p>The lessons, knowledge and experience gained from the project should be systematically recorded throughout the delivery of the project. Every project shall follow an agreed means of capturing learning to inform improvements during project delivery and to enable learning to be shared with future projects.</p>
  <h4>Document project archive requirements as part of Project Management Plan</h4>
  <p>The requirements for archiving project information shall be in line with company requirements as a minimum expectation and include any additional contractual requirements.</p>

  <h4>Identify and plan for anticipated project closure date</h4>
  <p>Projects shall plan the demobilization of resources so that this occurs in a controlled manner at the relevant point during the course of the project. In some circumstances this may be after a key deliverable, at the end of a stage or a phase or at the close of the project.</p>

  <h4>Confirm with client the contractual obligations are complete</h4>
  <p>The PM shall confirm with the client all final deliverables have addressed all contractual obligations prior to formally closing the project.</p>
  <h4>Measure client satisfaction post deliverables</h4>
  <p>Once the project is substantially closed client feedback shall be sought to identify learning for this project and future projects.</p>
  <h4>Document residual risks and ongoing liabilities</h4>
  <p>It is important any risks and/or liabiilities which cannot be mitigated and may present in the future are documented and archived in a manner that can be easily retrieved and understood should the risk/liability materialise at some point in the future.</p>
  <h4>Close project finances</h4>
  <p>At the end of the project, all outstanding payments must be paid by the client and the project summary must accurately reflect all the incurred project costs. 
    Confirm that all valid invoices from subcontractors and supply chain partners have been received and paid.</p>
  <h4>Conduct end of project review in line with the project risk categorisation</h4>
  <p>A review of project performance shall be undertaken, which may include complaints, good practice, management of risks, client feedback, successes and failures, technical innovations, staff performance and learning from the project.</p>

  <h4>Document learning from the project</h4>
  <p>Document any learning to enable continuous improvement in the future delivery of projects. It is important to capture learning in a manner which can be shared to inform future projects.</p>

  <h4>Archive project information in line with contractual obligations</h4>
  <p>Project data shall be retained and archived in line with contractual obligations and the requirements laid out in the PMP.</p>
</div>
</div>
</div>
</div>
<!-- Main content Container section end here -->




</div>

</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "DeliverWorkProjectClosureNewComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>