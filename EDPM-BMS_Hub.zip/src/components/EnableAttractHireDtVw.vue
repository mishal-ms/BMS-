<template>
  <div>
    <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Attract & Hire</h2>
    <p>Our brand is perhaps the most important element in attracting, hiring and retaining great talent. Our brand is what makes people want to work with us and for us. Having a clear strategy, identity and tone of voice will help us stand out as industry leaders.</p>
  </div>
  <div class="tabs">
     <button class="tab-link" onclick="window.location.href='#/EnableAttractHire';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='#/EnableAttractHireDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4> Human resource needs shall be identified aligned to business plan </h4>
  <p>The business should identify the human resources needed to deliver to the business plan.  This should include both capacity and capability aligned to their market plans and financial targets. The human resource needs should inform the hiring requirements and plan.</p>
  <h4> All vacancies will have a documented, evaluated, job definition</h4>
  <p>All vacancies shall have a documented job definition outlining key accountabilities, responsibilities and capabilities. This should be used to inform job evaluation and ensure fairness and equity across job roles. 
</p>
  <h4>All new vacancies shall be approved by the relevant manager according to the LoA</h4>
  <p>Approval for the vacancy shall be in accordance with the LOA. 
Job Classification framework grade shall be identified and approved in line with job definition.</p>
  <h4>All vacancies will have a specified recruitment plan </h4>
  <p>A recruitment plan, agreed by the relevant recruiter, shall include efforts to promote and increase the diversity of our talent pool by adopting an appropriate ED&I strategy. It should consider and challenge how it can attract the best talent from the widest pool possible. The plan shall take into consideration internal development, budget and capability requirements, aligned to the business plan. </p>


  <h4>Recruitment shall be managed in line with plan </h4>
  <p>The recruitment process shall be managed in line with the plan to ensure the intentions and ambitions of attracting the best talent is not compromised during the process. Any changes to the plan should be clearly documented to enable an auditable trail. </p>

  <h4>Formal contracts shall be documented, shared and mutually agreed</h4>
  <p>External recruits shall provide evidence prior to any formal offer, of their Right to Work and/or the correct levels of security clearance can be obtained. A verbal offer and/or negotiations may be conducted where applicable. Any agreed changes to contractual terms shall be captured and recorded,  
All contracts of employment or statement of terms and conditions shall be in writing and shall be produced by human resources.  </p>

  <h4> Formal On-Boarding approach developed for all new starters</h4>
  <p>All new starters should receive an organizational induction and a business specific induction. The organizational induction shall be managed by human resources. The business specific induction shall be led by the relevant division and should include an introduction into local processes and procedures, key contracts, key clients and markets. </p>

</div>
</div>
  
  </div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "EnableAttractHireDtVwComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>