<template>
  <div>
    <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Enterprise Risk Management</h2>
      <p>Effective Enterprise Risk Management helps us manage our risks and maximize opportunities. It helps identify threats that could affect the functioning and capability of our organization to deliver to our strategy and achieve our objectives. </p>
  </div>
  <div class="tabs">
       <button class="tab-link" onclick="window.location.href='#/EnableEnterpriseRiskManagement';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='#/EnableEnterpriseRiskManagementDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h3>Business Operational Risks</h3>
  <h4>Identify and document Business risks</h4>
  <p>Business risks shall be identified and documented on the ARM Risk Register, identifying owners, risk level, and mitigation actions</p>
  <h4> Review operational business risks  </h4>
  <p>Operational Business risks shall be reviewed by the region at least monthly.</p>
  <h4>Escalate risks as appropriate</h4>
  <p>Regional Commercial Director shall review risks and identify risks to be escalated to Regional leadership</p>
  <h4>Escalate risks to Sector leadership at least quarterly</h4>
  <p>Significant Operational Risks shall be reviewed and escalated, as appropriate, to Audit and Risk sector leadership team</p>

  <h4> Actions resulting from reviews shall be managed to closure</h4>
  <p>Actions from the Audit and Risk review shall be reported to and actioned by the relevant Regional Commercial Director</p>

  <h3>Sector Functional Risks</h3>
  <h4>Identify and document sector functional risks</h4>
  <p>Sector functional risks shall be identified and documented on the ARM Risk Register, identifying owners, risk level, and mitigation actions</p>
  <h4> Review sector functional risks</h4>
  <p>Sector Functional risks shall be reviewed by functional leadership at least quarterly.</p>
  <h4>Escalate risks as appropriate</h4>
  <p>Sector Function Lead shall review risks and identify risks to be escalated to Sector leadership  </p>
  <h4>Escalate risks to Sector leadership at least quarterly</h4>
  <p>Sector Functional Risks shall be reviewed and escalated, as appropriate, to Audit and Risk sector leadership team</p>

  <h4> Actions resulting from reviews shall be managed to closure</h4>
  <p>Actions from the Audit and Risk review shall be reported to and actioned by the relevant Sector Functional Lead</p>


</div>
</div>
  
  </div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "EnableEnterpriseRiskManagementDtVwComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>