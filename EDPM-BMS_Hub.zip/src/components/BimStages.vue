<template>
<div></div>
</template>
<script>
import mixin from '../mixins/common.js';
import api from '@/service'
import { mapActions,mapGetters } from 'vuex'
// import svgDiagram from '@/assets/images/GDF_Diagram_v3.svg';
export default {
	mixins: [mixin],
	name: 'bimstages',
	created(){
		const vm=this
		this.stageType=this.stageTypeNum
		this.selectedStage=this.stageNum
	},
	
	computed: {
		...mapGetters([
			'stages','stagesType','combinedResults','stageTypeNum','stageNum', 'parentClassIndex', 'showGrid', 'showDiagram'
		]),
		
		slugID() {
			return this.$route.name
		},
		
		stagesWithStageType() {
			return this.getCorrectStages()
        }
	},
    data() {
        return {
			stageType:1,
			selectedStage:1,
			bimStagesBtn: true,
			svgDiagram: svgDiagram,
			linkData: [
				{
					"id": '00',
					"title": "Evaluate Information Requirements",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/02.01"
				},
				{
					"id": '01',
					"title": "Pre-Appointment BIM Execution Plan",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/03.02"
				},
				{
					"id": '02',
					"title": "Capability & Capacity Assessment",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/03.07"
				},
				{
					"id": '03',
					"title": "Responsibility Matrix",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/03.06"
				},
				{
					"id": '04',
					"title": "Design Accelerator Challenge",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/02.08"
				},
				{
					"id": '20',
					"title": "BIM Execution Plan",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/04.01"
				},
				{
					"id": '21',
					"title": "Requirements Management",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/04.06"
				},
				{
					"id": '22',
					"title": "Content Library Management",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/02.10"
				},
				{
					"id": '23',
					"title": "CDE Setup",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/05.02"
				},
				{
					"id": '25',
					"title": "Interface Management",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/03.05"
				},
				{
					"id": '26',
					"title": "Project Information Security",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/02.02"
				},
				{
					"id": '27',
					"title": "Survey Mobilisation",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/05.04"
				},
				{
					"id": '28',
					"title": "Federation Strategy",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/03.05"
				},
				{
					"id": '30',
					"title": "Mobilisation",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/03.08"
				},
				{
					"id": '40',
					"title": "Collaborative Working (CDE Process)",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.01"
				},
				{
					"id": '41',
					"title": "Model Development",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.01"
				},
				{
					"id": '42',
					"title": "Design for Fabrication",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.08"
				},
				{
					"id": '43',
					"title": "Design for Health & Safety",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.07"
				},
				{
					"id": '44',
					"title": "Sustainability, Optioneering &amp; Reporting",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.09"
				},
				{
					"id": '45',
					"title": "Engineering Analysis",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.02"
				},
				{
					"id": '46',
					"title": "Clash Management",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.04"
				},
				{
					"id": '47',
					"title": "Model Coordination",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.04"
				},
				{
					"id": '48',
					"title": "Single Discipline Check",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.06"
				},
				{
					"id": '49',
					"title": "Interdisciplinary check",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.06"
				},
				{
					"id": '50',
					"title": "Drawing Production",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.03"
				},
				{
					"id": '51',
					"title": "Programme and Cost Simulation",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.05"
				},
				{
					"id": '52',
					"title": "Visualisation",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.03"
				},
				{
					"id": '60',
					"title": "Plan for Asset Management",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/07.04"
				},
				{
					"id": '61',
					"title": "Change Control",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/04.07"
				},
				{
					"id": '62',
					"title": "Digital Step Back",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/02.08"
				},
				{
					"id": '63',
					"title": "Query Management",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/04.08"
				},
				{
					"id": '64',
					"title": "Information Delivery & Control",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.06"
				},
				{
					"id": '65',
					"title": "Quality Assurance",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/06.06"
				},
				{
					"id": '66',
					"title": "Client Information Exchange",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/07.03"
				},
				{
					"id": '67',
					"title": "Global Design Framework Maturity Assessment",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/08.03"
				},
				{
					"id": '80',
					"title": "CDE Close Out",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/08.03"
				},
				{
					"id": '81',
					"title": "Customer Satisfaction",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/08.01"
				},
				{
					"id": '82',
					"title": "Digital Lessons Learnt",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/08.02"
				},
				{
					"id": 'Appointing Party',
					"title": "Appointing Party IM Functions",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/01.02"
				},
				{
					"id": 'Project Information PIR',
					"title": "Project Information Requirements (PIR)",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/01.03"
				},
				{
					"id": 'Delivery Milestones',
					"title": "Delivery Milestones",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/01.04"
				},
				{
					"id": 'Project Information PIS',
					"title": "Project Information Standard (PIS)",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/01.05"
				},
				{
					"id": 'Production Methods &',
					"title": "Project Information Requirements (PIR)",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/01.06"
				},
				{
					"id": 'Reference information',
					"title": "Reference information and shared resources",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/01.07"
				},
				{
					"id": 'Common Data',
					"title": "Common Data Environment (CDE)",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/01.08"
				},
				{
					"id": 'The Information Protocol',
					"title": "The Information Protocol",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/01.09"
				},
				{
					"id": 'Information Management Service Line',
					"title": "Information Management Service Line",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/01.10"
				},
				{
					"id": '29',
					"title": "Sustainability, Stategry &amp; Target Setting",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/02.11"
				},
				{
					"id": '68',
					"title": "Plan for sCDE",
					"url": "https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/detail/07.10"
				},

			]
        }
	},
	mounted() {
		this.$nextTick(() => {
			this.configureDiagramSVG();
			if(this.$route.name == 'Home') {
				this.UPDATE_SHOW_DIAGRAM(true);
			}
		})
	},
    methods: {
		...mapActions([
			'SET_STAGE','SET_STAGE_TYPE', 'UPDATE_PARENT_INDEX', "UPDATE_SHOW_GRID", "UPDATE_SHOW_DIAGRAM"
		]),

		getActiveStageType(stageTypeId,stageId){ 
			const vm = this;
			vm.selectedStage = stageId;
			vm.stageType = stageTypeId;
			this.SET_STAGE_TYPE(stageTypeId);
			this.SET_STAGE(stageId);
			this.UPDATE_PARENT_INDEX(1);
			if(this.$route.name !== "Home") {
				this.$router.push('/')
			}

		},
		getCorrectStages(){
			var result=  _.chain(this.stages).groupBy("StageTypeId").value();
			return _.orderBy(result[this.stageType], 'OrderNumber', 'asc')
			 
		},

		getActiveStage(currentStageNum,stageId,currentStageOrderNum, linkTo) {
			const vm = this;
			vm.selectedStage = stageId;
			vm.stageType=this.stageTypeNum;
			this.SET_STAGE(stageId);
			this.SET_STAGE_TYPE(this.stageTypeNum);
			this.UPDATE_PARENT_INDEX(currentStageNum);
			// debugger;
			// if(this.$route.name !== "Home") {
			// 	this.$router.push('/')
			// }
			// if(this.bimStagesBtn == true) {
			// 	this.toggleAllBimStages();
			// }
			this.UPDATE_SHOW_GRID(false);
			this.UPDATE_SHOW_DIAGRAM(false);
			if(this.$route.params.slug !== linkTo) {
				this.$router.push({ name: 'Detail', params: {slug: linkTo } })
				console.log('navigated to detail: ', linkTo)
			}

		},

		getDefaultValue(stagesTypeID) {
			var result= _.find(this.stages,{StageTypeId: stagesTypeID,OrderNumber: 1});
			this.selectedStage=result
			return result.Id;
		},

		// toggleAllBimStages() {
		// 	this.bimStagesBtn = !this.bimStagesBtn;
		// 	this.$emit('allbimstages', { active: this.bimStagesBtn })
		// 	console.log(this.bimStagesBtn);
		// },

		toggleGrid() {
			this.UPDATE_SHOW_DIAGRAM(false);
			this.UPDATE_SHOW_GRID(!this.showGrid);
		},

		toggleDiagram() {
			this.UPDATE_SHOW_GRID(false);
			this.UPDATE_SHOW_DIAGRAM(!this.showDiagram);
		},
		findDataElementById(id, data) {
            let currentPartentLinkData = data.filter(function (item) { 
				// console.log(item.id, id); 
				
				return item.id == id 
			})[0]
			console.log('currentPartentLinkData', currentPartentLinkData)
			return currentPartentLinkData;
        },
		addInteractions(type, data) {
			const vm = this;
            d3
			.selectAll(type).on("click", function () {
				let theNode = this;
				let canContinueToSearchAncestors = true;
				let dataNameValue = null;
				let counter = 1;
				while(canContinueToSearchAncestors && !(theNode == null || theNode == undefined)){
					if(typeof theNode.hasAttribute === "undefined"){
						// now try the parent node
						theNode = theNode.parentNode;
					}
					else if(theNode.hasAttribute("stop")){
						canContinueToSearchAncestors = false;
					}else if(theNode.hasAttribute("data-name")){
						dataNameValue = theNode.getAttribute("data-name");
						canContinueToSearchAncestors = false;
						//alert(dataNameValue);
					}else{
						// now try the parent node
						theNode = theNode.parentNode;
					}
				}
				//Find link data
				let currentPartentLinkData = vm.findDataElementById(dataNameValue, data)
				if (currentPartentLinkData) {
					console.log(currentPartentLinkData.title)
					//alert(currentPartentLinkData.url);
					document.location = currentPartentLinkData.url;
				}
				vm.UPDATE_SHOW_DIAGRAM(false);
				return;
			})
			.style("cursor", "pointer")
		},
		configureDiagramSVG() {
			const vm = this;
			console.log('test');
			d3.xml(svgDiagram)
            .mimeType("image/svg+xml")
            .get(function (error, xml) {
                document.getElementById("svgimage").appendChild(xml.documentElement);
				//Add interactions diagram is made from circles and paths so need something for both
				console.log('Link Data', vm.linkData)
				vm.addInteractions("circle,path,ellipse, rect", vm.linkData);
	
            });
		},
		
		filterStagesByTitle(title) {
			let filterList = this.combinedResults.filter(function(item) {
				return item.Stage.Title === title && item.ShowGrid !== false;
			});

			return _.orderBy(filterList, ['OrderItem'], ['asc']);
		},

		navigateToDetail(slug) {
			// this.bimStagesBtn = false;
			// this.$emit('allbimstages', { active: this.bimStagesBtn })

			this.UPDATE_SHOW_GRID(false);
			if(this.$route.params.slug !== slug) {
				this.$router.push({ name: 'Detail', params: {slug: slug } })
				console.log('navigated to detail: ', slug)
			}
		},

		highlightStages(index) {
			let stages = this.$refs.stages;
			stages.classList.add("parent-color-"+index);
		},
		unHighlightStages(index) {
			let stages = this.$refs.stages;
			stages.classList.remove("parent-color-"+index);
		}

		
	},
	watch: {	
		$route(to, from) {
			console.log(to);
			// console.log('showDiagram', this.showDiagram);
			// this.UPDATE_SHOW_DIAGRAM(false);
		}
	}
}
</script>
