<template>
    <div>

<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Performance</h2>
      <p>Monitoring business performance is key to improving business processes which underpin and enable delivery to our clients needs and expectations. Measuring performance is a vital part of monitoring delivery to our strategy and plans and gives the organization a sense of how we are performing. It enables the business to identify issues quickly and to make decisions to change direction based on evidence and facts.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/LeadProcessPerformanceAndImprove';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='xxxxxxxx.html';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Establish mechanisms to monitor business performance</h4>
  <p>Leadership should establish the mechanism to measure and monitor delivery to documented plans and controls. Mechanisms shall be communicated on how business performance shall be reported at both sector and regional level. </p>
  <h4>Collect, analyse and report against established KPIs</h4>
  <p>Each region shall determine what needs to be measured, aligned to their business plan. Methods shall be determined to ensure  reliable and valid results </p>
  <h4>Formal Quarterly review of performance to business plan</h4>
  <p>Quarterly Business Review (QBR) reports shall be documented and shared with top leadership. A formal review meeting shall be held to review performance, against established KPI's and the effectiveness of the business plan. Evidence of QBR reviews shall be documented.</p>
  <h4>Update Business plan to reflect deviations from the plan</h4>
  <p>The Business Plan should be reviewed at planned intervals and where necessary updated to reflect agreed actions from the QBR. The review shall include consideration of any changes or updates to existing risks and the identification of new risks. Any changes to the business plan shall be communicated to relevant stakeholders.</p>
  <h4>Identify and prioritise opportunities for improvements</h4>
  <p>Opportunities shall be identified to enhance client engagement, safety of our people and the care for the environment to drive enhanced satsifaction.   They shall include improving products and services to meet requirements as well as to address future needs and expectations; correcting, preventing or reducing undesired effects; and improving performance and effectiveness of the management system.</p>

  <h4>Manage Nonconformities</h4>
  <p>When a nonconformity arises, including complaints, action shall be taken to react by correcting it and dealing with the consequences; evaluating the need to take action to eliminate the cause of the nonconformity to prevent reocurrence; and to implement any actions needed. The effectiveness of any actions taken shall be reviewed and the risk and opportunity register updated if necessary, along with any identified changes needed to the management system. </p>

  <h4>Continually improve the management system </h4>
  <p>The management system shall be continually improved to ensure suitability, adequacy and effectiveness. The management system shall be reviewed by top management at planned intervals and any decisions and actions shall be documented and managed through to closure.</p>

</div>
</div>
</div>
</div>
<!-- Main content Container section end here -->


</div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "LeadProcessPerformanceAndImproveDetailedViewcomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>