<template>
    <div>




<!-- Main content Container section start from here -->
<div class="cont-container">
<div class="content-wt">
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/DeliverWorkAllSteps';">All</button>
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkStartJobTab';">Start the Job Right </button>
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkDoJobTab';">Do the Job Right </button>
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkFinishJobTab';">Finish the Job Right  </button>
</div>
  
 <div class="cont-row-wrapper mt">
    <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProposalHandover';"><div class="outline-cont-dl"><p>Proposal Handover</p></div></div>
   <div class="scroll-area-sgl">
   <ul class="list-box-dl">
      <li><div class="first-child-dl">Identify appropriately assessed and competent PD and PM when procurement document received</div></li>
      <li><div class="first-child-dl">Involve PD and PM in establishing the proposed baselines/deliverables</div></li>
      <li><div class="first-child-dl">Document proposal baselines, deliverables and outline delivery principles</div></li>
      <li><div class="first-child-dl">Conduct formal handover meeting between proposal manager, PD and PM</div></li>
      <li><div class="second-child-dl">Finalise and document the Project Management Plan</div></li>
      <li><div class="second-child-dl">Engage competent project resources</div></li>
      </ul>
    </div>
    </div>
    
<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectPlanning';"><div class="outline-cont-dl"><p>Project Planning</p></div>
 </div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Identify appropriately assessed and competent PD and PM when procurement document received</div></li>
     <li><div class="first-child-dl">Involve PD and PM in establishing proposed baselines/deliverables</div></li>
     <li><div class="first-child-dl">Conduct formal handover between Proposal Manager, PD and PM</div></li>
     <li><div class="second-child-dl">Understand client and contractual obligations</div></li>
     <li><div class="second-child-dl">Confirm deliverables with client</div></li>
     <li><div class="second-child-dl">Establish project baseline reference levels to monitor and control the project</div></li>
     <li><div class="second-child-dl">Set up relevent financial management system for the project</div></li>
     <li><div class="second-child-dl">Document required Project Management Plans aligned to project risk categorisation</div></li>
     <li><div class="third-child-dl">Formally mobilise the project, appropriate to the project risk, scale & complexity </div></li>
     <li><div class="third-child-dl">Manage project delivery in line with the Project Management Plan </div></li>
     <li><div class="third-child-dl">Review, measure and monitor project performance against the Project Management Plan</div></li>
     <li><div class="forth-child-dl">Measure client satisfaction post delivery </div></li>
     <li><div class="forth-child-dl">Conduct end of project review in line with the project risk categorisation</div></li>
    </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectFinancialManagement';"><div class="outline-cont-dl"><p>Project Financial Management</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Handover the proposal commercial strategy to the delivery team</div></li>
     <li><div class="second-child-dl">Review proposal pricing against contractual obligations</div></li>
     <li><div class="second-child-dl">Finalise project estimating and pricing model </div></li>
     <li><div class="second-child-dl">Confirm project financial baselines</div></li>
     <li><div class="second-child-dl">Generate financial project summary report on relevant finance system </div></li>
     <li><div class="second-child-dl">Document Financial Management Plan </div></li>
     <li><div class="third-child-dl">Formally mobilise project informing the project team of key project financial controls</div></li>
     <li><div class="third-child-dl">Assign budgets to discipline leads and interdivisional </div></li>
     <li><div class="third-child-dl">Monitor and review project costs against financial plan </div></li>
     <li><div class="third-child-dl">Review and update Project Summary Report monthly</div></li>
     <li><div class="third-child-dl">Invoice client against agreed payment terms in line with contractual requirements </div></li>
     <li><div class="forth-child-dl">Close Project Finances</div></li>
     <li><div class="forth-child-dl">Archive project information in line with contractual obligations</div></li>
  </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverworkProjectMobilisation';"><div class="outline-cont-dl"><p>Project Mobilization</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="second-child-dl">Document required Project Management Plans  </div></li>
     <li><div class="second-child-dl">Define project team roles and responsibilities, and identify competent individuals</div></li>
     <li><div class="second-child-dl">Identify competent Technical Leads and Technical Reviewers </div></li>
     <li><div class="second-child-dl">Hold Client kick off meeting  </div></li>
     <li><div class="second-child-dl">Brief Technical Reviewers on expectations, budget and requirements </div></li>
     <li><div class="third-child-dl">Formally mobilise the project involving the project team </div></li>
     <li><div class="third-child-dl">Evidence project team have read and understood Project Management Plan</div></li>
    </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectRiskManagement';"><div class="outline-cont-dl"><p>Project Risk Management </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Document risk categorisation of the project</div></li>
     <li><div class="first-child-dl">Identify proposal risks, assumptions and exclusions</div></li>
     <li><div class="first-child-dl">Conduct formal handover meeting between proposal manager, PD and PM</div></li>
     <li><div class="second-child-dl"> Understand client expectations aligned to contractual obligations and proposal commitments</div></li>
     <li><div class="second-child-dl">Review and validate risks and assumptions identified as part of the proposal </div></li>
     <li><div class="second-child-dl">Review project requirements and identify additional risks</div></li>
     <li><div class="second-child-dl">Document Risk Management Plan as part of the Project Management Plan</div></li>
     <li><div class="second-child-dl">Document the Project Risk Register</div></li>
     <li><div class="second-child-dl">Analyse and evaluate risks, identify owners and document mitigation plan</div></li>
     <li><div class="second-child-dl">Treat risks and/or schedule subsequent treatment</div></li>
     <li><div class="third-child-dl">Formally mobilise project and share project risks with the project team </div></li>
     <li><div class="third-child-dl">Manage and review project risk register in line with the Project Management Plan</div></li>
     <li><div class="third-child-dl">Review and update risk register; identify new risks, review existing risks, analyse and evaluate all.</div></li>
     <li><div class="third-child-dl">Communicate any changes and actions to risk register to relevant stakeholders</div></li>
     <li><div class="third-child-dl">Treat risks</div></li>
     <li><div class="forth-child-dl">Confirm with client the contractual obligations are complete</div></li>
     <li><div class="forth-child-dl"> Document residual risks and ongoing liabilities</div></li>
     <li><div class="forth-child-dl">Archive risk register in line with contractual obligations</div></li>
 </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectInfoManagement';"><div class="outline-cont-dl"><p>Project Info Management</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl"> Identify proposal assumptions for management of Information </div></li>
     <li><div class="second-child-dl">Establish project information requirements and standards to be met </div></li>
     <li><div class="second-child-dl"> Establish information deliverables required and milestones</div></li>
     <li><div class="second-child-dl"> Establish information exchange requirements and means of sharing/publishing</div></li>
     <li><div class="second-child-dl">Confirm how information management responsibilities will be addressed within team </div></li>
     <li><div class="second-child-dl">Agree information delivery approach with client</div></li>
     <li><div class="second-child-dl"> Document Project Information Management plan as part of the Project Management Plan</div></li>
     <li><div class="second-child-dl">Update risk register with information management assumptions </div></li>
     <li><div class="third-child-dl">Formally mobilise project and share the Project Information Management plan with the project team</div></li>
     <li><div class="third-child-dl">Undertake information management assurance checks</div></li>
     <li><div class="third-child-dl"> Undertake reviews of information management approach as defined in Project Management Plan</div></li>
     <li><div class="third-child-dl">Update as required the information management approach following review</div></li>
     <li><div class="third-child-dl">Hand over information to client and confirm acceptance </div></li>
     <li><div class="forth-child-dl">Review and document information management learning from the project</div></li>
     <li><div class="forth-child-dl">Archive project information in line with contractual obligations</div></li>
 </ul>
</div>
</div>
<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkClientSatisfaction';"><div class="outline-cont-dl"><p>Client Satisfaction </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Understand client requirements aligned to proposal commitments </div></li>
     <li><div class="first-child-dl">Conduct formal handover meeting between proposal manager, PD and PM </div></li>
     <li><div class="second-child-dl">Identify client requirements from offer commitments and contractual obligations</div></li>
     <li><div class="second-child-dl">Document Stakeholder Management Plan  as part of the Project Management Plan</div></li>
     <li><div class="third-child-dl">Formally mobilise project outlining client requirements in line with Stakeholder Management plan </div></li>
     <li><div class="third-child-dl">Manage scope of services in line with Project Management Plan</div></li>
     <li><div class="third-child-dl">Measure and document client satisfaction as defined in the Project Management Plan</div></li>
     <li><div class="third-child-dl">Share key learning with Project Team</div></li>
     <li><div class="forth-child-dl">Measure and document client satisfaction post deliverables</div></li>
     <li><div class="forth-child-dl">Archive client satisfaction information in line with contractual obligations </div></li>
 </ul>
</div>
</div>
<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkTechnicalAssurance';"><div class="outline-cont-dl"><p>Technical Assurance</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Understand client requirements aligned to proposal commitments </div></li>
     <li><div class="first-child-dl">Conduct formal handover meeting between proposal manager, PD and PM </div></li>
     <li><div class="second-child-dl">Identify approach to ensure deliverables meet proposal offer commitments and contractual obligations</div></li>
     <li><div class="second-child-dl">Identify and document external compliance requirements </div></li>
     <li><div class="second-child-dl">Document learning from previous projects and updated guidance</div></li>
     <li><div class="second-child-dl">Document technical methodology and deliverables </div></li>
     <li><div class="second-child-dl">Identify competencies required to deliver the project</div></li>
     <li><div class="second-child-dl">Identify competent people to undertake technical assurance responsibilities</div></li>
     <li><div class="second-child-dl">Identify benchmark criteria for check and review assessment</div></li>
     <li><div class="second-child-dl">Document technical assurance requirements as part of Project Management Plan</div></li>
     <li><div class="second-child-dl">Document technical risks on the risk register</div></li>
     <li><div class="third-child-dl">Formally mobilise project and  evidence understanding of scope, schedule and technical assurance expectations</div></li>
     <li><div class="third-child-dl">Fully brief check, review and authorisers on key criteria for review</div></li>
     <li><div class="third-child-dl">Programme all technical assurance activities, including check and review</div></li>
     <li><div class="third-child-dl">Monitor progress and impact of delivery to technical assurance as part of planned project reviews</div></li>
     <li><div class="third-child-dl">Capture, document and ensure closure of actions resulting from reviews of deliverables, including check and review </div></li>
     <li><div class="third-child-dl">Proactively manage, assess and record change and risks on appropriate registers</div></li>
     <li><div class="third-child-dl">Seek and document client satisfaction in line with Project Management Plan, aligned to key milestone deliverables</div></li>
     <li><div class="third-child-dl">Share key learning from project reviews and client feedback with project team </div></li>
     <li><div class="third-child-dl">Check, review and authorise all deliverables in line with the Project Management Plan prior to issuing to any external parties </div></li>
     <li><div class="third-child-dl">Document and control all information shared with the client in line with Project Management Plan </div></li>
     <li><div class="forth-child-dl">Confirm with the client all deliverables are complete </div></li>
     <li><div class="forth-child-dl">Confirm with client contractual obligations are complete</div></li>
     <li><div class="forth-child-dl">Collate and share technical learning from the project </div></li>
     <li><div class="forth-child-dl">Archive project information in line with contractual obligations</div></li>
</ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectPerformance';"><div class="outline-cont-dl"><p>Project Performance </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Identify proposal assumptions and exclusions aligned to proposal baseline reference levels</div></li>
     <li><div class="first-child-dl">Conduct formal handover meeting between proposal manager, PD and PM </div></li>
     <li><div class="second-child-dl">Establish project baseline reference levels to monitor and control the project</div></li>
     <li><div class="second-child-dl">Document Project Management Plan, aligned to project risk categorisation</div></li>
     <li><div class="third-child-dl">Formally mobilise project and share project baseline reference levels </div></li>
     <li><div class="third-child-dl">Hold project progress meetings with key members of the project team in line with the Project Management Plan</div></li>
     <li><div class="third-child-dl">Conduct regular Project Financial Reviews as defined in the Project Management Plan</div></li>
     <li><div class="third-child-dl">Provide progress updates to key stakeholders in line with PMP</div></li>
     <li><div class="third-child-dl">Share key learning with Project Team </div></li>
     <li><div class="third-child-dl">Review and update Project Management Plan to reflect project delivery</div></li>
     <li><div class="third-child-dl">Measure and document client satisfaction during delivery in line with Stakeholder Management Plan</div></li>
     <li><div class="forth-child-dl">Measure client satisfaction post delivery in line with Stakeholder Management Plan</div></li>
     <li><div class="forth-child-dl">Conduct End of Project Review</div></li>
</ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectChangeControl';"><div class="outline-cont-dl"><p>Project Change Control</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl">Understand client requirements aligned to proposal commitments</div></li>
     <li><div class="second-child-dl">Understand contractual change mechanism aligned to contractual obligations</div></li>
     <li><div class="second-child-dl">Document Contract Administration Plan as part of the Project Management Plan  </div></li>
     <li><div class="second-child-dl">Develop Change Management Plan as part of the Project Management Plan</div></li>
     <li><div class="second-child-dl">Create change register </div></li>
     <li><div class="third-child-dl">Inform Project Team of the change management plan as part of Project Mobilization</div></li>
     <li><div class="third-child-dl">Regularly review known changes and consider potential changes  </div></li>
     <li><div class="third-child-dl">Update change register to reflect potential and agreed changes</div></li>
     <li><div class="third-child-dl">Review and gain agreement for changes with the client</div></li>
     <li><div class="third-child-dl">Approve all changes in line with the gated approval process where required</div></li>
     <li><div class="third-child-dl">Quantify and assess the impact of changes against the project baseline</div></li>
     <li><div class="third-child-dl">Formally communicate the impact of the change to the project team</div></li>
     <li><div class="third-child-dl">Update project forecast to reflect changes </div></li>
     <li><div class="third-child-dl">Invoice changes as per contractual terms  </div></li>
     <li><div class="forth-child-dl">Confirm with client contractual obligations are complete </div></li>
     <li><div class="forth-child-dl">Collate and share learning from the project </div></li>
     <li><div class="forth-child-dl">Close project finances </div></li>
     <li><div class="forth-child-dl">Archive project change information in line with contractual obligations</div></li>
  </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkExternalProjectProcurementManagement';"><div class="outline-cont-dl"><p>External Project Procurement Management </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="first-child-dl"> Document proposed procurement need in a plan</div></li>
     <li><div class="first-child-dl">Identify approved suppliers in line with procurement plan</div></li>
     <li><div class="first-child-dl">Consider commercial risk and ensure relevant protection in place </div></li>
     <li><div class="first-child-dl">Engage suppliers to obtain budgetary pricing </div></li>
     <li><div class="first-child-dl">Conduct formal handover meeting between proposal manager, PD and PM</div></li>
     <li><div class="second-child-dl">Review and document procurement requirements</div></li>
     <li><div class="second-child-dl">Document Procurement Plan as part of the Project Management Plan   </div></li>
     <li><div class="second-child-dl">Approve competent supplier(s)  </div></li>
     <li><div class="second-child-dl">Agree criteria for the evaluation of tenders</div></li>
     <li><div class="second-child-dl">Complete purchase requisition (or equivalent as required)</div></li>
     <li><div class="second-child-dl"> Complete tender process in line with documented plan </div></li>
     <li><div class="second-child-dl">Select preferred supplier</div></li>
     <li><div class="second-child-dl">Agree formal contract with supplier in line with LOA </div></li>
     <li><div class="second-child-dl">Document Contract Administration plan </div></li>
     <li><div class="third-child-dl"> Documented evidence from supplier received and contract accepted   </div></li>
     <li><div class="third-child-dl">Conduct contract mobilization meeting with supplier </div></li>
     <li><div class="third-child-dl">Monitor and review supplier performance and progress in accordance with contract administration plan  </div></li>
     <li><div class="third-child-dl">Manage change in accordance with the provisions of the contract and in line LoA</div></li>
     <li><div class="forth-child-dl">Confirm services / goods delivered by supplier</div></li>
     <li><div class="forth-child-dl">Evaluate and document supplier performance as part of Project closure</div></li>
     <li><div class="forth-child-dl">Conduct end of project review in line with Project Management Plan</div></li>
</ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectClosure';"><div class="outline-cont-dl"><p>Project Closure</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="second-child-dl">Understand contractual obligations in relation to archiving of project information </div></li>
     <li><div class="second-child-dl">Document project key success measures as part of the Project Management Plan </div></li>
     <li><div class="second-child-dl">Document client feedback requirements  </div></li>
     <li><div class="third-child-dl">Define approach to capture learning from the project as part of the Project Management Plan</div></li>
     <li><div class="third-child-dl">Document project archive requirements as part of Project Management Plan</div></li>
     <li><div class="third-child-dl">Identify and plan for anticipated project closure date</div></li>
     <li><div class="forth-child-dl">Confirm with client the contractual obligations are complete</div></li>
     <li><div class="forth-child-dl">Measure client satisfaction post deliverables</div></li>
     <li><div class="forth-child-dl">Document residual risks and ongoing liabilities</div></li>
     <li><div class="forth-child-dl">Close project finances</div></li>
     <li><div class="forth-child-dl">Conduct end of project review in line with the project risk categorisation</div></li>
     <li><div class="forth-child-dl">Document learning from the project</div></li>
     <li><div class="forth-child-dl">Archive project information in line with contractual obligations</div></li>
</ul>
</div>
</div>
</div>
</div>
<!-- Main content Container section end here -->



</div>

  
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "DeliverWorkAllStepsComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>