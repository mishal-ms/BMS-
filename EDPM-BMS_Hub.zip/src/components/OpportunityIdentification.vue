<template>
    <div>


<!-- Main content Container section start from here -->
<div class="cont-container">
      <div class="content-wt">
    <div class="content-hd-text">
      <h2>Opportunity Identification</h2>
      <p><strong class="bld-txt">Opportunity identification and classification</strong> refers to the process of identifying, quantifying and classifying Win Work Pursuit Opportunities. A consistently applied methodology and set of practices for doing this helps in the prioritization or Pursuits; helping to inform key decisions around where to allocate resource and investment, and where there are opportunities to leverage global capabilities to maximize chances of bidding success.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" >Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/OpportunityIdentificationDetailedView';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>

  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <div class="row-box">
        <div class="box" v-on:click="show(' Should be aligned to Regional Market Strategies and informed by basic market analysis that identifies market drivers and trends. ')">
          <div class="content bg-base"><p class="para-cont">Identify strategy and
            market priorities</p></div> 
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show(' Should be aligned to Regional Market Strategies and should be informed by an understanding of where customer demand drivers meet Engineering Services capabilities')">
          <div class="content bg-base"><p class="para-cont">Identify
            target
            clients  </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Should be derived from by ongoing client engagement and monitoring of formal procurement portals and channels.')">
          <div class="content bg-base"><p class="para-cont">Identify pipeline of
            opportunities aligned
            to market priorities </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('New opportunities should be uploaded to local CRM system and should include as much relevant information as is possible to record.')">
          <div class="content bg-base"><p class="para-cont">Record pipeline of
            opportunities on
            relevant client
            management system</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt" v-on:click="show('Opportunity pipeline data should analysed and critically assessed to apportion appropriate weighting. Pipeline analysis and assessment should be informed by client and competitor intelligence.')">
          <div class="content bg-base"><p class="para-cont">Review opportunities
            in pipeline and
            manage weighting
            based on client and
            competitor analysis</p></div>
          </div>
        
      </div>

       <div class="row-reverse-last-child">
        <div class="box" v-on:click="show('Review total costs of bid activity for the period - direct and indirect.')">
          <div class="content bg-base"><p class="para-cont">Identify pursuit investment </p></div>
        </div>
        <div class="box" v-on:click="show('Identify suitable opportunities to pursue. Assess risks and conduct go/no go to identify opportunities to pursue further.')">
          <div class="content bg-base"><p class="para-cont">Select opportunities and confirm Go/No Go</p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('A Capture Planning process should be initiated, utilizing the tools, processes and guidance available')">
          <div class="content bg-base"><p class="para-cont">Prepare for the potential opportunity using the capture planning process </p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-base cursor-none"><p class="para-cont">Review and monitor the capture plan relevant to size of Opportunity </p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        
      </div>
    </div>
    </div>

    <RightInformationPannel/>

    </div>
  
    




</div>
  
</div>
<!-- Main content Container section end here -->





    </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapActions } from "vuex";
import RightInformationPannel from "../components/RightInformationPannel"
export default {
  name: "OpportunityIdentificationComp",
  components: {RightInformationPannel},
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  methods: {
     ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>