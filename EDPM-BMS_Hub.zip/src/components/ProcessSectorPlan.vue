<template>
    <div>
 

<!-- Main content Container section start from here -->
<div class="cont-container">
    <div class="content-wt">
    <div class="content-hd-text">
      <h2>Sector Plan</h2>
      <p>The Sector plan provides a clear picture of what we want our future to look like over the next 5 years. It highlights our competitive advantages and seeks to close any capability gaps in our organization. It creates a high level of awareness around shared goals and ambitions, giving attention to activities which create sustainable success. It defines and drives decisions about the right organizational design for innovation and growth and it prepares us to deliver to the 5 year Strategy.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/ProcessSectorPlan';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/LeadProcessSectorPlanDetailedView';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">

      <div class="row-box">
        <div class="box" v-on:click="show('Each Region shall identify external and internal factors which might influence and impact their business plan. They should use recognised strategic frameworks, such as PESTLE, SWOT, Porters Five Forces to develop an understanding of these factors to inform their plan.')">
          <div class="content bg-lead-mx"><p class="para-cont">Identify and understand internal and external factors influencing and affecting the organization's ability to deliver products and services </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Each region shall develop and document a 5 year plan using an approved template which shall be approved by the Sector President. The regional 5 year plan shall set out the goals and objectives for the region and shall be used to inform the Sector 5 year plan.')">
          <div class="content bg-lead"><p class="para-cont">Develop Regional 5 year plans </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('The 5 year Sector plan shall be documented. It shall be informed and supported by the regional 5 year plans. It shall set out the Sector roadmap, investment and objectives and shall inform the SNC-L 5 year Strategy.')">
          <div class="content bg-lead"><p class="para-cont">Complete the 5 year Sector Plan aligned to SNC-L strategy  </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('The approved 5 year Sector plan shall be cascaded through the sector to ensure all employees are aware of the objectives and goals for the sector. Each region shall share their 5 year regonal plan to enable employees to understand the key strategic themes and how they contribute to the success of the sector.')">
          <div class="content bg-lead"><p class="para-cont">Share and cascade the 5 year Sector plan</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Controls shall be identified to manage delivery to the 5 year sector plan. A sector management system shall be established to ensure effective implementation of identified controls. The management system shall be regularly reviewed and updated to respond to required changes to the context and factors impacting the documented plans.')">
          <div class="content bg-lead"><p class="para-cont">Identify relevant controls to deliver to the 5 year sector plan</p></div>
          </div>
      </div>  
</div>
</div>

    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span></div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>

  </div>
  </div>
  </div>
<!-- Main content Container section end here -->



    </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions} from "vuex";
export default {
  name: "ProcessPlanComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
   methods: {
           ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
   },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
