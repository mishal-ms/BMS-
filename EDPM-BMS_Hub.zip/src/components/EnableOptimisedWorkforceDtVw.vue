<template>
  <div>
    <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
       <h2>Optimized workforce</h2>
                <p>
                    <strong class="bld-txt">Workforce Optimization (WFO)</strong> refers
                    to a business strategy that is focused on balancing customer
                    satisfaction with service levels, workforce scheduling, operational
                    costs, and other key performance metrics. The goal is to get the
                    maximum performance from employees at any given time while servicing
                    customers in a way that works for them. WFO is an overall approach
                    to business operation with the necessary tools and applications put
                    in place to foster efficient and effective growth.
                </p>
  </div>
  <div class="tabs">
     <button class="tab-link" onclick="window.location.href='#/EnableOptimisedWorkforce';">
                    Requirements
                </button>
                <button class="tab-link active" onclick="window.location.href='#/EnableOptimisedWorkforceDtVw';">
                    Additional Detail
                </button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Share Sector Business Plan </h4>
  <p>The resource, skills and knowledge expectations to deliver to the sector plan shall be used to build the workforce management plans and inform future workforce planning needs</p>
  <h4> Establish Workforce Management Plan</h4>
  <p>The resource management plan identifies the availability and skills required to deliver the short to medium term commitments.  It should balance staffing issues, agency staff, staff retention, recruitment and training. </p>
  <h4>Establish documented development plans for all employees</h4>
  <p>Development plans shall be identified to ensure people have the right knowledge, right skills and right tools to deliver to expectations</p>
  <h4>Support employee development </h4>
  <p>Capture learning from experience and make it available to share with employees to support development</p>
 <h4> Document effective technology plan </h4>
  <p>Provide employees with the right technology to effectively deliver to client requirements</p>

   <h4>Dcoument workforce planning strategy</h4>
  <p>A workforce planning strategy shall understand and plan for future workforce needs. It shall take into account changing skills, expectations, markets and drivers to ensure the workforce of the future is ready to deliver to expectations with the right capabilities and working environment to deliver business success.</p>

  

</div>
</div>
  
  </div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "EnableOptimisedWorkforceDtVwComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>