<template>
<div>



<!-- Main content Container section start from here -->
 <div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Client Satisfaction </h2>
      <p>A quality deliverable begins and ends with understanding our client requirements and ensuring we deliver to these requirements. Only our clients can tell us if we meet their expectations. Collecting client feedback throughout the lifecycle of a project is key to helping us improve as a business, providing valuable insights as to whether our services, products and capabilities are fulfilling the needs and expectations of our clients, and informing where we should focus next to achieve even  greater levels of client satisfaction.</p>
  </div>
  <div class="tabs">
   <button
            class="tab-link"
            onclick="window.location.href='#/DeliverWorkClientSatisfaction';">
            Requirements
          </button>
          <button
            class="tab-link active"
            onclick="window.location.href='#/DeliverWorkClientSatisfactionNew';">
            Additional Detail
          </button>
     <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4>Understand client requirements aligned to proposal commitments</h4>
  <p>The Proposal lead shall fully understand client requirements, have assessed these as being reasonable and translated them into a clear scope of work. The project scope (deliverables and associated work to produce them) must be clearly defined in the contract. The PM shall ensure the project team and the client have a clear, shared understanding of the project scope and the allocation of responsibility for associated activities between ourselves, the client or other third parties. Any deviations in understanding or expectations from the contracted scope must be identified as potential changes There shall be an agreed process to record agreement of the scope.</p>
  <h4>Conduct formal handover meeting between proposal manager, PD and PM</h4>
  <p>To ensure understanding of the clients drivers and priorities all information & knowledge relating to the project shall be transferred between the proposal lead and PM where these are different. The format of the handover shall be proportionate to the scale, risk and complexity of the project.</p>
  <h4> Identify client requirements from offer commitments and contractual obligations</h4>
  <p>Before commencing work there shall be documented evidence of a commitment from the client to procure and pay for our services. This should be a signed, agreed contract. Where a signed agreed contract is not in place appropriate approval, in  line with LoA approvals, shall be in place. The client requirements and contract shall identify the client expectations on how they will be informed of project progress; change control and risk management etc. The PM shall ensure what we have committed to deliver has been translated into what we have contracted to deliver. The Project Management Plan needs to respond to our contractual obligations and agreed client commitments.</p>
  <h4>Document Stakeholder Management Plan  as part of the Project Management Plan</h4>
  <p>The Stakeholder Management Plan sets out the preferred procedures, tools and techniques to be used in managing stakeholders. Stakeholder management involves identifying people or organizations that may be impacted or affected by the project, including the client. The Stakeholder Management Plan shall document the approach to gathering client feedback at all levels during the lifecycle of the project.</p>
  <h4>Formally mobilise project outlining client requirements in line with Stakeholder Management plan</h4>
  <p>Mobilizing the project shall be planned and delivered in a timely manner to clearly communicate key stakeholders and the roles and responsibilities within the project team for engaging with key stakeholders. The PM shall  ensure internal and external project team members know who to communicate with and understand their level of delegated authority. The method for capturing and sharing client feedback, including client complaints shall be shared with the project team.</p>

  <h4>Manage scope of services in line with Project Management Plan</h4>
  <p>The PM shall deliver the brief to the defined scope ensuring the client is communicated with in a timely manner to understand project progress, any emerging risks and potential changes. Change and risk are the key drivers that impact on delivery. Failure to understand the implications of either and to address them can have severe commercial, contractual and legal consequences. Therefore ensuring that all parties are using current data and have addressed all reasonable risks is fundamental to successful delivery</p>

  <h4>Measure and document client satisfaction as defined in the Project Management Plan</h4>
  <p>Client satisfication may be measured formally through client surveys, agreed KPIs or client audit requirements or it may be through informal discussions. The Stakeholder Management Plan should define how formal feedback will be sought and shall agree milestones for a formal client satisfaction survey. The frequency and requirement for formally defined feedback shall be proportionate to the size, scale and complexity of the project but shall ensure the client has the opportunity to share feedback during, and at the end, of the project.</p>

  <h4>Share key learning with Project Team </h4>
  <p>Learning from client feedback should be shared with the wider project team during the project to inform improvements which will increase client satisfaction.</p>

  <h4>Measure and document client satisfaction post deliverables</h4>
  <p>Once the project is substantially closed client feedback shall be sought to document the level of client satisfaction; enable any issues to be resolved prior to project closure and to provide valuable learning for future projects. It should be carried out immediately prior to demobilization of project resources to capture the wider project team perspective.</p>

  <h4>Archive client satisfaction information in line with contractual obligations</h4>
  <p>Learning that has been captured during the delivery of the project shall be documented in a format that can be shared. All client feedback shall be archived with the wider project documentation.</p>

</div>
</div>
</div>
</div>
<!-- Main content Container section end here -->


</div>

</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "DeliverWorkClientSatisfactionNewComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>