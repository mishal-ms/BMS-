<template>
  <div>
    <!-- Main content Container section start from here -->
    <div class="cont-container">
      <div class="content-wt">
        <div class="content-hd-text">
          <h2>Project Risk Mangement</h2>
          <p>
            Effective risk management is fundamental to helping us achieve our
            project objectives. Risk management is important during project
            planning, mobilization and execution; well-managed risks and
            opportunities significantly increase the likelihood of project
            success. A structured and proactive approach to risk management
            leads to better decision making and therefore better project
            outcomes.
          </p>
        </div>
        <div class="tabs">
          <button
            class="tab-link active"
            onclick="window.location.href='xxxxx.html';"
          >
            Requirements
          </button>
          <button
            class="tab-link"
            onclick="window.location.href='#/DeliverWorkProjectRiskManagementNew';"
          >
            Additional Detail
          </button>
          <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button>  -->
        </div>
        <div class="row-content">
          <div class="col-9">
            <div class="card-wrap">
              <div class="row-box">
                <div class="box" v-on:click="show('The PM and PD shall be engaged during the proposal stage to understand the assumptions and exclusions which shall be factored into the proposal and the associated risks to delivery ')">
                  <div class="content bg-fst-chld">
                    <p class="para-cont">
                      Identify proposal risks, assumptions and exclusions
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The Project manager shall ensure that they have a complete set of proposal related materials including the proposal risk register.')">
                  <div class="content bg-fst-chld">
                    <p class="para-cont">
                      Conduct formal proposal handover
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The PM shall review the contract to understand the contractual obligations and identify the associated plans needed to manage and control the project. The Project Management Plans shall also take into account any commitments made to the client as part of engagement during the proposal phase.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Understand client expectations aligned to contractual
                      obligations and proposal commitments
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Following review of the contractual obligations the proposal risk register shall be reviewed to confirm that the identified risks are appropriate.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Review & validate risks & assumptions identified as part of the bid
                    </p>
                  </div>
                   <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                 <div class="box arrow-rt" v-on:click="show('When developing the project plans and identifying the delivery methodology, additional risks should be identified and included on the project risk register')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Review project requirements and identify additional risks
                    </p>
                  </div>
                </div>
              </div>

              <div class="row-reverse">
                <div class="box" v-on:click="show('The approach to risk management shall be documented. For smaller projects this is typically part of the project management plan but for more complex project it may require a separate risk management plan.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Develop Risk Management Plan as part of the Project Management Plan
                    </p>
                  </div>
                  
                </div>
                <div class="box" v-on:click="show('Construct a quantified risk log on the basis of known risks, assumption, exclusions & dependencies. This shall include mitigation plans where necessary. The PM should engage subject matter experts and/or the project team as appropriate to identify risks.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">Develop and document the Project Risk Register</p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Risks shall be quantified and include as a minimum an assessment of Impact & Probability. An appropriate mitigation strategy shall be identified. There are four mitigation strategies available: 1. Terminate – e.g. the scheme is too risky to offer a bid, risks exceed rewards – avoid 2. Transfer the risk – transfer to a third party, contractor, subcontractor, client, insurance company 3. Treat – reduce the likelihood, or reduce the impact, do more investigative work 4. Tolerate – keep the risk and manage it within our contingency provision in accordance with the agreed action plan')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                     Analyse and evaluate risks, identify owners and document mitigation plan
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Treatment shall be in line with the PMP and any individual mitigation strategy.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Treat risks and/or schedule subsequent treatment
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                 <div class="box arrow-lt" v-on:click="show(' Accountability and ownership for individual risks shall be documented and understood. Mitigation strategies shall be shared with the wider project team to ensure risks are appropriately managed and controlled. ')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Formally mobilize project and share project risks with the
                      project team
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
              </div>

              <div class="row-box">
               
                <div class="box" v-on:click="show('The PM should declare the status and progress of risks in line with the Project plan and review cycle. The communication and escalation approach shall be described within the PMP.')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Manage and review Project Risk Register in line with PMP
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The risk register is a dynamic document that shall be regularly reviewed to ensure all project risks are identified and being suitably managed.  The identification, update, review and analysis required to effectively manage risks shall be documented within the PMP.')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Review and update risk register; identify new risks,
                      review existing risks, analyse and evaluate all.
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Risks need to be reviewed and assessed to identify those which require escalation. Escalation may result in additional LoA or gated approval levels being required or management as part of the wider Business Enterprise Risk Management process')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Escalate / communicate any changes and actions to risk register to  relevant stakeholders
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Treatment shall be in line with the PMP and any individual mitigation strategy.')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">Treat risks</p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                 <div class="box arrow-lt" v-on:click="show('The PM shall confirm with the client all final deliverables have addressed all contractual obligations prior to formally closing the project.  ')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Confirm with client the contractual obligations are
                      complete
                    </p>
                  </div>
                </div>
              </div>

              <div class="row-reverse-last-child">
               
                <div class="box" v-on:click="show('Any risks and/or liabilities which cannot be mitigated and may present in the future shall be documented and archived in a manner that can be easily retrieved and understood should the risk/liability materialise at some point in the future.')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
Close out residual risks, where possible                    </p>
                  </div>
                 
                </div>
                <div class="box" v-on:click="show('Project data shall be retained and archived in line with contractual obligations and the requirements laid out in the PMP. Any residual risks beyond the project shall be clearly documented and appropriately escalated.')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
Archive risk register, (including outstanding Project Risks not mitigated), in line with contractual requirements                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
              </div>
            </div>
          </div>
   <!-- <RightInformationPannel/> -->

          <div class="col-3">
            <div class="content-box">
              <div class="own-detail">
                <span
                  >Process Owner:
                  <strong class="bld-txt"> Nick Welch</strong></span
                >
                <!-- <span
                  >Key Contact:
                  <strong class="bld-txt">Joann Clarke</strong></span
                > -->
              </div>
              <div class="ult-links">
                <h4>Useful links</h4>
                <a href="https://atkins.sharepoint.com/sites/dwh/html/index.aspx?OR=Teams-HL&CT=1649844968359&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjA0MDExMTQwMCJ9#/" target="_blank">Deliver Work Hub</a>
                <a href="https://atkins.sharepoint.com/sites/ESMS/SitePages/Glossary.aspx?OR=Teams-HL&CT=1649852129464&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjAzMjEwMDEwNyJ9" target="_blank">Glossary</a>
                <a href="http://axis.eu.atkinsglobal.com/uk/projectbids/bidprojectprocesses/world_riskmanagement/Pages/default.aspx" target="_blank">Risk Management</a>
                 <a href="https://atkins.sharepoint.com/sites/CommercialHub/html/index.aspx#/" target="_blank">Commercial Hub</a> 
              </div>
              <!-- <div class="ult-links">
                <h4>Training</h4>
                <a>xxxxxxx</a>
              </div> -->
              <div class="ult-links">
                <h4>Approved Deviations</h4>
                <a>None</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapActions } from "vuex";
// import RightInformationPannel from "../components/RightInformationPannel.vue";
export default {
  name: "DeliverWorkProjectRiskManagementComp",
  // components: {RightInformationPannel}
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  methods: {
     ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>