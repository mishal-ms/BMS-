<template>
<div>

    <!-- Main content Container section start from here -->
    <div class="main-cont-container">
        <div class="row content-wt">
            <div class="prc-column1">
                <FunctionalComponent />
            </div>
            <div class="led-prc">
                <ul>
                    <li><a href="#/ProcessLeadership">Leadership & Commitment</a></li>
                    <li><a href="#/ProcessSectorPlan">Sector<br/> Plan</a></li>
                    <li><a href="#/ProcessBusinessPlan">Business<br/> Plan</a></li>
                    <li><a href="#/ProcessImplement">Controls & Assurance</a></li>
                    <li><a href="#/ProcessPerformance">Performance</a></li>
                    <li><a href="#/ProcessImprovement">Improve</a></li>
                </ul>
            </div>
            <div class="win-wk-steps"><span id="wn-wk-process"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="298" height="298" viewBox="0 0 298 298">
      <defs>
        <linearGradient id="linear-gradient" x1="1" y1="0.53" x2="0" y2="0.523" gradientUnits="objectBoundingBox">
          <stop offset="0" stop-color="#ff7b00"/>
          <stop offset="1" stop-color="#e31c79"/>
        </linearGradient>
        <linearGradient id="linear-gradient-2" x1="1" y1="0.53" x2="0" y2="0.523" gradientUnits="objectBoundingBox">
          <stop offset="0" stop-color="#5b4b9a"/>
          <stop offset="1" stop-color="#e52370"/>
        </linearGradient>
        <clipPath id="clip-path">
          <path id="Subtraction_5" data-name="Subtraction 5" d="M149,298a150.1,150.1,0,0,1-30.029-3.027,148.179,148.179,0,0,1-53.278-22.42A149.425,149.425,0,0,1,11.709,207a148.231,148.231,0,0,1-8.682-27.969,150.442,150.442,0,0,1,0-60.057A148.2,148.2,0,0,1,25.447,65.693,149.443,149.443,0,0,1,91,11.709a148.267,148.267,0,0,1,27.969-8.682,150.452,150.452,0,0,1,60.058,0,148.18,148.18,0,0,1,53.278,22.42A149.438,149.438,0,0,1,286.291,91a148.264,148.264,0,0,1,8.682,27.969,150.466,150.466,0,0,1,0,60.057,148.186,148.186,0,0,1-22.42,53.279A149.436,149.436,0,0,1,207,286.291a148.249,148.249,0,0,1-27.969,8.682A150.1,150.1,0,0,1,149,298Zm1.552-225.57a75.018,75.018,0,1,0,75.017,75.018A75.1,75.1,0,0,0,150.552,72.43Z" transform="translate(0 0)" fill="url(#linear-gradient)"/>
        </clipPath>
      </defs>
      <g id="Group_1117" data-name="Group-1117" transform="translate(-335 -614)">
        <text onclick="window.location.href='#/PostSubmission'" style="cursor:pointer"  transform="translate(445 833.823)" fill="#fff" font-size="10" font-family="Roboto-Regular, Roboto"><tspan x="-6.931" y="0">26.</tspan><tspan x="-10.186" y="15">Post</tspan><tspan x="-26.104" y="30">Submission</tspan></text>
        <g id="Group_485" data-name="Group 485" transform="translate(335 614)">
          <path id="Subtraction_4" data-name="Subtraction 4" d="M149,298a150.1,150.1,0,0,1-30.029-3.027,148.179,148.179,0,0,1-53.278-22.42A149.425,149.425,0,0,1,11.709,207a148.231,148.231,0,0,1-8.682-27.969,150.442,150.442,0,0,1,0-60.057A148.2,148.2,0,0,1,25.447,65.693,149.443,149.443,0,0,1,91,11.709a148.267,148.267,0,0,1,27.969-8.682,150.452,150.452,0,0,1,60.058,0,148.18,148.18,0,0,1,53.278,22.42A149.438,149.438,0,0,1,286.291,91a148.264,148.264,0,0,1,8.682,27.969,150.466,150.466,0,0,1,0,60.057,148.186,148.186,0,0,1-22.42,53.279A149.436,149.436,0,0,1,207,286.291a148.249,148.249,0,0,1-27.969,8.682A150.1,150.1,0,0,1,149,298Zm1.552-225.57a75.018,75.018,0,1,0,75.017,75.018A75.1,75.1,0,0,0,150.552,72.43Z" transform="translate(0 0)" fill="url(#linear-gradient-2)"/>
          <g id="Mask_Group_3" data-name="Mask Group 3" transform="translate(0 0)" clip-path="url(#clip-path)">
            <g id="Group_484" data-name="Group 484" transform="translate(4.599 -16.567)">
              <line id="Line_19" data-name="Line 19" y2="331.668" transform="translate(143.135)" fill="none" stroke="#fff" stroke-width="0.5"/>
              <line id="Line_20" data-name="Line 20" x2="0.482" y2="330.834" transform="translate(286.27 82.917) rotate(60)" fill="none" stroke="#fff" stroke-width="0.5"/>
              <line id="Line_21" data-name="Line 21" x1="0.482" y2="330.834" transform="translate(286.51 248.334) rotate(120)" fill="none" stroke="#fff" stroke-width="0.5"/>
            </g>
          </g>
        </g>
        <text onclick="window.location.href='#/CapturePlanning'" style="cursor:pointer" transform="translate(413 672)" fill="#fff" font-size="10" font-family="Roboto-Regular, Roboto"><tspan x="-17.463" y="0">Capture</tspan><tspan x="-19.382" y="15">Planning</tspan></text>
        <text onclick="window.location.href='#/ProposalManagement'" style="cursor:pointer" transform="translate(526 653)" fill="#fff" font-size="10" font-family="Roboto-Regular, Roboto"><tspan x="-19.817" y="0">Proposal</tspan><tspan x="-29.441" y="15">Management</tspan></text>
        <text onclick="window.location.href='#/StragicPositioning'" style="cursor:pointer" transform="translate(540 853)" fill="#fff" font-size="10" font-family="Roboto-Regular, Roboto"><tspan x="-19.832" y="0">Strategic</tspan><tspan x="-25" y="15">Positioning</tspan></text>
        <text onclick="window.location.href='#/ClientDevelopment'" style="cursor:pointer" transform="translate(434 853)" fill="#fff" font-size="10" font-family="Roboto-Regular, Roboto"><tspan x="-13.96" y="0">Client </tspan><tspan x="-29.229" y="15">Development</tspan></text>
        <text onclick="window.location.href='#/PostSubmission'" style="cursor:pointer"  transform="translate(593 740.431)" fill="#fff" font-size="10" font-family="Roboto-Regular, Roboto"><tspan x="-10.186" y="0">Post</tspan><tspan x="-26.104" y="15">Submission</tspan></text>
        <ellipse id="Ellipse_46" data-name="Ellipse 46" cx="72.5" cy="72" rx="72.5" ry="72" transform="translate(413 688.484)" fill="#cbcbcb"/>
        <line id="Line_22" data-name="Line 22" x2="61.979" y2="39.253" transform="translate(483.767 761.27)" fill="none" stroke="#fff" stroke-width="0.5"/>
        <line id="Line_23" data-name="Line 23" y1="36.155" x2="61.98" transform="translate(423.853 762.3)" fill="none" stroke="#fff" stroke-width="0.5"/>
        <line id="Line_24" data-name="Line 24" x1="3.099" y1="77.474" transform="translate(482.733 687.693)" fill="none" stroke="#fff" stroke-width="0.5"/>
        <text onclick="window.location.href='#/ExploreTheMarket'" style="cursor:pointer"  transform="translate(487 803)" font-size="9" font-family="Roboto-Regular, Roboto"><tspan x="-22.282" y="0">Explore the</tspan><tspan x="-14.005" y="11">market</tspan></text>
        <text onclick="window.location.href='#/ExploreTheMarket'" style="cursor:pointer" transform="translate(432 724)" font-size="9" font-family="Roboto-Regular, Roboto"><tspan x="0" y="0">Develop the </tspan><tspan x="0" y="11">opportunity</tspan></text>
        <text onclick="window.location.href='#/ExploreTheMarket'" style="cursor:pointer" transform="translate(505 732.396)" font-size="9" font-family="Roboto-Regular, Roboto"><tspan x="0" y="0">Bid it &amp; </tspan><tspan x="0" y="11">win it</tspan></text>
        <g id="Ellipse_45" data-name="Ellipse 45" transform="translate(463 739)" fill="#fff" stroke="#707070" stroke-width="1">
          <ellipse cx="24" cy="24.5" rx="24" ry="24.5" stroke="none"/>
          <ellipse cx="24" cy="24.5" rx="23.5" ry="24" fill="none"/>
        </g>
        <text onclick="window.location.href='#/ExploreTheMarket'" style="cursor:pointer" transform="translate(487 760)" fill="#141414" font-size="12" font-family="Roboto-Regular, Roboto"><tspan x="-10.09" y="0">Win</tspan><tspan x="-13.726" y="14">Work</tspan></text>
        <text onclick="window.location.href='#/OpportunityIdentification'" style="cursor:pointer"  transform="translate(376 758)" fill="#fff" font-size="10" font-family="Roboto-Regular, Roboto"><tspan x="-26.074" y="0">Opportunity</tspan><tspan x="-28.997" y="15">Identification</tspan></text>
      </g>
    </svg>
    </span></div>
            <div class="hd-ovr-clr" onclick="window.location.href='#/DeliverWorkProposalHandover'" style="cursor:pointer;">Handover</div>
            <div class="del-wk-steps"><span id="del-wk-process"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="295.5" height="298.5" viewBox="0 0 295.5 298.5"><defs><linearGradient id="a" x1="1" y1="0.53" x2="0" y2="0.523" gradientUnits="objectBoundingBox"><stop offset="0" stop-color="#58595b"/><stop offset="1" stop-color="#e31c79"/></linearGradient><linearGradient id="b" x1="1" y1="0.53" x2="0" y2="0.523" gradientUnits="objectBoundingBox"><stop offset="0" stop-color="#003e5d"/><stop offset="1" stop-color="#009dd4"/></linearGradient><clipPath id="c"><path d="M147.5,298a145.857,145.857,0,0,1-82.469-25.447A149.115,149.115,0,0,1,3,179.028a151.929,151.929,0,0,1,0-60.057A149.153,149.153,0,0,1,65.032,25.447a146.175,146.175,0,0,1,164.937,0A149.119,149.119,0,0,1,292,118.971a151.968,151.968,0,0,1,0,60.057,149.15,149.15,0,0,1-62.034,93.525A145.808,145.808,0,0,1,147.5,298Zm1.536-225.57c-40.948,0-74.261,33.653-74.261,75.018s33.314,75.018,74.261,75.018S223.3,188.813,223.3,147.448,189.985,72.43,149.037,72.43Z" transform="translate(0 0)" fill="url(#a)"/></clipPath></defs><g transform="translate(-767.75 -613.75)"><g transform="translate(877 721)" fill="none" stroke="#707070" stroke-width="1"><circle cx="40.5" cy="40.5" r="40.5" stroke="none"/><circle cx="40.5" cy="40.5" r="40" fill="none"/></g>
            <text onclick="window.location.href='#/ExploreTheMarket'" style="cursor:pointer" transform="translate(918 759)" fill="#141414" font-size="12" font-family="Roboto-Regular, Roboto"><tspan x="-18.103" y="0">Deliver</tspan><tspan x="-13.726" y="14">Work</tspan></text><path d="M147.5,298a145.857,145.857,0,0,1-82.469-25.447A149.115,149.115,0,0,1,3,179.028a151.929,151.929,0,0,1,0-60.057A149.153,149.153,0,0,1,65.032,25.447a146.175,146.175,0,0,1,164.937,0A149.119,149.119,0,0,1,292,118.971a151.968,151.968,0,0,1,0,60.057,149.15,149.15,0,0,1-62.034,93.525A145.808,145.808,0,0,1,147.5,298Zm1.536-225.57c-40.948,0-74.261,33.653-74.261,75.018s33.314,75.018,74.261,75.018S223.3,188.813,223.3,147.448,189.985,72.43,149.037,72.43Z" transform="translate(768 614)" stroke="#fff" stroke-width="0.5" fill="url(#b)"/><g transform="translate(768 614)" clip-path="url(#c)"><g transform="translate(-16.109 -14.239)"><line y2="336.648" transform="translate(158.474)" fill="none" stroke="#fff" stroke-width="0.5"/><line x2="1.612" y2="335.478" transform="matrix(0.809, 0.588, -0.588, 0.809, 256.417, 32.147)" fill="none" stroke="#fff" stroke-width="0.5"/><line x2="0.996" y2="333.583" transform="matrix(0.309, 0.951, -0.951, 0.309, 316.949, 116.309)" fill="none" stroke="#fff" stroke-width="0.5"/><line x1="0.996" y2="333.583" transform="matrix(-0.309, 0.951, -0.951, -0.309, 317.256, 219.392)" fill="none" stroke="#fff" stroke-width="0.5"/><line x1="1.612" y2="335.478" transform="matrix(-0.809, 0.588, -0.588, -0.809, 257.72, 303.554)" fill="none" stroke="#fff" stroke-width="0.5"/></g></g>
            <text onclick="window.location.href='#/DeliverWorkProjectPlanning'" style="cursor:pointer" transform="translate(799 761.537)" fill="#fff" font-size="9" font-family="Roboto-Regular, Roboto"><tspan x="-14.168" y="0">Project</tspan><tspan x="-17.444" y="14">Planning</tspan></text>
            <text onclick="window.location.href='#/DeliverWorkProjectFinancialManagement'" style="cursor:pointer" transform="translate(816 690.299)" fill="#fff" font-size="9" font-family="Roboto-Regular, Roboto"><tspan x="-14.168" y="0">Project</tspan><tspan x="-17.98" y="14">Financial</tspan><tspan x="-26.497" y="28">Management</tspan></text>
            <text onclick="window.location.href='#/DeliverWorkProjectMobilisation'" style="cursor:pointer" transform="translate(876.699 650)" fill="#fff" font-size="9" font-family="Roboto-Regular, Roboto"><tspan x="-14.168" y="0">Project</tspan><tspan x="-24.585" y="13">Mobilization</tspan></text>
            <text onclick="window.location.href='#/DeliverWorkProjectRiskManagement'" style="cursor:pointer" transform="translate(942.229 650)" fill="#fff" font-size="9" font-family="Roboto-Regular, Roboto"><tspan x="-23.746" y="0">Project Risk</tspan><tspan x="-26.497" y="14">Management</tspan></text>
            <text onclick="window.location.href='#/DeliverWorkProjectInfoManagement'"  style="cursor:pointer" transform="translate(1005 680.102)" fill="#fff" font-size="9" font-family="Roboto-Regular, Roboto"><tspan x="-14.168" y="0">Project</tspan><tspan x="-23.361" y="14">Information</tspan><tspan x="-26.497" y="28">Management</tspan></text>
            <text onclick="window.location.href='#/DeliverWorkClientSatisfaction'" style="cursor:pointer" transform="translate(1023 752.369)" fill="#fff" font-size="9" font-family="Roboto-Regular, Roboto"><tspan x="-11.45" y="0">Client</tspan><tspan x="-23.977" y="14">Satisfaction</tspan></text>
            <text onclick="window.location.href='#/DeliverWorkTechnicalAssurance'"  style="cursor:pointer" transform="translate(996.646 829.787)" fill="#fff" font-size="9" font-family="Roboto-Regular, Roboto"><tspan x="-19.156" y="0">Technical</tspan><tspan x="-21.162" y="14">Assurance</tspan></text>
            <text onclick="window.location.href='#/DeliverWorkProjectPerformance'" style="cursor:pointer" transform="translate(939.205 861)" fill="#fff" font-size="9" font-family="Roboto-Regular, Roboto"><tspan x="-14.168" y="0">Project</tspan><tspan x="-26.016" y="14">Performance</tspan></text>
            <text onclick="window.location.href='#/DeliverWorkProjectChangeControl'" style="cursor:pointer" transform="translate(876.697 861)" fill="#fff" font-size="9" font-family="Roboto-Regular, Roboto"><tspan x="-14.168" y="0">Project</tspan><tspan x="-15.247" y="14">Change</tspan><tspan x="-14.585" y="28">Control</tspan></text>
            <text onclick="window.location.href='#/DeliverWorkExternalProjectProcurementManagement'" style="cursor:pointer" transform="translate(823 818.775)" fill="#fff" font-size="9" font-family="Roboto-Regular, Roboto"><tspan x="-31.469" y="0">External Project</tspan><tspan x="-25.866" y="13">Procurement</tspan><tspan x="-26.497" y="26">Management</tspan></text></g></svg>
                </span></div>
            <div class="pr-clos" onclick="window.location.href='#/DeliverWorkProjectClosure'" style="cursor:pointer;">Project Closure</div>

        </div>
        <div class="content-wt">
            <div class="tp-lft-align">
            <div class="en-suc-box-md"><span><a href="#/ExploreTheMarket">Enable our success</a></span></div>

            <div class="accordion-container">
                <div class="acc-cont-hd">
                    <a>Business Execution
                        <i class="fas fa-angle-down"></i>
                    </a>
                    <div class="acc-content">
                        <ul>
                            <li onclick="window.location.href='#/EnableBusinessPerformanceManagement'" style="cursor:pointer;">Business Performance <span class="alg-txt">Management</span></li>
                            <li onclick="window.location.href='#/EnableExternalCompliance'" style="cursor:pointer;">External Compliance</li>
                            <li onclick="window.location.href='#/EnableOptimisedWorkforce'" style="cursor:pointer;">Optimized Workforce</li>
                            <li onclick="window.location.href='#/EnableEnterpriseRiskManagement'" style="cursor:pointer;">Enterprise Risk <span class="alg-txt">Management</span></li>
                        </ul>
                    </div>
                </div>
                <div class="acc-cont-hd">
                    <a>People Performance
                        <i class="fas fa-angle-down"></i>
                    </a>
                    <div class="acc-content">
                        <ul>
                            <li onclick="window.location.href='#/EnableAttractHire'" style="cursor:pointer;">Attract & Hire</li>
                            <li onclick="window.location.href='#/EnableHighPerformingCulture'" style="cursor:pointer;">High Performing Culture</li>
                            <li onclick="window.location.href='#/EnableCareerDevelopment'" style="cursor:pointer;">Career Development</li>
                        </ul>
                    </div>
                </div>
                <div class="acc-cont-hd">
                    <a>Infrastructure
                        <i class="fas fa-angle-down"></i>
                    </a>
                    <div class="acc-content">
                        <ul>
                            <!-- <li>Facilities</li> -->
                            <li onclick="window.location.href='#/EnableIT'" style="cursor:pointer;">IT</li>
                            <!-- <li>Equipment</li> -->
                            <li onclick="window.location.href='#/EnableCorporateProcurement'" style="cursor:pointer;">Corporate Procurement</li>
                            <li onclick="window.location.href='#/EnableSecurity'" style="cursor:pointer;">Security</li>
                            <!-- <li>Communication</li> -->
                            <li onclick="window.location.href='#/EnableIntegratedManagementSystem'" style="cursor:pointer;">Integrated Management <span class="alg-txt">System</span></li>
                        </ul>
                    </div>
                </div>
                <div class="acc-cont-hd">
                    <a>Social Responsibility
                        <i class="fas fa-angle-down"></i>
                    </a>
                    <div class="acc-content">
                        <ul>
                            <!-- <li>Employee Experience</li> -->
                            <li onclick="window.location.href='#/EnableEdAndI'" style="cursor:pointer;">Equality, Diversity & <span class="alg-txt">Inclusion</span></li>
                            <li onclick="window.location.href='#/EnableSafeHealthyWorkEnvironment'" style="cursor:pointer;">Safe and Healthy <span class="alg-txt">Work Environment</span></li>
                            <!-- <li>Environment & <span class="alg-txt">Sustainability</span></li> -->
                            <li onclick="window.location.href='#/EnableIntegrity'" style="cursor:pointer;">Integrity</li>
                        </ul>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
    <!-- Main content Container section end here -->
</div>
</template>

<script>
import api from "@/service";
import router from "@/router";
import {
    mapGetters
} from "vuex";
import FunctionalComponent from "../components/FunctionalComponent.vue";
import $ from "jquery";
export default {
    name: "HeaderComp",
    components: {
        FunctionalComponent
    },
    data() {
        return {
            // banner: Banner,
            // searchText: "",
            // search: false,
            // sr: "",
            // searchResults: [],
        };
    },
    mounted() {
 $(".acc-cont-hd > a").on("click", function() {
    if ($(this).hasClass("active")) {
      $(this).removeClass("active");
      $(this)
        .siblings(".acc-content")
        .slideUp(200);
      $(".acc-cont-hd > a i")
        .removeClass("fa-angle-up")
        .addClass("fa-angle-down");
    } else {
      $(".acc-cont-hd > a i")
        .removeClass("fa-angle-up")
        .addClass("fa-angle-down");
      $(this)
        .find("i")
        .removeClass("fa-angle-down")
        .addClass("fa-angle-up");
      $(".acc-cont-hd > a").removeClass("active");
      $(this).addClass("active");
      $(".acc-content").slideUp(200);
      $(this)
        .siblings(".acc-content")
        .slideDown(200);
    }
  });
    
    },
    computed: {
    //  ...mapGetters(["showpopup"]),

        // ...mapGetters(["subStages", "stages", "header"]),
        // completeStagesInfo() {
        //     let array = [];
        //     this.subStages.forEach((subStage) => {
        //         let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
        //         subStage.Stage = stage;
        //         array.push(subStage);
        //     });
        //     return array;
        // },
        // searchRes() {
        //     if (this.sr) {
        //         return this.completeStagesInfo.filter((post) => {
        //             if (post.Title) {
        //                 return post.Title.toLowerCase().includes(this.sr.toLowerCase());
        //             }
        //         });
        //     }
        // },
    },
    methods: {
       
        // redirectTo() {
        //     this.sr = "";
        //     this.$router.push("/").catch((err) => {});
        // },
        // pushTo(slug) {
        //     this.sr = "";
        //     if (this.$route.params.slug !== slug) {
        //         // this.$router.go({ path: `/detail/${slug}` })
        //         this.$router.push({
        //             name: "Detail",
        //             params: {
        //                 slug: slug
        //             }
        //         });
        //     }
        //     this.$emit("searching", {
        //         active: false
        //     });
        // },
    },
    watch: {
        // $route(to, from) {
            // Reset Search If route changes
            // this.search = false;
            // this.searchText = '';
            // this.searchResults = [];
        // },
    },
};
</script>
