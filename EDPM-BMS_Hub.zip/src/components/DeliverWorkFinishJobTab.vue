<template>
    <div> 


<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkAllSteps';">All</button>
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkStartJobTab';">Start the Job Right </button>
    <button class="tab-link" onclick="window.location.href='#/DeliverWorkDoJobTab';">Do the Job Right </button>
    <button class="tab-link active" onclick="window.location.href='#/DeliverWorkFinishJobTab';">Finish the Job Right  </button>
</div>
  
 <div class="cont-row-wrapper mt">
    <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProposalHandover';"><div class="outline-cont-dl"><p>Proposal Handover</p></div></div>
   <div class="scroll-area-sgl">
   <ul class="list-box-dl">
      
      </ul>
    </div>
    </div>
    
<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectPlanning';"><div class="outline-cont-dl"><p>Project Planning</p></div>
 </div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     
     <li><div class="forth-child-dl">Measure client satisfaction post delivery </div></li>
     <li><div class="forth-child-dl">Conduct end of project review in line with the project risk categorisation</div></li>
    </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectFinancialManagement';"><div class="outline-cont-dl"><p>Project Financial Management</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
    
     <li><div class="forth-child-dl">Close Project Finances</div></li>
     <li><div class="forth-child-dl">Archive project information in line with contractual obligations</div></li>
  </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverworkProjectMobilisation';"><div class="outline-cont-dl"><p>Project Mobilization</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
    
    </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectRiskManagement';"><div class="outline-cont-dl"><p>Project Risk Management </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     
     <li><div class="forth-child-dl">Confirm with client the contractual obligations are complete</div></li>
     <li><div class="forth-child-dl"> Document residual risks and ongoing liabilities</div></li>
     <li><div class="forth-child-dl">Archive risk register in line with contractual obligations</div></li>
 </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectInfoManagement';"><div class="outline-cont-dl"><p>Project Info Management</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
    
     <li><div class="forth-child-dl">Review and document information management learning from the project</div></li>
     <li><div class="forth-child-dl"> Archive project information in line with contractual obligations</div></li>
 </ul>
</div>
</div>
<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkClientSatisfaction';"><div class="outline-cont-dl"><p>Client Satisfaction </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     
     <li><div class="forth-child-dl">Measure and document client satisfaction post deliverables</div></li>
     <li><div class="forth-child-dl">Archive client satisfaction information in line with contractual obligations </div></li>
 </ul>
</div>
</div>
<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkTechnicalAssurance';"><div class="outline-cont-dl"><p>Technical Assurance</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
    
     <li><div class="forth-child-dl">Confirm with the client all deliverables are complete </div></li>
     <li><div class="forth-child-dl">Confirm with client contractual obligations are complete</div></li>
     <li><div class="forth-child-dl">Collate and share technical learning from the project </div></li>
     <li><div class="forth-child-dl">Archive project information in line with contractual obligations</div></li>
</ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectPerformance';"><div class="outline-cont-dl"><p>Project Performance </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
    
     <li><div class="forth-child-dl">Measure client satisfaction post delivery in line with Stakeholder Management Plan</div></li>
     <li><div class="forth-child-dl">Conduct End of Project Review</div></li>
</ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectChangeControl';"><div class="outline-cont-dl"><p>Project Change Control</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     
     <li><div class="forth-child-dl">Confirm with client contractual obligations are complete </div></li>
     <li><div class="forth-child-dl">Collate and share learning from the project </div></li>
     <li><div class="forth-child-dl">Close project finances </div></li>
     <li><div class="forth-child-dl">Archive project change information in line with contractual obligations</div></li>
  </ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkExternalProjectProcurementManagement';"><div class="outline-cont-dl"><p>External Project Procurement Management </p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     
     <li><div class="forth-child-dl">Confirm services / goods delivered by supplier</div></li>
     <li><div class="forth-child-dl">Evaluate and document supplier performance as part of Project closure</div></li>
     <li><div class="forth-child-dl">Conduct end of project review in line with Project Management Plan</div></li>
</ul>
</div>
</div>

<div class="cont-row-wrapper">
  <div class="outline-box-dl" onclick="window.location.href='#/DeliverWorkProjectClosure';"><div class="outline-cont-dl"><p>Project Closure</p></div></div>
  <div class="scroll-area-sgl">
  <ul class="list-box-dl">
     <li><div class="forth-child-dl">Confirm with client the contractual obligations are complete</div></li>
     <li><div class="forth-child-dl">Measure client satisfaction post deliverables</div></li>
     <li><div class="forth-child-dl">Document residual risks and ongoing liabilities</div></li>
     <li><div class="forth-child-dl">Close project finances</div></li>
     <li><div class="forth-child-dl">Conduct end of project review in line with the project risk categorisation</div></li>
     <li><div class="forth-child-dl">Document learning from the project</div></li>
     <li><div class="forth-child-dl">Archive project information in line with contractual obligations</div></li>
</ul>
</div>
</div>
</div>
</div>
<!-- Main content Container section end here -->




</div>

  
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "DeliverWorkFinishJobTabcomp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
