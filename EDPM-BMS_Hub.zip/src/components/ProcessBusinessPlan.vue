<template>
    <div>
 

<!-- Main content Container section start from here -->
<div class="cont-container">
    <div class="content-wt">
    <div class="content-hd-text">
     <h2>Business Plan</h2>
      <p>The annual business plan is about setting milestones and objectives which creates a clear roadmap to achieve the sector plan. It is a stepping stone to achieve the longer term sector goals. It highlights priorities and goals focused on taking the business in the right direction, giving a tangible way of reviewing the businesses progress and supporting critical decision making , ironing out issues and avoiding unnecessary mistakes.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active" onclick="window.location.href='#/ProcessBusinessPlan';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/LeadProcessBusinessPlanDetailedView';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <div class="row-box">
        <div class="box" v-on:click="show('The Annual Business Plan shall outline the key actions and assumptions for the next financial year, aligned to the regional 5 year plan. It should be a top down view of  focusing on business objectives including clients and employee needs and expectations and Quality, Health, Safety and Environmental objectives. The plan shall be reviewed quarterly to monitor performance, identify improvements and corrections, to ensure delivery to the plan.')">
          <div class="content bg-lead"><p class="para-cont">Documented Annual Business Plan completed that defines the priorities for the year ahead</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('All regions shall prepare an annual financial plan (The Budget) which shall be part of the Annual Business Plan.The timetable and instructions for the budget process shall be issued by the Regional Finance Director. The Budget shall be  approved by the Sector President in advance of the commencement of each financial year. Budgets should be prepared for all profit and cost centres within the region.')">
          <div class="content bg-lead"><p class="para-cont">Develop the annual financial plan "The Budget"  </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('A workforce management plan shall form part of the Annual Business Plan to identify human resources needs, capacity, capability, and training and development required to deliver to the business plan. This shall include the plan to deliver a more diverse and inclusive workforce, as well as factors to deliver an improved employee experience.')">
          <div class="content bg-lead"><p class="para-cont">Identify Human Resources needed to deliver to plan   </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('The annual business plan shall be approved by the Sector President and shared with employees in the region to enable them to understand the key objectives for the year and how they contribute to the success of the region.')">
          <div class="content bg-lead"><p class="para-cont">Share the annual business plan with key stakeholders </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt" v-on:click="show('The annual business plan shall include measures to enable monitoring of performance against the plan during the year.  These measures shall be reviewed at least quarterly by the CEO and on request by the Sector President.')">
          <div class="content bg-lead"><p class="para-cont">Monitor the effectiveness of the annual business plan</p></div>
          </div>
      </div> 

       <div class="row-reverse-last-child">
  <div class="box"  v-on:click="show('A formal process shall be established to capture risks and issues across the Sector.  These risks should be both strategic (such as change in macro economy, Government policy etc), and operational (such as workload, project performance, client). The Regions shall ensure that their reported risks are an accurate reflection of the risks they hold and that they are reviewed, updated and validated quarterly.')">
    <div class="content bg-lead"><p class="para-cont">Document risks from the annual plan on the Enterprise risk register. </p></div>
  </div>
  </div>  
</div>
</div>

    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span></div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>

  </div>
  </div>
  </div>
<!-- Main content Container section end here -->



    </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions} from "vuex";
export default {
  name: "ProcessPlanComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
   methods: {
           ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
   },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
