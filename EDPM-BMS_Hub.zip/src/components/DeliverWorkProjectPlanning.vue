<template>
  <div>
    <!-- Main content Container section start from here -->
    <div class="cont-container">
      <div class="content-wt">
        <div class="content-hd-text">
          <h2>Project Planning</h2>
          <p>
            Without careful planning project performance is almost certainly
            guaranteed to fail. Good project planning reduces the pressure on a
            project, inspires confidence and drives communication. It rallies a
            team around a single project vision. Priorities are clear,
            expectations are aligned, and everyone knows exactly what needs to
            happen to deliver on time, to scope, cost and quality. Project
            planning needs to be proportionate and appropriate to the risk and
            complexity of the project throughout the lifecycle of the project.
          </p>
        </div>
        <div class="tabs">
          <button
            class="tab-link active"
            onclick="window.location.href='xxxxx.html';"
          >
            Requirements
          </button>
          <button
            class="tab-link"
            onclick="window.location.href='#/DeliverWorkProjectPlanningNew';"
          >
            Additional Detail
          </button>
           <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
        </div>
        <div class="row-content">
          <div class="col-9">
            <div class="card-wrap">
              <div class="row-box">
                <div class="box" v-on:click="show('The competence level of the PM and PD shall be commensurate with the risk, scale and complexity of the project. Mitigation measures shall be documented and implemented where competency of the PD and/or PM is not at the required level. This should be discussed as part of the gated process. For medium (Amber) and high (Red) risk projects the PM and PD shall have completed the formal PM competency assessment procedure relevant to their business unit. ')">
                  <div class="content bg-fst-chld">
                    <p class="para-cont">
                      Identify appropriately assessed and competent PD and PM
                      when procurement document received
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Where PM and PD is different to the proposal leads they shall be engaged and involved in the development of the proposed baselines to aid the seamless transition from proposal to delivery and to ensure validity and optimality of the technical proposal and pricing strategy. Before commitments are made to a client or internally to the business, a project baseline shall be established. The timing of availability of the baseline elements may vary depending on project circumstances. The level of detail required for the project baseline will also vary based on project size, scale and complexity.')">
                  <div class="content bg-fst-chld">
                    <p class="para-cont">
                      Involve PD and PM in establishing proposed
                      baselines/deliverables
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Where the PM is different to the proposal lead the PM shall ensure a handover is conducted so they have a complete set of proposal related materials including contract, issued proposal, bid risk register, commercial data and other pertinent information. They shall gain assurance that correct Stage Gate and LOA approvals are in place prior to commencing delivery. The method of handover shall be dependent on the size, scale and complexity of the project. For large, complex projects the handover shall also involve Technical Leads. All projects >£10m (or equivalent value) shall follow the MPU requirements. ')">
                  <div class="content bg-fst-chld">
                    <p class="para-cont">
                      Conduct formal handover between Proposal Manager, PD and
                      PM
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The PM shall review the contract to understand the contractual obligations and identify the associated plans needed to manage and control the project. The Project Management Plans shall also take into account any commitments made to the client as part of engagement during the proposal phase. ')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Understand client and contractual obligations
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-rt" v-on:click="show('Before undertaking substantial delivery activity, a discussion proportionate to the size, scale, and complexity of the project shall be undertaken with a suitable person in the client organization to verify the project requirements. The discussion should identify the aspirations behind contractual and commercial requirements, any areas of risk and additional stakeholders, which shall inform which project management plans are required to effectively control the project. For major projects >£10m (or equivalent value) the client engagement outcomes shall be documented and communicated to the client for their agreement. ')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">Confirm deliverables with client</p>
                  </div>
                </div>
              </div>

              <div class="row-reverse">
                <div class="box" v-on:click="show('Setting the right level of project baseline is an essential prerequisite for a successful project. The baseline is the reference levels against which a project, programme or portfolio is monitored and controlled. The MPU Baseline Process should be used on all projects proportionally. As a minimum cost, schedule, resource and deliverables baselines shall be established to enable monitoring and control of the project. For any projects over £10m (or equivakent value) the 7 MPU baseline elements shall be established. Projects shall establish appropriate project KPIs to monitor performance against approved baselines over the lifecycle of the project. ')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Establish project baseline reference levels to monitor and
                      control the project
                    </p>
                  </div>
                </div>
                <div class="box" v-on:click="show('Setting the financial system goes beyond creating a job no and must consider how the project will achieve the baseline reference levels including phasing of the project. The financial system needs to consider the schedule of delivery, the work breakdown structure, resource management plan, the delivery strategy to enable a clear budget and programme to monitor progress.')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Set up relevent financial management system for the
                      project
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The Project Management Plan (PMP) brings together all the plans for a project. The purpose of the PMP is to document the outcomes of the planning process and to provide the reference documents for managing the project. The PMP provides a single reference for the project in one place so that people joining the project can easily find out what the project is about, the reasons for the project, the business justification, major risks, how it is being managed and controlled The scale of the PMP shall be proportional to the risk, scale and complexity of the project. For large, complex projects the PMP may be the plan of plans with a number of sub plans e.g. Project Execution Plan, Quality Plan, HSE Plan.. For smaller projects the PMP may be a single document. All projects >£10m (or equivalent vaue) shall follow the requirements of the MPU. ')">
                  <div class="content bg-snd-chld">
                    <p class="para-cont">
                      Document required Project Management Plans aligned to
                      project risk categorisation
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('Mobilizing the project shall be planned and delivered in a timely manner, to clearly communicate the requirements laid out in the PMP. It is important project team members, including team members from other divisions or business units and external third party suppliers understand the project requirements. The mobilisation shall be proportionate to the size, scale and complexity of the project. An effective mobilisation of the project team shall be evidenced by team members having read and understood the PMP. ')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Formally mobilize the project, appropriate to the project
                      risk, scale & complexity
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box arrow-lt" v-on:click="show('The PMP shall act as the reference point to manage the delivery of the project and shall be a dynamic document. It is important to recognize that changes may require amendments to the PMP to reflect changes to scope, schedule, price, costs, budget and resourcing profile. Any changes must be communicated to the project delivery team including third party suppliers and internal project team members in other divisions or business units.')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Manage project delivery in line with the Project
                      Management Plan
                    </p>
                  </div>
                  <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
              </div>
              <div class="row-box">
                <div class="box" v-on:click="show('Project reviews shall be conducted in line with the Project Management Plan to monitor and measure performance against the baseline levels, over the lifecycle of the project. Performance against appropriate project KPIs shall be reported as defined in the PMP. The requirements of the review will be proportionate to the size, scale and complexity of the project.  For small, low risk projects this may be combined with the the PD monthly project review. For larger, complex projects this should be reviewed by the formal established Board overseeing the project. For Major Projects >£10m (or equivalent value) the MPU requirements shall be followed. Learning from project reviews shall be captured and shared with the project team. ')">
                  <div class="content bg-th-chld">
                    <p class="para-cont">
                      Review, measure and monitor project performance against
                      the Project Management Plan
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('It is important to understand the impact and effectiveness of the Project Management Plan and how it has driven performance in the project. Once the project is substantially closed client feedback shall be sought to identify learning for this project and future projects. It should be carried out immediately prior to demobilization of project resources to capture the wider project team perspective.')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Measure client satisfaction post delivery
                    </p>
                  </div>
                  <div class="arrow-img">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                </div>
                <div class="box" v-on:click="show('The purpose of the end of project review is to ensure that project delivery is complete and we capture feedback on project performance. It is important to verify we have been paid and all contractual obligations are complete. The performance of third party suppliers shall be  evaluated and recorded and technical and financial performance is reviewed. Learning during the lifecycle of the project shall be captured and shared to inform future projects.')">
                  <div class="content bg-frth-chld">
                    <p class="para-cont">
                      Conduct end of project review in line with the project
                      risk categorization
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
   <!-- <RightInformationPannel/> -->

          <div class="col-3">
            <div class="content-box">
              <div class="own-detail">
                <span
                  >Process Owner:
                  <strong class="bld-txt">Nick Welch</strong></span
                >
                <!-- <span
                  >Key Contact:
                  <strong class="bld-txt">Joann Clarke</strong></span
                > -->
              </div>
              <div class="ult-links">
                <h4>Useful links</h4>
                <a href="https://atkins.sharepoint.com/sites/dwh/html/index.aspx?OR=Teams-HL&CT=1649844968359&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjA0MDExMTQwMCJ9#/" target="_blank">Deliver Work Hub</a>
                <a href="https://atkins.sharepoint.com/sites/ESMS/SitePages/Glossary.aspx?OR=Teams-HL&CT=1649852129464&params=eyJBcHBOYW1lIjoiVGVhbXMtRGVza3RvcCIsIkFwcFZlcnNpb24iOiIyNy8yMjAzMjEwMDEwNyJ9" target="_blank">Glossary</a>
                 <a href="https://atkins.sharepoint.com/sites/CommercialHub/html/index.aspx#/" target="_blank">Commercial Hub</a>
                  <a href="https://atkins.sharepoint.com/sites/pmcommunity/SitePages/PM%20Competency.aspx" target="_blank">PM Competency Framework</a>
                   <a href="https://atkins.sharepoint.com/sites/digitalservices/productportal/ClientPerception/Pages/default.aspx" target="_blank">Client Perception & Project </a>
                    <a href="https://atkins.sharepoint.com/sites/digitalservices/productportal/ClientPerception/Pages/default.aspx" target="_blank">Feedback </a>
              </div>
              <!-- <div class="ult-links">
                <h4>Training</h4>
                <a>xxxxxxx</a>
              </div> -->
              <div class="ult-links">
                <h4>Approved Deviations</h4>
                <a>None</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapActions } from "vuex";
// import RightInformationPannel from "../components/RightInformationPannel.vue";
export default {
  name: "DeliverWorkProjectPlanningComp",
  // components: {RightInformationPannel}

  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  methods: {
    ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>