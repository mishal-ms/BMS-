<template>
    <div>


<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Proposal Management</h2>
      <p><strong class="bld-txt">Proposal management</strong> Involves implementing and scaling a common SNCL-wide capture and proposal process for major opportunities, based on 3-phase approach: capture phase; proposal preparation; post-submission. This process is enabled by a set of tools, capabilities and behaviours including: a greater emphasis on leveraging our Global Networks to address resource issues and identify opportunities for horizontal collaboration; using Digital Marketing techniques to generate data-driven insights that strengthen sales enablement; maintaining a competitive intelligence knowledge bank and supporting with the development of work winning talent.</p>
  </div>
  <div class="tabs">
    <button class="tab-link active">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/ProposalManagementDetailedView';"> Additional Detail</button>
   <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">
      <h2 class="heading-txt pb">Commercial Proposal</h2>
<div class="row-box">
  <div class="box">
    <div class="content bg-prop cursor-none"><p class="para-cont">Analyse how pricing can be structured to maximise scoring </p></div>
    <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
  </div>
  <div class="box">
    <div class="content bg-prop cursor-none"><p class="para-cont">Develop the price to win strategy </p></div>
    <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
  </div>
  <div class="box">
    <div class="content bg-prop cursor-none"><p class="para-cont">Identify commercial risks and add to risk register </p></div>
        <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
</div>
   <div class="box">
    <div class="content bg-prop cursor-none"><p class="para-cont">Define supply chain strategy</p></div>
        <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>

  </div>
  <div class="box arrow-rt">
    <div class="content bg-prop cursor-none"><p class="para-cont">Identify resource requirements and cost</p></div>
  </div>
  </div>

<div class="row-reverse-last-child">
<div class="box">
    <div class="content bg-prop cursor-none"><p class="para-cont">Develop pricing proposal</p></div>
  </div>
  </div>
<h2 class="heading-txt-nxt pt-0">Qualifying Proposal</h2>

      <div class="row-box">
        <div class="box" v-on:click="show('Formal documents received via formal channel')">
          <div class="content bg-prop"><p class="para-cont">Procurement document received </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show(' Bid teams should review the procurement documentation collectively as soon as possible, noting the key points and potential issues to query.')">
          <div class="content bg-prop"><p class="para-cont">Review procurement documentation </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Decision to confirm continued pursuit and investment  </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Bid Director / Pursuit Lead formally appointed to Pursuit')">
          <div class="content bg-prop"><p class="para-cont">Agree pursuit Manager/Director </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt" v-on:click="show('Should produce an itemized costing of internal and external costs related to bid activity')">
          <div class="content bg-prop"><p class="para-cont">Agree pursuit budget </p></div>
          </div>
        
      </div>

       <div class="row-reverse">
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Identify 
            additional risks
            and update
            register  </p></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Conduct Go/No
            Go to confirm
            investment</p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Bid teams should agree Pursuit team structure and provide list of Pursuit team members and brief profiles as part of Pursuit kick-off materials')">
          <div class="content bg-prop "><p class="para-cont">Confirm the Pursuit team, including the delivery project director and project manager</p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('The core Pursuits team should produce a Proposal Management Plan. It shall document tasks, schedules, delivery milestones, roles and responsibilities. The plan should be used to keep the Pursuit on track and accountable.  ')">
          <div class="content bg-prop"><p class="para-cont">Develop the
            Proposal
            Management
            Plan  </p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-lt" v-on:click="show('The completed Capture Plan should be shared / presented by core Pursuits team with relevant Pursuit stakeholders ')">
          <div class="content bg-prop "><p class="para-cont">Share capture
            planning
            information via a
            kick off meeting
            with pursuit team  </p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        
      </div>
      <div class="row-box">
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Submit clarifying
            questions to
             client and
            monitor
            responses </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Review procuarement documentation </p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Define key messages and differentiators for win strategy</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Complete pursuit responses</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box arrow-rt">
          <div class="content bg-prop cursor-none"><p class="para-cont">Conduct full pursuit response review </p></div>
          </div>
      </div>

      <div class="row-reverse-last-child">
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Submit response to client</p></div>
        </div>
        <div class="box">
          <div class="content bg-prop cursor-none"><p class="para-cont">Update sales database</p></div>
          <div class="arrow-img-rev"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        </div>
</div>


    </div>
<div class="col-3">
    <div class="content-box mt-custom">
        <div class="own-detail">
            <span>Process Owner:
                <strong class="bld-txt">Martina Perrin</strong></span>
            <!-- <span>Key Contact:
                <strong class="bld-txt">Joann Clarke</strong></span> -->
        </div>
        <div class="ult-links">
            <h4>Useful links</h4>
            <a href="http://communities.eu.atkinsglobal.com/sites/winworkhub/Pages/home.aspx" target="_blank">Win Work Hub</a>
            <!-- <a>Community</a> -->
            <a href=" http://visionapp.na.atkinsglobal.com/VisionClient/" target="_blank">Vision Sales Database for US</a>
            <a href="https://sncl-d365.crm11.dynamics.com/apps/snclsales" target="_blank">SNCL Sales Enterprise Users</a>
            <a href="https://sncl-d365.crm11.dynamics.com/apps/snclstm" target="_blank">Sales Team Member</a>
            <a href="https://atkins.sharepoint.com/sites/GWWPDP/SitePages/Home.aspx" target="_blank">Engineering Services Capture & Pursuit Toolkit </a>
            <a href="https://atkins.sharepoint.com/sites/digitalservices/productportal/ClientPerception/Pages/default.aspx" target="_blank">Client Perception & Project Feedback </a>
            <a href="https://atkins.sharepoint.com/sites/GDFLibrary/html/BIM/index.aspx#/" target="_blank">Global Design Framework </a>

           




        </div>
        <!-- <div class="ult-links">
                <h4>Training</h4>
                <a>None</a>
              </div> -->
        <div class="ult-links">
            <h4>Approved Deviations</h4>
            <a>None</a>
        </div>
    </div>
</div>
    <!-- <RightInformationPannel/> -->

    </div>
</div>
</div>
<!-- Main content Container section end here -->



    </div>
</template>



<script>
import api from "@/service";
import router from "@/router";
import { mapActions } from "vuex";
import RightInformationPannel from "../components/RightInformationPannel.vue"
export default {
  name: "ProposalManagementComp",
  components: {RightInformationPannel},
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  methods: {
      ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>