<template>
    <div>
      

<!-- Main content Container section start from here -->
<div class="cont-container">
      <div class="content-wt">
    <div class="content-hd-text">
      <h2>Performance</h2>
      <p>Monitoring business performance is key to improving business processes which underpin and enable delivery to our clients needs and expectations. Measuring performance is a vital part of monitoring delivery to our strategy and plans and gives the organization a sense of how we are performing. It enables the business to identify issues quickly and to make decisions to change direction based on evidence and facts.</p>
  </div>
  <div class="tabs">
        <button class="tab-link active" onclick="window.location.href='#/ProcessPlanMonitor';">Requirements</button>
    <button class="tab-link" onclick="window.location.href='#/LeadProcessPerformanceDetailedView';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>
  <div class="row-content">
    <div class="col-9">
    <div class="card-wrap">

      <div class="row-box">
        <div class="box" v-on:click="show('Leadership should establish the mechanism to measure and monitor delivery to documented plans and controls. Mechanisms shall be communicated on how business performance shall be reported at both sector and regional level.')">
          <div class="content bg-lead"><p class="para-cont">Establish mechanisms to monitor business performance</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Each region shall determine what needs to be measured, aligned to their business plan. Methods shall be determined to ensure  reliable and valid results.')">
          <div class="content bg-lead"><p class="para-cont">Collect, analyze and report against established KPIs</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('Quarterly Business Review (QBR) reports shall be documented and shared with top leadership. A formal review meeting shall be held to review performance, against established KPIs and the effectiveness of the business plan. Evidence of QBR reviews shall be documented.')">
          <div class="content bg-lead"><p class="para-cont">Formal Quarterly review of performance to business plan</p></div>
          <div class="arrow-img"><img src="../assets/images/arrow-main.png"/></div>
        </div>
        <div class="box" v-on:click="show('The Business Plan should be reviewed at planned intervals and where necessary updated to reflect agreed actions from the QBR. The review shall include consideration of any changes or updates to existing risks and the identification of new risks. Any changes to the business plan shall be communicated to relevant stakeholders.')">
          <div class="content bg-lead"><p class="para-cont">Update Business plan to reflect deviations from the plan</p></div>
        </div>
      </div>        
</div>
</div>

    <div class="col-3">
    <div class="content-box">
      <div class="own-detail"><span>Process Owner: <strong class="bld-txt">Simon Cole</strong></span></div>
      <div class="ult-links"><h4>Approved Deviations</h4> <a>None</a></div>
    </div>
    </div>
  </div>
  </div>
  </div>
<!-- Main content Container section end here -->



    </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters, mapActions } from "vuex";
export default {
  name: "ProcessPlanMonitor",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
   methods: {
           ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
   },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>
