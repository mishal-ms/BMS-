<template>
<div>

    <!-- Main content Container section start from here -->
    <div class="cont-container">
        <div class="content-wt">
            <div class="content-hd-text">
                <h2>Strategic positioning</h2>
                <p><strong class="bld-txt">Strategic positioning</strong> is one of the most powerful marketing activities. It enables us to influence how we are perceived by our clients and provides an opportunity for us to
                    build our reputation whilst differentiating ourselves from our competitors. Through <strong class="bld-txt">strategic positioning</strong> we increase our win work success, and it helps us achieve a
                    sustainable competitive advantage. It also empowers us to build lasting differentiation by creating new forms of client value.</p>
            </div>
            <div class="tabs">
                <button class="tab-link active" >Requirements</button>
                <button class="tab-link" onclick="window.location.href='#/StragicPositioningDetailedView';"> Additional Detail</button>
                <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
            </div>

            <div class="row-content">
                <div class="col-9">
                    <div class="card-wrap">
                        <div class="row-box">
                            <div class="box" v-on:click="show('The SNC-Lavalin Corporate Strategy shall be produced centrally by SNC-Lavalin Corporate Strategy Team in conjunction with SNC-Lavalin Executive Committee (ExCom). This shall represent the Corporate Strategy Plan and Vision for SNC-Lavalin, including 5-year Budget Plan. The SNC-Lavalin Corporate Strategy shall be communicated internally via internal communications channels, and externally via external communications channels including investor presentations. ')">
                                <div class="content">
                                    <p class="para-cont">Corporate Strategy communicated</p>
                                </div>
                                <div class="arrow-img"><img src="../assets/images/arrow-main.png" /></div>
                            </div>
                            <div class="box" v-on:click="show('The Global Growth Markets shall be agreed at Global Growth level. Global Market Network Leads shall appointed with responsibility for driving engagement and connectivity across the wider SNC-Lavalin Group. ')">
                                <div class="content">
                                    <p class="para-cont">Strategic Markets identified globally </p>
                                </div>
                                <div class="arrow-img"><img src="../assets/images/arrow-main.png" /></div>
                            </div>
                            <div class="box" v-on:click="show('Overall approach and strategy structure designed by SNC-Lavalin Corporate Strategy Team and agreed with Market Networkd Leads. Global Market Strategies should be developed by Market Network Leads with coordinated inputs from nominated Regional Market Leads.' )">
                                <div class="content">
                                    <p class="para-cont">Global Market Strategies defined and shared with relevant market networks</p>
                                </div>
                                <div class="arrow-img"><img src="../assets/images/arrow-main.png" /></div>
                            </div>
                            <div class="box" v-on:click="show('Regional Market Plans authors should access Win Work guidance when designing and developing structure of Regional Market Plans. Regional Markets Plans should be connected via Golden Thread to Global Market Strategies; to ensure alignment on overall strategic focus and particular consistency around marco drivers, growth themes and strategic priorities. ')">
                                <div class="content">
                                    <p class="para-cont">Regional Market priorities defined and documented in line Strategy</p>
                                </div>
                                <div class="arrow-img"><img src="../assets/images/arrow-main.png" /></div>
                            </div>
                            <div class="box arrow-rt" v-on:click="show('Formal KPIs and Metrics shall be agreed to measure performance against Strategy and Plan. Sector, Business Unit and Global Market Win Work metrics shall be measured on a quarterly basis, with Global Growth Team responsibility for coordination and consolidation. Sectors, Business Units and Global Markets should have robust mechanisms in place to enable the tracking of key metrics data. ')">
                                <div class="content">
                                    <p class="para-cont">Formal measures identified to enable monitoring of delivery to strategy and priorities </p>
                                </div>
                            </div>
                        </div>

                        <div class="row-reverse-last-child">
                            <div class="box" v-on:click='show("Factored and Unfactored Pipeline data by Sector, Business Unit and Global Market shall be identified and prioritized in-line with Regional Market Plans, including by prioritizing \"Must-Wins\".")'>
                                <div class="content">
                                    <p class="para-cont">Identify regional market priorities aligned to regional plan </p>
                                </div>
                            </div>
                            <div class="box" v-on:click='show("Utilise tools and process for undertaking early stage, pre-positioning Capture Planning on prioritized \"must-wins\" with adequate \"lead-in\" time.")'>
                                <div class="content">
                                    <p class="para-cont">Strategically position opportunities for specific clients/ individual pursuits </p>
                                </div>
                                 <div class="arrow-img-rev">
                    <img src="../assets/images/arrow-main.png" />
                  </div>
                            </div>
                        </div>


                    </div>
                </div>

                <RightInformationPannel />

            </div>
        </div>
    </div>
    <!-- Main content Container section end here -->

</div>
</template>

<script>
import api from "@/service";
import router from "@/router";
import {
    mapGetters,
    mapActions
} from "vuex";
import RightInformationPannel from "../components/RightInformationPannel.vue";
export default {
    name: "StragicPositioningComp",
    components: {
        RightInformationPannel
    },
    // data() {
    //       return {
        //     banner: Banner,
        //     searchText: "",
        //     search: false,
        //     sr: "",
        //     searchResults: [],
    //       };
    // },
    computed: {
        // ...mapGetters(["showpopup"]),
        //   completeStagesInfo() {
        //     let array = [];
        //     this.subStages.forEach((subStage) => {
        //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
        //       subStage.Stage = stage;
        //       array.push(subStage);
        //     });
        //     return array;
        //   },
        //   searchRes() {
        //     if (this.sr) {
        //       return this.completeStagesInfo.filter((post) => {
        //         if (post.Title) {
        //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
        //         }
        //       });
        //     }
        //   },
    },
    methods: {
        ...mapActions(["UPDATE_POPUP_CONTENT","UPDATE_SHOW_POPUP"]),
        show(val) {
            this.UPDATE_POPUP_CONTENT(val);
            this.UPDATE_SHOW_POPUP(true);

        },
        
        //   redirectTo() {
        //     this.sr = "";
        //     this.$router.push("/").catch((err) => {});
        //   },
        //   pushTo(slug) {
        //     this.sr = "";
        //     if (this.$route.params.slug !== slug) {
        //       // this.$router.go({ path: `/detail/${slug}` })
        //       this.$router.push({ name: "Detail", params: { slug: slug } });
        //     }
        //     this.$emit("searching", { active: false });
        //   },
    },
    // watch: {
    //   $route(to, from) {
    //     // Reset Search If route changes
    //     // this.search = false;
    //     // this.searchText = '';
    //     // this.searchResults = [];
    //   },
    // },
};
</script>
