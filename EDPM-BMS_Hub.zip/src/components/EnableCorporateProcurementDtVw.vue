<template>
  <div>
    <!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Corporate Procurement</h2>
      <p>The requirement for clear controls in the procurement of goods and services is to contribute in creating and maintaining effective supply chain management capabilities, processes and systems. The overarching objective is to set controls whereby SNC-Lavalin will be competitive, yet fair and ethical in our business practice. </p>
  </div>
  <div class="tabs">
     <button class="tab-link" onclick="window.location.href='#/EnableCorporateProcurement';">Requirements</button>
    <button class="tab-link active" onclick="window.location.href='#/EnableCorporateProcurementDtVw';"> Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='xxxxxxxx.html';">Related Governance</button> -->
  </div>
  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4> Document procurement requirements using the Project Initiation Charter</h4>
  <p>Prior to initiating the procurement and sourcing of indirect goods and services, the requester shall complete the Indirect Procurement Project Initiation Charter. Involve authorised Procurement Personnel at the beginning of the procurement process to ensure the process is handled in accordance with documented procedures.</p>
  <h4> Involve authorised procurement personnel  </h4>
  <p>Authorised Procurement Personnel shall be involved at the beginning of the procurement process to ensure the process is handled in accordance with documented procedures</p>
  <h4>Utilize suppliers who are appropriately approved</h4>
  <p>SNC-L Employees shall make every attempt to utilize preferred suppliers where identified.  </p>
  <h4>Competively bid where value exceeds $2,500 CAD</h4>
  <p>All indirect Goods and Services to be procured equal to or in excess of $2,500 CAD shall be competitively bid. Any exception to this standard must use the Bid Waiver Sole Source Justification form, prior to launching the RFT process</p>

  <h4> Establish Tender criteria and guidelines</h4>
  <p>Request For Tender (RFT) Criteria and Guidelines for assessment shall be established and used to evaluate suppliers. During the evaluation process suppliers shall be assessed against the RFT Criteria which shall  include:
Bid Compliance; Pricing and Scope; Technical Evaluation; Commercial Questionnaire</p>
  <h4> Approval must be received from the relevant Corporate Function</h4>
  <p>A Bid review Presentation and, or Contract Resume and Approvals report shall be developed and approved by the relevant Corporate Function Manager. All negotiations shall ensure they do not take the following prohibited actions: "tender (bid) shopping; sharing confidential information or information from other tenders; unequal sharing of information; non-disclosure of any conflicts of interest.</p>
  <h4>Final supplier selection notice must be issued and communiated by authorized procurement personnel</h4>
  <p>On completion of negotiations and mutual agreement is reached by both parties, Authorized Procurement Personnel must issue a notice communicating final Supplier selection. The final decision and all binding commitments shall be made by an authorised Procurement Personnel</p>
  <h4>In formalising an agreement all necessary internal procurement requirements must be followed </h4>
  <p>Approved Procurement Personnel shall ensure all necessary internal requirements are followed in the formalising of any agreement with a third party supplier. Prior to an award of an Agreement authorised procurement personnel shall ensure the following is completed: 360 Integrity Check Verification; Business Partner Compliance Due Diligence (CDD); data privacy requirements and verifications; cloud and Third Parties Engagement Framework requirements and verifications. If required ensure IT equipment activities are approved. </p>

  <h4>Embed requirements of Supplier code of conduct in agreement </h4>
  <p>All suppliers shall receive a copy of the Supplier Code of Conduct and the requirements of the Code shall be embeded in the agreement</p>

  <h4> Obtain appropriate signatures </h4>
  <p>The Authorized Procurement Personnel shall obtain the appropriate signatures from the designated signatories with respect to the legal entity entering into the contract</p>
  <h4> Obtain purchase order for non-IT expenditure over $2500 CAD and all IT expenditure</h4>

  <h4>Digitally file contractual documents</h4>
  <p>All fully signed contractual documents will be filed by Corporate Procurement in digital format</p>
  <h4>Performance of suppliers shall be monitored and measured</h4>
  <p>Performance of suppliers shall be monitored and measured at planned intervals to ensure delivery to contractual obligations and service level agreements.</p>

</div>
</div>
  
  </div>
</div>
    <!-- Main content Container section end here -->
  </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";

export default {
  name: "EnableCorporateProcurementDtVwComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>