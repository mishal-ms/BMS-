<template>
    <div>
    


<!-- Main content Container section start from here -->
<div class="main-cont-container">
  <div class="content-wt">
  <div class="wrapper-sec">

    <div class="prc-column1">
<FunctionalComponent/>

</div>
    <div class="led-prc-nxt">
      <ul>
      <li><a href="#/ProcessLeadership">Leadership & Commitment</a></li>
      <li><a href="#/ProcessSectorPlan">Sector Plan</a></li>
      <li><a href="#/ProcessBusinessPlan">Business Plan</a></li>
      <li><a href="#/ProcessImplement">Controls & Assurance</a></li>
      <li><a class="my-sgl-lne" href="#/ProcessPerformance">Performance</a></li>
      <li><a class="my-sgl-lne" href="#/ProcessImprovement">Improve</a></li>
      </ul>
    </div>
    <div class="exp-mark-txt">
      <ul>
      <li><a href="#/StragicPositioning">Strategic Positioning</a></li>
      <li><a href="#/ClientDevelopment">Client Development</a></li>
    </ul>
    </div>
    <div class="hdover-txt"><ul>
      <li><a href="#/OpportunityIdentification">Opportunity Identification</a></li>
      <li><a href="#/CapturePlanning">Capture Planning</a></li></ul>
    </div>
    <div class="bid-wn-steps">
      <ul>
        <li><a class="my-th-lne" href="#/ProposalManagement">Proposal - Qualifying Proposal</a></li>
        <li><a class="my-th-lne" href="#/ProposalManagement">Proposal - Commercial Proposal</a></li>
        <li><a href="#/PostSubmission">Post Submission</a></li>
      </ul>
      </div>   
      <div class="st-jb-box">
        <ul>
          <li><a href="#/DeliverWorkProposalHandover">Proposal Handover</a></li>
          <li><a href="#/DeliverWorkProjectPlanning">Project Planning</a></li>
          <li><a class="my-th-lne" href="#/DeliverWorkProjectFinancialManagement">Project Financial Management</a></li>
          <li><a href="#/DeliverWorkProjectMobilisation">Project Mobilization</a></li> 
        </ul>
      </div>
      <div class="do-jb-box">
        <ul>
          
          <li><a href="#/DeliverWorkProjectRiskManagement">Project Risk Management</a></li>
          <li><a class="my-th-lne" href="#/DeliverWorkProjectInfoManagement">Project Information Management</a></li>
          <li><a href="#/DeliverWorkClientSatisfaction">Client Satisfaction</a></li>
          <li><a href="#/DeliverWorkTechnicalAssurance">Technical Assurance</a></li>

        </ul>
      </div>
      <div class="finsh-jb-box">
        <ul>
          <li><a href="#/DeliverWorkProjectPerformance">Project Performance</a></li>
          <li><a class="my-th-lne" href="#/DeliverWorkProjectChangeControl">Project Change Control</a></li> 
          <li><a  class="my-th-lne" href="#/DeliverWorkExternalProjectProcurementManagement">External Project Procurement  </a></li>
          <li><a href="#/DeliverWorkProjectClosure">Project Closure</a></li>            
           </ul>
      </div>
     

<div class="enable-sc-box">
        <ul>
          <li><a  class="my-th-lne" href="#/EnableBusinessPerformanceManagement">Business Performance Management</a></li>
          <li><a  class="my-th-lne" href="#/EnableEnterpriseRiskManagement">Enterprise Risk Management</a></li>
          <li><a href="#/EnableCorporateProcurement">Corporate Procurement</a></li> 
          <li><a class="my-sgl-lne" href="#/EnableIntegrity">Integrity </a></li> 
          <li><a class="my-sgl-lne" href="#/EnableSecurity">Security</a></li>  
          <li><a  class="my-th-lne" href="#/EnableIntegratedManagementSystem">Integrated Management System</a></li> 
          <li><a class="my-sgl-lne" href="#/EnableAttractHire">Attract & Hire</a></li> 
          <li><a href="#/EnableCareerDevelopment">Career Development</a></li> 
          <li><a href="#/EnableExternalCompliance">External Compliance</a></li> 
          <li><a class="my-th-lne" href="#/EnableEdAndI">Equality, Diversity & Inclusion</a></li> 
          <li><a class="my-sgl-lne" href="#/EnableIT">IT</a></li> 
          <li><a href="#/EnableOptimisedWorkforce">Optimized Workforce</a></li> 
          <li><a  class="my-th-lne" href="#/EnableHighPerformingCulture">High Performance Culture</a></li>
          <li><a  class="my-th-lne" href="#/EnableSafeHealthyWorkEnvironment">Safe & Healthy Work Environment</a></li>
        </ul>
      </div>

    </div>
  </div>
</div>
<!-- Main content Container section end here -->

    </div>
</template>
<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
import FunctionalComponent from "../components/FunctionalComponent.vue";
import $ from "jquery";

export default {
  name: "ExploretheMarketComp;",
  components: {
    FunctionalComponent
  },
  mounted(){
    $(document).on("mouseenter",'#hoverEft',function(){
    var el= $('.highLite');
    el.css({"background-color":"#929292"})
    el.children().css({"color":"#fff"})
  })
  $(document).on("mouseout",'#hoverEft',function(){
    var el= $('.highLite');
    el.css({"background-color":"#fff"})
    el.children().css({"color":"#000"})
  })

  $(document).on("mouseenter",'#hoverEftexp',function(){
    var el= $('.exp-mark-txt').children().children().children();
    el.css({"background-color":"#E74590"})
    el.css({"color":"#fff"})
  })
  $(document).on("mouseout",'#hoverEftexp',function(){
    var el= $('.exp-mark-txt').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
  })

$(document).on("mouseenter",'#hoverEftLd',function(){
    var el= $('.led-prc-nxt').children().children().children();
    el.css({"background-color":"#00A2DB"})
    el.css({"color":"#fff"})
  })
  $(document).on("mouseout",'#hoverEftLd',function(){
    var el= $('.led-prc-nxt').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
  })

  $(document).on("mouseenter",'#hoverEftDlp',function(){
    var el= $('.hdover-txt').children().children().children();
    el.css({"background-color":"#E31F7B"})
    el.css({"color":"#fff"})
  })
  $(document).on("mouseout",'#hoverEftDlp',function(){
    var el= $('.hdover-txt').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
  })

  $(document).on("mouseenter",'#hoverEftBd',function(){
    var el= $('.bid-wn-steps').children().children().children();
    el.css({"background-color":"#5B4B9A"})
    el.css({"color":"#fff"})
  })
  $(document).on("mouseout",'#hoverEftBd',function(){
    var el= $('.bid-wn-steps').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
  })
  
  $(document).on("mouseenter",'#hoverEftSt',function(){
    var el= $('.st-jb-box').children().children().children();
    el.css({"background-color":"#00A2DB"})
    el.css({"color":"#fff"})
    var el= $('.do-jb-box').children().children().children();
    el.css({"background-color":"#00A2DB"})
    el.css({"color":"#fff"})
    var el= $('.finsh-jb-box').children().children().children();
    el.css({"background-color":"#00A2DB"})
    el.css({"color":"#fff"})
  })
  $(document).on("mouseout",'#hoverEftSt',function(){
    var el= $('.st-jb-box').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
    var el= $('.do-jb-box').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
    var el= $('.finsh-jb-box').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
  })
  
  $(document).on("mouseenter",'#hoverEftDo',function(){
    var el= $('.st-jb-box').children().children().children();
    el.css({"background-color":"#00A2DB"})
    el.css({"color":"#fff"})
    var el= $('.do-jb-box').children().children().children();
    el.css({"background-color":"#00A2DB"})
    el.css({"color":"#fff"})
    var el= $('.finsh-jb-box').children().children().children();
    el.css({"background-color":"#00A2DB"})
    el.css({"color":"#fff"})
  })
  $(document).on("mouseout",'#hoverEftDo',function(){
   var el= $('.st-jb-box').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
    var el= $('.do-jb-box').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
    var el= $('.finsh-jb-box').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
  })
  
  $(document).on("mouseenter",'#hoverEftFn',function(){
    var el= $('.st-jb-box').children().children().children();
    el.css({"background-color":"#00A2DB"})
    el.css({"color":"#fff"})
    var el= $('.do-jb-box').children().children().children();
    el.css({"background-color":"#00A2DB"})
    el.css({"color":"#fff"})
    var el= $('.finsh-jb-box').children().children().children();
    el.css({"background-color":"#00A2DB"})
    el.css({"color":"#fff"})
  })
  $(document).on("mouseout",'#hoverEftFn',function(){
    var el= $('.st-jb-box').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
    var el= $('.do-jb-box').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
    var el= $('.finsh-jb-box').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
  })

  $(document).on("mouseenter",'#hoverEftLdEn',function(){
    var el= $('.enable-sc-box').children().children().children();
    el.css({"background-color":"#58595B"})
    el.css({"color":"#fff"})
  })
  $(document).on("mouseout",'#hoverEftLdEn',function(){
    var el= $('.enable-sc-box').children().children().children();
    el.css({"background-color":"#fff"})
    el.css({"color":"#000"})
  })

}

  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>