<template>
    <div>


<!-- Main content Container section start from here -->
<div class="cont-container">
  <div class="content-wt">
    <div class="content-hd-text">
      <h2>Strategic positioning</h2>
      <p><strong class="bld-txt">Strategic positioning</strong> is one of the most powerful marketing activities. It enables us to influence how we are perceived by our clients and provides an opportunity for us to
          build our reputation whilst differentiating ourselves from our competitors. Through <strong class="bld-txt">strategic positioning</strong> we increase our win work success, and it helps us achieve a
          sustainable competitive advantage. It also empowers us to build lasting differentiation by creating new forms of client value.</p>
  </div>
  <div class="tabs">
    <button class="tab-link" onclick="window.location.href='#/StragicPositioning';">Requirements</button>
    <button class="tab-link active" > Additional Detail</button>
    <!-- <button class="tab-link" onclick="window.location.href='Nonex.html';">Related Governance</button> -->
  </div>

  <div class="detail-cont-pg">
    <div class="top-info-wrap">
      <div class="hd-text"><h3>Detailed Info</h3></div>
      <div class="dropdown">
          <i class="expbtn fas fa-ellipsis-v"></i>
          <div id="export-dots" class="export-content">
            <a href="#"><i class="fas fa-file-pdf"></i> Export as Pdf</a>
              <a href="#"><i class="fas fa-print"></i> Print</a>
          </div>
      </div>
    </div>
    
<div class="detail-txt-cont">
  <h4> Corporate Strategy communicated  </h4>
  <p>The SNC-Lavalin Corporate Strategy shall be produced centrally by SNC-Lavalin Corporate Strategy Team in conjunction with SNC-Lavalin Executive Committee (ExCom). This shall represent the Corporate Strategy Plan and Vision for SNC-Lavalin, including 5-year Budget Plan. The SNC-Lavalin Corporate Strategy shall be communicated internally via internal communications channels, and externally via external communications channels including investor presentations. </p>
  <h4>Identify Global Growth Markets</h4>
  <p>The Global Growth Markets shall be agreed at Global Growth level. Global Market Network Leads shall appointed with responsibility for driving engagement and connectivity across the wider SNC-Lavalin Group.</p>
  <h4> Global Market Strategies defined and shared with relevant market networks</h4>
  <p>Overall approach and strategy structure designed by SNC-Lavalin Corporate Strategy Team and agreed with Market Networkd Leads. Global Market Strategies should be developed by Market Network Leads with coordinated inputs from nominated Regional Market Leads.</p>
  <h4>Regional Market priorities defined and documented in line with Market Strategy </h4>
  <p>Regional Market Plans authors should access Win Work guidance when designing and developing structure of Regional Market Plans. 

    Regional Markets Plans should be connected via "Golden Thread" to Global Market Strategies; to ensure alignment on overall strategic focus and particular consistency around marco drivers, growth themes and strategic priorities. </p>
  <h4>Formal measures identified to enable monitoring of delivery to strategy and priorities</h4>
  <p>Formal KPIs and Metrics shall be agreed to measure performance against Strategy and Plan. Sector, Business Unit and Global Market Win Work metrics shall be measured on a quarterly basis, with Global Growth Team responsibility for coordination and consolidation. Sectors, Business Units and Global Markets should have robust mechanisms in place to enable the tracking of key metrics data.</p>

  <h4>Identify regional market priorities aligned to regional plan </h4>
  <p>Factored and Unfactored Pipeline data by Sector, Business Unit and Global Market shall be identified and prioritized in-line with Regional Market Plans, including by prioritizing "Must-Wins".</p>

  <h4>Strategically position opportunities for specific clients/ individual pursuits</h4>
  <p>Utilise tools and process for undertaking early stage, pre-positioning Capture Planning on prioritized "must-wins" with adequate "lead-in" time.</p>

</div>
</div>
    </div>
</div>
<!-- Main content Container section end here -->



    </div>
</template>



<script>
import api from "@/service";
import router from "@/router";
import { mapGetters } from "vuex";
export default {
  name: "StragicPositioningDetailedViewComp",
  // data() {
  //   return {
  //     banner: Banner,
  //     searchText: "",
  //     search: false,
  //     sr: "",
  //     searchResults: [],
  //   };
  // },
  // computed: {
  //   ...mapGetters(["subStages", "stages", "header"]),
  //   completeStagesInfo() {
  //     let array = [];
  //     this.subStages.forEach((subStage) => {
  //       let stage = this.stages.find((stage) => stage.Id === subStage.StageId);
  //       subStage.Stage = stage;
  //       array.push(subStage);
  //     });
  //     return array;
  //   },
  //   searchRes() {
  //     if (this.sr) {
  //       return this.completeStagesInfo.filter((post) => {
  //         if (post.Title) {
  //           return post.Title.toLowerCase().includes(this.sr.toLowerCase());
  //         }
  //       });
  //     }
  //   },
  // },
  // methods: {
  //   redirectTo() {
  //     this.sr = "";
  //     this.$router.push("/").catch((err) => {});
  //   },
  //   pushTo(slug) {
  //     this.sr = "";
  //     if (this.$route.params.slug !== slug) {
  //       // this.$router.go({ path: `/detail/${slug}` })
  //       this.$router.push({ name: "Detail", params: { slug: slug } });
  //     }
  //     this.$emit("searching", { active: false });
  //   },
  // },
  // watch: {
  //   $route(to, from) {
  //     // Reset Search If route changes
  //     // this.search = false;
  //     // this.searchText = '';
  //     // this.searchResults = [];
  //   },
  // },
};
</script>