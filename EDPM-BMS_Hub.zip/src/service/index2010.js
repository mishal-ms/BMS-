import axios from 'axios';

const url ='http://organisation.eu.atkinsglobal.com/sites/Creative_Design/Babcock/_vti_bin/listdata.svc/';
const list1 = 'Stages';


export default {
    
    /**
     * Gets all stages from list
     */
    getAllStages() {

        // Query 1
        let expand = 'StepGroup2/Title';
        let query = "?$select=*";
    

         let request = url + list1+'?$select=*&$top=500';

        return axios.get(request)
        .then(response => { console.log('TESTING DATA', response)
            return response.data.d;
        })
        .catch(error => {
            return error;
        })
    },

    getAll() {
        return axios.all([this.getAllStages()]).then(axios.spread(function (stages) {
            return {
                stages: stages
            }
        }));
    }

}