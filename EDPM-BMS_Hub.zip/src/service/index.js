import axios from 'axios';

// const url = 'https://atkins.sharepoint.com/sites/BIMNavigator/_api/';
const url = 'https://atkins.sharepoint.com/sites/GDFLibrary/_api/';

const list1 = 'Stages';
const list2 = 'StageType';
const list3 = 'SubStages';
const list4 = 'VideoLinks';
const list5 = 'Links';
const list6 = 'Documents';
const list7 = 'Header';
const list8 = 'Footer';
export default {

    getHeaderDetails() {
        let query = "?$select=*";
        let request = url + "lists/getbytitle('" + list7 + "')/items" + query;

        return axios.get(request).then(response => {
            return response.data.value;
        }).catch(error => {
            return error;
        })
    },
    getFooterDetails() {
        let query = "?$select=*";
        let request = url + "lists/getbytitle('" + list8 + "')/items" + query;

        return axios.get(request).then(response => {
            return response.data.value;
        }).catch(error => {
            return error;
        })
    },

    getAllStages() {

        let expand = 'StageType/Title';
        let query = "?$select=*,"+ expand + "&$expand="+ expand;
        let request = url + "lists/getbytitle('" + list1 + "')/items" + query + '&$top=500';

        return axios.get(request).then(response => {
            return response.data.value;
        }).catch(error => {
            return error;
        })
    },

    getStagesType() {
        let query = "?$select=*";
        let request = url + "lists/getbytitle('" + list2 + "')/items" + query;

        return axios.get(request).then(response => {
            return response.data.value;
        }).catch(error => {
            return error;
        })
    },

    getSubStages() {
        let expand = 'Stage/Title';
        let query = "?$select=*,"+ expand + "&$expand="+ expand;
        let request = url + "lists/getbytitle('" + list3 + "')/items" + query + '&$top=500';

        return axios.get(request).then(response => {
            return response.data.value;
        }).catch(error => {
            return error;
        })
    },
    getAllVideos() {
        
        let expand = 'Slug/Title,Slug/Slug';
        let query = "?$select=*,"+ expand + "&$expand="+expand;
        let request = url + "lists/getbytitle('" + list4 + "')/items" + query + '&$top=500';

        return axios.get(request).then(response => {
            return response.data.value;
        }).catch(error => {
            return error;
        })
    },
    getAllLinks() {
        let expand = 'Slug/Title,Slug/Slug';
        let query = "?$select=*,"+ expand + "&$expand="+ expand;
        let request = url + "lists/getbytitle('" + list5 + "')/items" + query + '&$top=500';

        return axios.get(request).then(response => {
            return response.data.value;
        }).catch(error => {
            return error;
        })
    },
    getAllDocuments() {
        let docFileName='FieldValuesAsText/FileRef,';
        let expand = 'Slug/Title,Slug/Slug';
        let filePath='FieldValuesAsText,';
        let query = "?$select=*,"+docFileName+ expand + "&$expand="+ filePath+expand;
        let request = url + "lists/getbytitle('" + list6 + "')/items" + query + '&$top=500';

        return axios.get(request).then(response => {
            return response.data.value;
        }).catch(error => {
            return error;
        })
    },
    getAll() {
        return axios.all([this.getAllStages(),this.getStagesType(),this.getSubStages(),this.getAllDocuments(),this.getAllLinks(),this.getAllVideos(),this.getHeaderDetails(),this.getFooterDetails()])
        .then(axios.spread(function (stages,stagesType,subStages,documents,links,videos,header,footer) {
            return {
                stages: stages,
                stagesType:stagesType,
                subStages:subStages,
                documents:documents,
                links:links,
                videos:videos,
                header:header,
                footer:footer
            }
        }));
    }

}