<template>
	<div class="detail">

        <BimStages />
	
		<section class="detail-section" v-show="!showGrid && !showDiagram"> 
			<b-container v-if="renderData">
                <b-row class="detail-title-row">
                    <b-col lg="12">
                        <div class="content-wrapper" v-if="renderData">
							<h1 >{{renderData.Title}}</h1>
                            <p>{{renderData.Overview}}</p>
						</div>
                    </b-col>
                </b-row>
				<b-row class="detail-content-row">
					<b-col lg="7">
                        <!-- <div id="hidden" style="display: none" v-html="rteText"></div>
                        <div id="text-tabs"></div> -->
                        <div class="detail-tabs" id="rte-tabs">
                            <b-tabs content-class="mt-3" align="left" v-model="tabIndex" @input="reConfigureRTE()">
                                <b-tab :title="renderData.TabTitle1" active v-if="renderData.TabTitle1!=null || renderData.TabTitle1!=undefined">
                                    <div class="rte-wrap" v-html="renderData.TabDesc1"></div>
                                </b-tab>
                                <b-tab :title="renderData.TabTitle2" v-if="renderData.TabTitle2!=null || renderData.TabTitle2!=undefined">
                                    <div class="rte-wrap" v-html="renderData.TabDesc2"></div>
                                </b-tab>
                                <b-tab :title="renderData.TabTitle3" v-if="renderData.TabTitle3!=null || renderData.TabTitle3!=undefined">
                                    <div class="rte-wrap" v-html="renderData.TabDesc3"></div>
                                </b-tab>
                                <b-tab :title="renderData.TabTitle4" v-if="renderData.TabTitle4!=null || renderData.TabTitle4!=undefined">
                                    <div class="rte-wrap" v-html="renderData.TabDesc4"></div>
                                </b-tab>
                                <b-tab :title="renderData.TabTitle5" v-if="renderData.TabTitle5!=null || renderData.TabTitle5!=undefined">
                                    <div class="rte-wrap" v-html="renderData.TabDesc5"></div>
                                </b-tab>
                            </b-tabs>
                        </div>
					</b-col>
					<b-col lg="4" offset-lg="1" v-if="renderVideos.length > 0 || renderDocuments.length > 0 || renderLinks.length > 0">
						<div class="block-videos" v-if="renderVideos && renderVideos.length > 0">
							<h2>Videos</h2>
							<div class="videos-container">
								<div class="video" v-for="(video, index) in renderVideos" :key="index">
                                    <div class="responsive-frame">
                                        <iframe :src="video.Link" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                    </div>
                                    <p>{{video.Desc}}</p>
								</div>
                                
							</div>
						</div>
						<div class="block-docs" v-if="renderDocuments && renderDocuments.length > 0">
							<h2>Documents</h2>
							<div class="docs-container">
								<ul>
									<li  v-for="(doc, index) in renderDocuments" :key="index">
										<a :href="doc.FieldValuesAsText.FileRef" target="_blank">
                                            <font-awesome-icon :icon="['far', 'file-alt']" />
                                            <span>{{doc.Title}}</span>
                                        </a>
									</li>
								</ul>
							</div>
						</div>
                        <div class="block-docs" v-if="renderLinks && renderLinks.length > 0">
							<h2>Links</h2>
							<div class="docs-container">
								<ul>
									<li v-for="(link, index) in renderLinks" :key="index">
										<a :href="link.Link" target="_blank">
                                            <font-awesome-icon :icon="['fas', 'external-link-alt']" />
                                            <span>{{link.Title}}</span>
                                        </a>
									</li>
								</ul>
							</div>
						</div>
					</b-col>
				</b-row>
			</b-container>
		</section>
	</div>
</template>



<script>
// @ is an alias to /src
// import $ from 'jquery'
import HeaderComp from '@/components/Header.vue'
import BimStages from '@/components/BimStages.vue'
import { BimStageMixin } from '@/mixins/showAllBIMStages'
import { mapActions,mapGetters } from 'vuex'
export default {
    name: 'Detail',
    mixins: [BimStageMixin],
	components: {
	    HeaderComp, BimStages
    },
    data() {
        return {
            tabIndex: 0,
            tabs: null
        }
    },
    computed: {
        ...mapGetters([
			'combinedResults','links','documents','videos', 'showGrid', 'showDiagram'
        ]),
        slugID() {
			return this.$route.params.slug
        },
        renderVideos(){
            const vm = this;
            if(this.videos) {
                    var filtered_values = _.filter(this.videos, function(p){
                        return  p.Slug.Slug==vm.slugID;  
                    });
                    return filtered_values
            }else{
                    return ''
            }
        },
        renderDocuments(){
            const vm = this;
            if(this.documents) {
                    var filtered_values = _.filter(this.documents, function(p){
                        return  p.Slug.Slug==vm.slugID;  
                    });
                    return filtered_values
            }else{
                    return ''
            }
        },
        renderLinks(){
            const vm = this;
            if(this.links) {
                    var filtered_values = _.filter(this.links, function(p){ 
                        return  p.Slug.Slug==vm.slugID;  
                    });
                    return filtered_values
            }else{
                    return ''
            }
        },
        renderData() {
            const vm = this;
			if(this.combinedResults) {
                var result=_.find(this.combinedResults,{Slug: vm.slugID})
                if(result){
                    this.SET_STAGE(result.Stage.Id);
                    this.SET_STAGE_TYPE(result.Stage.StageTypeId);
                    return result
                }else{
                    return ''
                }
                
                
			} else {
				return []
			}
        },
    },
    mounted() {
        const vm = this;
        
        this.$nextTick(() => {
            // console.log('dom loaded in mounted')
            this.UPDATE_SHOW_GRID(false);
            
            this.configureRTE();
        }); 
        
    },
    methods: {
        ...mapActions([
			'SET_STAGE','SET_STAGE_TYPE','UPDATE_SHOW_GRID'
        ]),
        
       
        
        configureRTE() {

            $('#custom-overlay').remove();

            $('#rte-tabs .tab-content').find('img').each(function(i, v) {
                if(!$(v).parent('a.popup-image').length) {
                    $(v).wrap('<a href="#" class="popup-image"></a>');
                }
            });

            $(document).on("click", ".popup-image", function(e){
                e.preventDefault();
                let string = '<div id="custom-overlay">';
                    string += '<a href="#" id="CloseModal"></a><div>';
                    string += $(this).html();
                    string += '</div>'
                    string += '</div>';
                $('body').append(string);
                $('html, body').css({
                    overflow: 'hidden'
                });
            })

            $(document).on("click", "#CloseModal" , function(e) {
                e.preventDefault();
                $('#custom-overlay').remove();
                    $('html, body').css({
                    overflow: 'auto'
                });
            });
        },
        reConfigureRTE() {
            this.$nextTick(() => {
                $('#rte-tabs .tab-content').find('img').each(function(i, v) {
                    if(!$(v).parent('a.popup-image').length) {
                        $(v).wrap('<a href="#" class="popup-image"></a>');
                    }
                });
            })
		},
    },
    watch: {
        
        renderData: function (newValue, oldValue) {
            this.$nextTick(() => {
                console.log('dom loaded in watcher')
                this.reConfigureRTE();
            })
        },
    },
}
</script>
