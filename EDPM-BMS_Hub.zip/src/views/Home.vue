<template>
	<div class="home">
		
		<!-- <BimStages /> -->
	 <HomeComponent/>
		<!-- <section class="stages-info" v-show="!bimStagesOpen"> 
			<b-container>
				<b-row>
					<b-col lg="8">
						<div class="content-wrapper">
							<h2 v-if="stageDesc">{{stageDesc.OrderNumber}}.{{stageDesc.Title}}</h2>
							<p v-if="stageDesc">{{stageDesc.Desc}}</p>
							<ol>
								<li v-for="(substage,index) in stageDetails" :key="index">
									<router-link :to="{ name: 'Detail', params: {slug: substage.Slug } }">
										<div>
											<span>{{stageDesc.OrderNumber}}.{{index+1}}</span> {{substage.Title}}
										</div>
									</router-link>
								</li>
							</ol>
						</div>
					</b-col>
				</b-row>
			</b-container>
		</section> -->
	</div>
</template>

<script>
import BimStages from '@/components/BimStages.vue'
import { mapActions, mapGetters } from 'vuex'
import HeaderComp from '@/components/Header.vue'
import { BimStageMixin } from '@/mixins/showAllBIMStages'
import HomeComponent from '@/components/HomeComponent.vue'

export default {
	name: 'Home',
	// mixins: [BimStageMixin],
	components: {
		BimStages, HeaderComp,HomeComponent
	},
	created(){
		// const vm=this
	},
	mounted(){
	},
	computed: {
		// ...mapGetters([
		// 	'combinedResults','stageTypeNum','stageNum','stages',
		// ]),
		// stageDesc(){
		// 	var result= _.find(this.stages,{Id: this.stageNum});			
		// 	return result;
		// },
		// stageDetails(){
		// 	var result=  _.chain(this.combinedResults).groupBy("Stage.ID").value();
		// 	if(result != undefined){
		// 		return result[this.stageNum];
		// 	}else{
		// 		return ''
		// 	}
		// },
	}
}
</script>
