
// JavaScript Document for basic use

$(document).ready(function() {	
	togPanel();
	$(".expbtn").click(function(){
        $(".export-content").toggle();
      });

	  $(".sign-out-btn").click(function(){
		$(".logout-content").toggle();
	  });

	  $("#moreInfo").click(function(){
		$("#showOne").toggle();
	  });

	  $(".message-btn").click(function(){
        $(".popuptext-message").toggle();
      });

	  $(".popup").click(function(){
        $(".popuptext").toggle();
      });

	  $(".tab button").hover(function() {
	  	$('.tab button').removeClass('active');
 	$(this).addClass('active');
   });
	  

  







   
});
$(window).resize(function(){
	togPanel();
});

function togPanel(){
	$('.togPanel .right-panel').append("<button class='togBtnPanel'><span class='d-none'>Panel Toggle Button</span></button>");
	$('.togBtnPanel').on("click", function(){
		$(this).toggleClass("openNow");
		$('.togPanel').find('.left-panel').toggleClass("moveLeft");
		$('.togPanel').find('.right-panel').toggleClass("fullView");
	})
}


// export menu
 $(document).ready(function(){
	$(".search-bar-expand").click(function(){
		$(".search-expand").animate({
			width: "toggle"
		});
	});
});





     

     
$(window).scroll(function() 
{
 if ($(this).scrollTop() > 1)
 {
  $('#myHeader').addClass("sticky_header");
 }
 else
 {
  $('#myHeader').removeClass("sticky_header");
 }
});




