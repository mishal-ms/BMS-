import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
		results: {},
		stageNum:1,
		stageTypeNum:1,
		combinedResults:[],
		stageDetails:[],
		parentClassIndex: 1,
		showGrid: false,
		showDiagram: false,
		showpopup:false,
		popupcontent:"Loading..",
		
	},
	mutations: {
		storeResults(state, payload) {
			state.results = payload
		},
		storeCombinedResult(state, payload) {
			state.combinedResults = payload
		},
		addToResults(state, payload) {
			state.results = { ...state.results, ...payload }
		},
		SetStage(state, payload) {
			state.stageNum = payload
		},
		SetStageType(state, payload) {
			state.stageTypeNum = payload
		},
		SetStageDetails(state, payload) {
			state.stageDetails= payload
		},
		updateParentIndex(state, payload) {
			state.parentClassIndex = payload
		},
		updateShowGrid(state, payload) {
			state.showGrid = payload
		},
		updateShowDiagram(state, payload) {
			state.showDiagram = payload
		},
		updateshowpopup(state, payload) {
			state.showpopup = payload
		},
		updatepopupcontent(state, payload) {
			state.popupcontent = payload
		}
	},
	actions: {
		storeResults ({ commit }, payload) {
			commit('storeResults', payload)
		},
		storeCombinedResult ({ commit }, payload) {
			commit('storeCombinedResult', payload)
		},
		addToResults({ commit }, payload) {
			commit('addToResults', payload)
		},
		SET_STAGE({commit},payload){
            commit('SetStage',payload)
		},
		SET_STAGE_TYPE({commit},payload){
            commit('SetStageType',payload)
		},
		SET_STAGE_DETAILS({commit},payload){
            commit('SetStageDetails',payload)
		},
		UPDATE_PARENT_INDEX({commit},payload){
            commit('updateParentIndex',payload)
		},
		UPDATE_SHOW_GRID({commit},payload){
            commit('updateShowGrid',payload)
		},
		UPDATE_SHOW_DIAGRAM({commit},payload){
            commit('updateShowDiagram',payload)
        },
		UPDATE_SHOW_POPUP({commit},payload){
            commit('updateshowpopup',payload)
        },
		UPDATE_POPUP_CONTENT({commit},payload){
            commit('updatepopupcontent',payload)
        },
	},
	getters: {
	combinedResults: state => state.combinedResults,

    results: state => state.results,
    stages: state => state.results.stages,
    stagesType: state => state.results.stagesType,
	subStages: state => state.results.subStages,
	links:	state=>state.results.links,
	documents:	state=>state.results.documents,
	videos:	state=>state.results.videos,
	header:	state=>state.results.header,
	footer:	state=>state.results.footer,

	stageNum: state => state.stageNum,
	stageDetails: state => state.stageDetails,
	stageTypeNum: state => state.stageTypeNum,

	parentClassIndex: state => state.parentClassIndex,
	showGrid: state => state.showGrid,
	showDiagram: state => state.showDiagram,
	showpopup: state => state.showpopup,
	popupcontent: state => state.popupcontent
	},
	modules: {
	}
})
