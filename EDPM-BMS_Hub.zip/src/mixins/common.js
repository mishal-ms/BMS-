/* eslint-disable */

const SiteUrl='/sites/creativedesign/ProjectShowcase/babcock/html/dist/index.aspx#/'

export default {
    created: function () {
    
    },

    data() {
        return {
            
        }
    },

    methods: {

    }
}