export const BimStageMixin  = {
    data() {
        return {
			bimStagesOpen: false
        }
	},
    methods: {
		showStages(value) {
			this.bimStagesOpen = value.active;
		}
	}
}