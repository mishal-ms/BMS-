import 'core-js/stable'
import 'regenerator-runtime/runtime'
// import 'intersection-observer' // Optional

// Vue Config Settings
Vue.config.productionTip = false
Vue.config.devtools = true

import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

// Bootstrap Settings
import { BootstrapVue, IconsPlugin } from 'bootstrap-vue';
Vue.use(BootstrapVue)
Vue.use(IconsPlugin)

window.$ = window.jQuery = require('jquery');

// Font Awesome Settings
import { library } from '@fortawesome/fontawesome-svg-core'
import { faSearch, faExternalLinkAlt, faProjectDiagram } from '@fortawesome/free-solid-svg-icons'
import { faFileAlt } from '@fortawesome/free-regular-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'
library.add(faSearch, faFileAlt, faExternalLinkAlt, faProjectDiagram)
Vue.component('font-awesome-icon', FontAwesomeIcon)

// Axios Settings
import axios from 'axios';
axios.defaults.baseURL = process.env.BASE_URL;
Vue.prototype.$http = axios;

// Global Var
Vue.prototype.$baseUrlPath = process.env.BASE_URL;

// Global Filters
Vue.filter('dbldigit',  function (value) {
  return ('00'+value).slice(-2);
});

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
